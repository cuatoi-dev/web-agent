# @dragon-ai/web-agent-charting

Chart.js tools, skills and lit-html chart blocks for the web-agent in-app
browser agent — lets the agent render charts in its replies.

## Install

```bash
pnpm add @dragon-ai/web-agent-charting lit-html
```

`lit-html` (^3) is a peer dependency, supplied by the host application.

## Usage

```ts
// tools + skills (no UI)
import { chartingTools } from "@dragon-ai/web-agent-charting";

// lit-html renderers; also registers <agent-chart-block>
import { chartingRenderers } from "@dragon-ai/web-agent-charting/lit";
```

The `./lit` entry point has side effects (custom-element registration) and is
marked as such so bundlers do not tree-shake the registration away.

## License

Apache-2.0
