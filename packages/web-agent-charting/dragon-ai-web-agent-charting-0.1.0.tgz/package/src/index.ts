import type { CustomToolDef, SkillDef } from "@dragon-ai/web-agent-core";
import { runShowChart, SHOW_CHART_SCHEMA } from "./tools/show-chart.js";
import { chartSkill } from "./skills/chart-skill.js";

/** show_chart tool — spread into a host's `tools:` like dataTools(). */
export function chartingTools(): CustomToolDef[] {
  return [
    {
      name: "show_chart",
      description:
        'Present a Chart.js chart to the user. Call load_skill("chart") before your first chart ' +
        "to learn the config shape, supported types, per-type data rules, and worked examples. " +
        "Pass { title?, config } where config is a Chart.js 2.x config object. " +
        "On invalid config the tool returns a precise field-path error so you can fix and retry.",
      inputSchema: SHOW_CHART_SCHEMA,
      execute: runShowChart,
    },
  ];
}

/** chart skill — spread into a host's `skills:` like coreSkills(). */
export function chartingSkills(): SkillDef[] {
  return [chartSkill];
}

export * from "./ui-blocks/chart-schema.js";
export * from "./ui-blocks/chart-spec.js";
export { runShowChart, SHOW_CHART_SCHEMA } from "./tools/show-chart.js";
export { chartSkill } from "./skills/chart-skill.js";
