import type { RenderableBlock } from "@dragon-ai/web-agent-core";
import type { BlockRenderer, RenderCtx } from "@dragon-ai/web-agent-lit";
import "./chart-block.js";

export const chartRenderer: BlockRenderer = {
  types: ["chart"],
  render(block: RenderableBlock, ctx: RenderCtx): Node {
    const disabled = !!ctx.disabled;
    const dataSource = ctx.dataSource;
    const el = document.createElement("agent-chart-block");
    (el as any).block = block;
    (el as any).dataSource = dataSource;
    (el as any).disabled = disabled;
    return el;
  },
  promptSnippet: `
- Chart: { "type": "chart", "title": string (optional), "config": <Chart.js 2.x config> }
  Use show_chart tool (preferred) or emit the block directly.
  Call load_skill("chart-skill") for the full Chart.js config schema and examples.
- Use a chart when comparing or showing trends over more than ~5 data points; prefer text or a table otherwise.
`.trim(),
};
