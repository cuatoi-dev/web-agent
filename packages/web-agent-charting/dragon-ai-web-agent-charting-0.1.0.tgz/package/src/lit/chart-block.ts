import Chart from "chart.js";
import { Component, injectStyle, html } from "@dragon-ai/web-agent-lit";
import type { DataSourceProvider, QueryResult } from "@dragon-ai/web-agent-core";
import type { ChartBlock } from "../ui-blocks/chart-schema.js";
import { hasDataUrl, checkRowCountExceeded, sanitizeChartConfig, checkAxisIdMismatch, transformFinancialConfig, transformPayoffConfig, transformPnlConfig, transformWaterfallConfig } from "../ui-blocks/chart-spec.js";
import "./finance-charts.js"; // side-effect: register the finance draw plugin
import { CHART_PALETTE } from "./chart-palette.js";
import { applyChartDefaults } from "./chart-theme.js";

const DEFAULT_INTERVAL_MS = 60000;
const MIN_INTERVAL_MS = 5000;

export class AgentChartBlock extends Component {
  private _block!: ChartBlock;
  private _disabled = false;
  private _dataSource?: DataSourceProvider;

  private _error: string | null = null;
  private _loading = false;
  private _mode: "auto" | "manual" | "off" = "auto";
  private _lastUpdated: number | null = null;

  private _chartInstance: Chart | null = null;
  private _intersectionObserver: IntersectionObserver | null = null;
  private _refreshTimer: ReturnType<typeof setInterval> | null = null;
  private _themeObserver: MutationObserver | null = null;
  private _inView = false;
  private _boundVisibilityHandler = () => this._syncTimer();
  private _lastRenderedBlock: ChartBlock | null = null;

  get block() { return this._block; }
  set block(v) {
    this._block = v;
    this.requestUpdate();
  }

  get disabled() { return this._disabled; }
  set disabled(v) {
    this._disabled = !!v;
    this.requestUpdate();
  }

  get dataSource() { return this._dataSource; }
  set dataSource(v) {
    this._dataSource = v;
    this.requestUpdate();
  }

  get error() { return this._error; }
  set error(v) {
    this._error = v;
    this.requestUpdate();
  }

  get loading() { return this._loading; }
  set loading(v) {
    this._loading = !!v;
    this.requestUpdate();
  }

  get mode() { return this._mode; }
  set mode(v) {
    this._mode = v;
    this.requestUpdate();
  }

  get lastUpdated() { return this._lastUpdated; }
  set lastUpdated(v) {
    this._lastUpdated = v;
    this.requestUpdate();
  }

  connectedCallback() {
    super.connectedCallback();
    this.style.display = "block";
    this.style.width = "100%";
    injectStyle("agent-chart-block-styles", `
      agent-chart-block {
        display: block;
        margin: 12px 0;
        font-family: var(--dragon-font-family, "Public Sans", system-ui, -apple-system, sans-serif);
      }
      agent-chart-block .error-card {
        background-color: var(--dragon-action-color-error-10opc, #fde8e8);
        border: 1px solid var(--dragon-action-color-error-40opc, #f98080);
        border-radius: 12px;
        padding: 16px;
        color: var(--dragon-text-color, #9b1c1c);
      }
      agent-chart-block .error-title {
        font-weight: bold;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      agent-chart-block details {
        margin-top: 8px;
        font-size: 0.85em;
        cursor: pointer;
      }
      agent-chart-block summary {
        color: var(--dragon-label-color, #771d1d);
        font-weight: 500;
      }
      agent-chart-block pre {
        background: var(--dragon-background-color-300, #fdf2f2);
        padding: 8px;
        border-radius: 6px;
        overflow-x: auto;
        margin-top: 4px;
        font-family: monospace;
        font-size: 0.9em;
      }
      agent-chart-block .chart-container {
        background: var(--dragon-background-color-300, white);
        border-radius: 12px;
        border: 1px solid var(--dragon-border-color, #e0e0e0);
        padding: 16px;
        transition: opacity 0.3s, filter 0.3s;
        overflow: hidden;
      }
      agent-chart-block .chart-container.disabled {
        opacity: 0.5;
        pointer-events: none;
        filter: grayscale(1);
      }
      agent-chart-block h3 {
        margin-top: 0;
        margin-bottom: 12px;
        font-size: 1.1em;
        color: var(--dragon-text-color, #3c4043);
      }
      agent-chart-block .chart-canvas {
        width: 100%;
        position: relative;
        min-height: 150px;
        overflow: hidden;
      }
      agent-chart-block .chart-canvas canvas {
        display: block;
      }
      agent-chart-block .refresh-controls {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 8px;
        font-size: 0.8em;
        color: var(--dragon-label-color, #666);
      }
      agent-chart-block .refresh-controls button {
        background: var(--dragon-background-color-500, #f0f0f0);
        border: 1px solid var(--dragon-border-color, #ccc);
        border-radius: 6px;
        padding: 4px 10px;
        font-size: 0.85em;
        cursor: pointer;
        color: var(--dragon-text-color, #333);
        transition: background 0.15s;
      }
      agent-chart-block .refresh-controls button:hover {
        background: var(--dragon-background-color-700, #e0e0e0);
      }
      agent-chart-block .refresh-controls button.refresh-btn {
        background: var(--dragon-action-color-info, #6200ee);
        color: var(--dragon-action-text-color-info, white);
        border-color: var(--dragon-action-color-info, #6200ee);
      }
      agent-chart-block .refresh-controls button.refresh-btn:hover {
        background: var(--dragon-action-color-info-700, #5000d0);
      }
      agent-chart-block .mode-indicator {
        font-weight: 500;
        padding: 2px 8px;
        border-radius: 4px;
        cursor: pointer;
        user-select: none;
      }
      agent-chart-block .mode-indicator.auto {
        color: var(--dragon-action-color-success, #2e7d32);
      }
      agent-chart-block .mode-indicator.manual {
        color: var(--dragon-action-color-warn, #e65100);
      }
      agent-chart-block .mode-indicator.off {
        color: var(--dragon-text-color-disabled, #888);
      }
      agent-chart-block .updated-stamp {
        margin-left: auto;
        color: var(--dragon-label-color, #999);
        font-size: 0.9em;
      }
    `);
    if (typeof MutationObserver !== "undefined") {
      this._themeObserver = new MutationObserver(() => { void this._renderChart(); });
      this._themeObserver.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ["data-theme"],
      });
    }
    if ((this.block?.query && this.block?.encoding) || this.block?.refresh) {
      this._initRefresh();
    }
    document.addEventListener("visibilitychange", this._boundVisibilityHandler);
  }

  disconnectedCallback() {
    document.removeEventListener("visibilitychange", this._boundVisibilityHandler);
    this._cleanupRefresh();
    if (this._themeObserver) {
      this._themeObserver.disconnect();
      this._themeObserver = null;
    }
    if (this._chartInstance) {
      this._chartInstance.destroy();
      this._chartInstance = null;
    }
  }

  updated() {
    if (this.block !== this._lastRenderedBlock) {
      this._lastRenderedBlock = this.block;
      this._cleanupRefresh();
      this.mode = "auto";
      this.lastUpdated = null;
      this._inView = false;
      if ((this.block?.query && this.block?.encoding) || this.block?.refresh) {
        this._initRefresh();
      }
      this._renderChart();
    }
  }

  private _initRefresh() {
    this.mode = this.block?.refresh?.mode ?? "auto";

    if (!this._intersectionObserver && typeof IntersectionObserver !== "undefined") {
      this._intersectionObserver = new IntersectionObserver(
        (entries) => {
          const entry = entries[0];
          this._inView = entry.isIntersecting;
          this._syncTimer();
        },
        { threshold: 0 }
      );
      this._intersectionObserver.observe(this);
    }

    this._syncTimer();
  }

  private _cleanupRefresh() {
    if (this._refreshTimer !== null) {
      clearInterval(this._refreshTimer);
      this._refreshTimer = null;
    }
    if (this._intersectionObserver) {
      this._intersectionObserver.disconnect();
      this._intersectionObserver = null;
    }
  }

  private _syncTimer() {
    if (this._refreshTimer !== null) {
      clearInterval(this._refreshTimer);
      this._refreshTimer = null;
    }

    if (
      this.block?.query &&
      this.block?.encoding &&
      this.mode === "auto" &&
      this._inView &&
      document.visibilityState === "visible" &&
      !this.disabled
    ) {
      const intervalMs = Math.max(
        this.block?.refresh?.intervalMs ?? DEFAULT_INTERVAL_MS,
        MIN_INTERVAL_MS
      );
      this._refreshTimer = setInterval(() => this._refreshTick(), intervalMs);
    }
  }

  private async _refreshTick() {
    if (
      !this.block?.query ||
      !this.block?.encoding ||
      this.mode !== "auto" ||
      !this._inView ||
      document.visibilityState !== "visible" ||
      this.disabled
    ) {
      this._syncTimer();
      return;
    }

    if (!this.block?.query || !this.dataSource) return;

    try {
      const result: QueryResult = await this.dataSource.query(this.block.query as any);

      if (this._chartInstance && this.block.encoding) {
        const newConfig = this._buildChartJsConfig(this.block.encoding, result.rows);
        this._chartInstance.data = newConfig.data;
        this._chartInstance.update();
      } else {
        await this._renderChart();
      }

      this.lastUpdated = Date.now();
    } catch (err: any) {
      console.error("Auto-refresh query failed:", err);
    }
  }

  private _handleModeToggle() {
    const cycle: Array<"auto" | "manual" | "off"> = ["auto", "manual", "off"];
    const idx = cycle.indexOf(this.mode);
    const next = cycle[(idx + 1) % cycle.length];
    this.mode = next;
    this._syncTimer();
  }

  private _handleManualRefresh() {
    this._renderChart().then(() => {
      this.lastUpdated = Date.now();
    });
  }

  private _setError(error: string | null) {
    const oldError = this.error;
    this.error = error;
    if (error && error !== oldError) {
      this.dispatchEvent(new CustomEvent("chart-error", {
        detail: { error, block: this.block },
        bubbles: true,
        composed: true
      }));
    }
  }

  private _buildChartJsConfig(encoding: any, rows: Record<string, any>[]): any {
    const mark = encoding.mark as string;

    if (mark === "candlestick" || mark === "ohlc") {
      const xF = encoding.x?.field ?? "x";
      const oF = encoding.open?.field ?? "open";
      const hF = encoding.high?.field ?? "high";
      const lF = encoding.low?.field ?? "low";
      const cF = encoding.close?.field ?? "close";
      return {
        type: mark,
        data: {
          datasets: [{
            label: encoding.title ?? "OHLC",
            data: rows.map(r => ({ x: r[xF], o: +r[oF], h: +r[hF], l: +r[lF], c: +r[cF] })),
          }],
        },
        options: { responsive: true, maintainAspectRatio: false },
      };
    }

    if (mark === "arc") {
      const labelField = encoding.color?.field ?? encoding.x?.field ?? "label";
      const dataField = encoding.theta?.field ?? encoding.y?.field ?? "value";
      return {
        type: "pie",
        data: {
          labels: rows.map(r => r[labelField]),
          datasets: [{
            data: rows.map(r => r[dataField]),
            backgroundColor: CHART_PALETTE.slice(0, rows.length),
          }],
        },
        options: { responsive: true, maintainAspectRatio: false },
      };
    }

    const chartType = mark === "area" ? "line" : mark;
    const xField = encoding.x?.field ?? "x";
    const yField = encoding.y?.field ?? "y";
    const labels = rows.map(r => r[xField]);

    if (encoding.color?.field) {
      const colorField = encoding.color.field as string;
      const groups = new Map<string, any[]>();
      rows.forEach(r => {
        const key = String(r[colorField]);
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key)!.push(r[yField]);
      });
      const datasets = Array.from(groups.entries()).map(([key, data], i) => ({
        label: key,
        data,
        backgroundColor: CHART_PALETTE[i % CHART_PALETTE.length],
        borderColor: CHART_PALETTE[i % CHART_PALETTE.length],
        fill: mark === "area",
      }));
      return {
        type: chartType,
        data: { labels, datasets },
        options: { responsive: true, maintainAspectRatio: false },
      };
    }

    return {
      type: chartType,
      data: {
        labels,
        datasets: [{
          label: yField,
          data: rows.map(r => r[yField]),
          backgroundColor: CHART_PALETTE[0],
          borderColor: CHART_PALETTE[0],
          fill: mark === "area",
        }],
      },
      options: { responsive: true, maintainAspectRatio: false },
    };
  }

  private async _renderChart() {
    if (this._chartInstance) {
      this._chartInstance.destroy();
      this._chartInstance = null;
    }
    this.error = null;
    applyChartDefaults(this);

    if (!this.block) {
      this._setError("Invalid chart block: missing block");
      return;
    }

    // Primary: block.config → Chart.js render
    if (this.block.config) {
      const config = this.block.config;
      if (hasDataUrl(config)) {
        this._setError("chart used a forbidden data.url");
        return;
      }
      if (checkRowCountExceeded(config)) {
        this._setError("chart exceeded 2000-row cap");
        return;
      }
      const axisMismatch = checkAxisIdMismatch(config);
      if (axisMismatch) {
        this._setError(axisMismatch);
        return;
      }
      const sanitized = sanitizeChartConfig(config);
      sanitized.options = sanitized.options ?? {};
      if (sanitized.options.responsive === undefined) sanitized.options.responsive = true;
      if (sanitized.options.maintainAspectRatio === undefined) sanitized.options.maintainAspectRatio = false;
      const finalConfig = transformFinancialConfig(transformPayoffConfig(transformPnlConfig(transformWaterfallConfig(sanitized))));
      const canvas = this.querySelector("#chart-el") as HTMLCanvasElement;
      if (!canvas) return;
      try {
        this._chartInstance = new Chart(canvas.getContext("2d")!, finalConfig);
      } catch (err: any) {
        this._chartInstance = null;
        this._setError(err?.message || "Failed to render chart");
      }
      return;
    }

    // Datasource path: block.query + block.encoding
    if (this.block.query && this.block.encoding && this.dataSource) {
      this.loading = true;

      try {
        const result: QueryResult = await this.dataSource.query(this.block.query as any);

        this.loading = false;
        await this.updateComplete;

        const chartConfig = this._buildChartJsConfig(this.block.encoding, result.rows);

        if (hasDataUrl(chartConfig)) {
          this._setError("chart used a forbidden data.url");
          return;
        }
        if (checkRowCountExceeded(chartConfig)) {
          this._setError("chart exceeded 2000-row cap");
          return;
        }

        const canvas = this.querySelector("#chart-el") as HTMLCanvasElement;
        if (!canvas) return;
        const ctx = canvas.getContext("2d")!;
        this._chartInstance = new Chart(ctx, transformFinancialConfig(transformPayoffConfig(transformPnlConfig(transformWaterfallConfig(chartConfig)))));
        this.lastUpdated = Date.now();
      } catch (err: any) {
        console.error("Failed to render datasource chart:", err);
        this._setError(err.message || "Failed to query datasource or render chart");
      } finally {
        this.loading = false;
      }
      return;
    }

    if (this.block.query && this.block.encoding && !this.dataSource) {
      this._setError("Chart requires a dataSource but none is configured.");
      return;
    }

    // Deprecated spec path
    if (this.block.spec) {
      this._setError("Deprecated chart spec: use block.config (Chart.js config) instead.");
      return;
    }

    this._setError("Invalid chart block: missing config or query+encoding");
  }

  template() {
    if (this.error) {
      return html`
        <div class="error-card">
          <div class="error-title">⚠️ Chart Error</div>
          <div>${this.error}</div>
          <details>
            <summary>View Block JSON</summary>
            <pre>${JSON.stringify(this.block, null, 2)}</pre>
          </details>
        </div>
      `;
    }

    const containerClass = this.disabled ? "chart-container disabled" : "chart-container";

    if (this.loading) {
      return html`
        <div class=${containerClass}>
          ${this.block?.title ? html`<h3>${this.block.title}</h3>` : ""}
          <div style="padding:40px;text-align:center;color:var(--dragon-label-color, #888);">Loading chart data…</div>
        </div>
      `;
    }

    const hasRefresh = !!(this.block?.query && this.block?.encoding);

    return html`
        <div class=${containerClass}>
        ${this.block?.title ? html`<h3>${this.block.title}</h3>` : ""}
        <div class="chart-canvas">
          <canvas id="chart-el"></canvas>
        </div>
        ${hasRefresh ? this._renderRefreshControls() : ""}
      </div>
    `;
  }

  private _renderRefreshControls() {
    const modeLabel = this.mode === "auto" ? "Auto" : this.mode === "manual" ? "Manual" : "Off";
    const updatedStr = this.lastUpdated
      ? new Date(this.lastUpdated).toLocaleTimeString()
      : null;

    const indicatorClass = "mode-indicator " + this.mode;

    return html`
      <div class="refresh-controls">
        <span
          class=${indicatorClass}
          @click=${() => this._handleModeToggle()}
          title="Click to change refresh mode"
        >${modeLabel}</span>
        ${this.mode === "manual"
          ? html`<button class="refresh-btn" @click=${() => this._handleManualRefresh()}>Refresh</button>`
          : ""}
        ${updatedStr ? html`<span class="updated-stamp">Updated ${updatedStr}</span>` : ""}
      </div>
    `;
  }
}

if (!customElements.get("agent-chart-block")) {
  customElements.define("agent-chart-block", AgentChartBlock);
}

declare global {
  interface HTMLElementTagNameMap {
    "agent-chart-block": AgentChartBlock;
  }
}

