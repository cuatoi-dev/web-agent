import { z } from "zod";
import { ChartConfigSchema } from "../ui-blocks/chart-schema.js";
import { sanitizeChartConfig, hasDataUrl, checkRowCountExceeded, checkAxisIdMismatch } from "../ui-blocks/chart-spec.js";
import type { ToolContext, ToolOutcome, RenderableBlock } from "@dragon-ai/web-agent-core";

export const SHOW_CHART_SCHEMA = z
  .object({
    title: z.string().optional().describe("Optional chart title"),
    config: ChartConfigSchema.describe(
      'Chart.js 2.x config object. Call load_skill("chart") for shape, types, and examples.',
    ),
  })
  .strict();

export async function runShowChart(
  input: Record<string, unknown>,
  _ctx: ToolContext,
): Promise<ToolOutcome> {
  const { title, config } = input as { title?: string; config: unknown };

  const parseResult = ChartConfigSchema.safeParse(config);
  if (!parseResult.success) {
    const msg = parseResult.error.errors
      .map((e) => `config.${e.path.join(".") || "root"}: ${e.message}`)
      .join("; ");
    return { content: msg, isError: true };
  }

  // Check violations on the raw parsed config BEFORE sanitization, because
  // sanitizeChartConfig strips remote URLs and caps data lengths — those
  // hard limits must surface as errors to the model, not be silently fixed.
  if (hasDataUrl(parseResult.data)) {
    return {
      content:
        "config.data: external data URLs are not allowed; embed data values inline",
      isError: true,
    };
  }
  if (checkRowCountExceeded(parseResult.data)) {
    return {
      content:
        "config.data: a dataset exceeds the 2 000-row limit; reduce the dataset before charting",
      isError: true,
    };
  }

  const axisMismatch = checkAxisIdMismatch(parseResult.data);
  if (axisMismatch) {
    return { content: `config.${axisMismatch}`, isError: true };
  }

  const sanitized = sanitizeChartConfig(parseResult.data);

  const block: RenderableBlock = {
    type: "chart",
    ...(title ? { title: String(title) } : {}),
    config: sanitized,
  };

  return { content: "chart rendered", block };
}