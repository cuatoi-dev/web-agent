import { z } from "zod";
import type { DataQuery } from "@dragon-ai/web-agent-core";

// ── Chart.js config schema ──

export const ChartTypeSchema = z.enum([
  "line", "bar", "horizontalBar", "radar", "doughnut", "pie",
  "polarArea", "bubble", "scatter", "candlestick", "ohlc", "payoff",
  "equity", "drawdown", "waterfall",
]);
export type ChartType = z.infer<typeof ChartTypeSchema>;

export const ChartDatasetSchema = z.object({
  data: z.array(z.union([
    z.number(),
    z.string(),
    z.null(),
    z.object({ x: z.union([z.number(), z.string()]), y: z.union([z.number(), z.string()]), r: z.number().optional() }).passthrough(),
    z.object({
      x: z.union([z.number(), z.string()]),
      o: z.number(), h: z.number(), l: z.number(), c: z.number(),
    }).passthrough(),
  ])),
  label: z.string().optional(),
  backgroundColor: z.union([z.string(), z.array(z.string())]).optional(),
  borderColor: z.union([z.string(), z.array(z.string())]).optional(),
  borderWidth: z.number().optional(),
  fill: z.boolean().optional(),
  type: z.string().optional(),
}).passthrough();
export type ChartDataset = z.infer<typeof ChartDatasetSchema>;

export const ChartDataSchema = z.object({
  labels: z.array(z.union([z.string(), z.number()])).optional(),
  datasets: z.array(ChartDatasetSchema).max(50),
}).passthrough();
export type ChartData = z.infer<typeof ChartDataSchema>;

export const ChartConfigSchema = z.object({
  type: ChartTypeSchema,
  data: ChartDataSchema,
  options: z.record(z.any()).optional(),
}).passthrough();
export type ChartConfig = z.infer<typeof ChartConfigSchema>;

// ── Chart refresh ──

export const ChartRefreshModeSchema = z.enum(["auto", "manual", "off"]);
export type ChartRefreshMode = z.infer<typeof ChartRefreshModeSchema>;

export const ChartRefreshSchema = z.object({
  mode: ChartRefreshModeSchema,
  intervalMs: z.number().int().positive().optional(),
});
export type ChartRefresh = z.infer<typeof ChartRefreshSchema>;

// ── Base chart block ──

const ChartBlockBase = z.object({
  type: z.literal("chart"),
  title: z.string().optional(),
  /** @deprecated Use `config` instead. */
  spec: z.record(z.any()).optional(),
  config: ChartConfigSchema.optional(),
  query: z.record(z.any()).optional(),
  /** @deprecated Use `config` instead. */
  encoding: z.record(z.any()).optional(),
  refresh: ChartRefreshSchema.optional(),
});

export const ChartBlockSchema = ChartBlockBase.refine(
  (val) => {
    const hasSpec = "spec" in val && val.spec !== undefined;
    const hasConfig = "config" in val && val.config !== undefined;
    const hasQuery = "query" in val && val.query !== undefined;
    return hasSpec || hasConfig || hasQuery;
  },
  {
    message:
      "ChartBlock must have one of: 'spec' (deprecated), 'config' (Chart.js), or 'query' (datasource).",
  }
);

export const ChartBlockDiscriminant = ChartBlockBase;

export interface ChartBlock {
  type: "chart";
  title?: string;
  /** @deprecated Use `config` instead. */
  spec?: object;
  config?: ChartConfig;
  query?: DataQuery;
  /** @deprecated Use `config` instead. */
  encoding?: Record<string, any>;
  refresh?: {
    mode: "auto" | "manual" | "off";
    intervalMs?: number;
  };
  [key: string]: unknown;
}
