// ── Chart.js config sanitizer ──

export function hasDataUrl(obj: any): boolean {
  if (!obj || typeof obj !== "object") return false;

  // Check Chart.js config structure: data.datasets[i].url
  if ("data" in obj && obj.data && typeof obj.data === "object") {
    const data = obj.data;
    if ("url" in data && data.url) return true;
    if (Array.isArray(data.datasets)) {
      for (const ds of data.datasets) {
        if (ds && typeof ds === "object" && "url" in ds && ds.url) return true;
      }
    }
  }

  // Generic recursive check (also captures nested Vega structures)
  for (const key of Object.keys(obj)) {
    if (hasDataUrl(obj[key])) return true;
  }
  return false;
}

export function checkRowCountExceeded(obj: any): boolean {
  let exceeded = false;
  function check(val: any) {
    if (exceeded) return;
    if (!val || typeof val !== "object") return;

    // Chart.js config: config.data.datasets[i].data length
    if ("data" in val && val.data && typeof val.data === "object") {
      const data = val.data;
      if (Array.isArray(data.datasets)) {
        for (const ds of data.datasets) {
          if (ds && typeof ds === "object" && Array.isArray(ds.data) && ds.data.length > 2000) {
            exceeded = true;
            return;
          }
        }
      }
      if (Array.isArray(data.values) && data.values.length > 2000) {
        exceeded = true;
        return;
      }
    }

    // Generic dataset check (backward compat with Vega)
    if ("datasets" in val && val.datasets && typeof val.datasets === "object") {
      for (const k of Object.keys(val.datasets)) {
        const ds = val.datasets[k];
        if (Array.isArray(ds) && ds.length > 2000) {
          exceeded = true;
          return;
        }
      }
    }

    for (const k of Object.keys(val)) {
      check(val[k]);
    }
  }
  check(obj);
  return exceeded;
}

export function checkAxisIdMismatch(config: any): string | null {
  if (!config || typeof config !== "object") return null;
  const datasets = config?.data?.datasets;
  if (!Array.isArray(datasets)) return null;

  const xIds = new Set(
    (config?.options?.scales?.xAxes ?? [])
      .map((a: any) => a?.id)
      .filter((id: any) => typeof id === "string"),
  );
  const yIds = new Set(
    (config?.options?.scales?.yAxes ?? [])
      .map((a: any) => a?.id)
      .filter((id: any) => typeof id === "string"),
  );

  for (let i = 0; i < datasets.length; i++) {
    const ds = datasets[i];
    if (!ds || typeof ds !== "object") continue;
    if (typeof ds.xAxisID === "string" && !xIds.has(ds.xAxisID)) {
      return `data.datasets[${i}].xAxisID: "${ds.xAxisID}" is not defined in options.scales.xAxes`;
    }
    if (typeof ds.yAxisID === "string" && !yIds.has(ds.yAxisID)) {
      return `data.datasets[${i}].yAxisID: "${ds.yAxisID}" is not defined in options.scales.yAxes`;
    }
  }
  return null;
}

export function sanitizeChartConfig(config: any): any {
  if (!config || typeof config !== "object") return config;

  // Deep clone via JSON (strips functions/callbacks/Symbols automatically)
  const cloned = JSON.parse(JSON.stringify(config));

  function clean(val: any) {
    if (!val || typeof val !== "object") return;

    // Block remote data.url
    if ("url" in val && typeof val.url === "string" && val.url.startsWith("http")) {
      delete val.url;
    }

    // Cap datasets at 50
    if ("datasets" in val && Array.isArray(val.datasets) && val.datasets.length > 50) {
      val.datasets = val.datasets.slice(0, 50);
    }

    // Cap each dataset's data array at 2000
    if ("data" in val && Array.isArray(val.data) && val.data.length > 2000) {
      val.data = val.data.slice(0, 2000);
    }

    for (const k of Object.keys(val)) {
      clean(val[k]);
    }
  }

  clean(cloned);
  return cloned;
}

const FINANCIAL_TYPES = new Set(["candlestick", "ohlc"]);

/** Rewrite a candlestick/ohlc config → native scatter carrier + stashed _ohlc.
 *  Pure & idempotent; returns the config unchanged for any other type. */
export function transformFinancialConfig(config: any): any {
  if (!config || typeof config !== "object" || !FINANCIAL_TYPES.has(config.type)) {
    return config;
  }
  const kind = config.type; // "candlestick" | "ohlc"
  const out = { ...config, type: "scatter" };
  out.data = { ...(config.data ?? {}) };
  out.data.datasets = (config.data?.datasets ?? []).map((ds: any) => {
    const ohlc = Array.isArray(ds?.data) ? ds.data : [];
    // Hidden carrier points: feed every high & low to the y-scale so it ranges
    // over the full candle extent; x carries the timestamp/category value.
    const carrier: any[] = [];
    for (const d of ohlc) {
      if (d && typeof d === "object" && "h" in d && "l" in d) {
        carrier.push({ x: d.x, y: d.h });
        carrier.push({ x: d.x, y: d.l });
      }
    }
    return {
      ...ds,
      _ohlc: ohlc,        // survives JSON-clone sanitize (plain data)
      _finKind: kind,     // "candlestick" | "ohlc"
      data: carrier,
      showLine: false,
      pointRadius: 0,     // carrier invisible; plugin draws the candles
      pointHitRadius: 0,
    };
  });
  return out;
}

export type OptionLeg = {
  kind: "call" | "put";
  strike: number;
  premium: number;
  qty?: number;                 // default 1
  side?: "long" | "short";      // default "long"
};

/** P/L at expiry for one leg at underlying price S. long = +(intrinsic - premium),
 *  short = -(intrinsic - premium), scaled by qty. */
function legPnl(leg: OptionLeg, S: number): number {
  const qty = leg.qty ?? 1;
  const sign = (leg.side ?? "long") === "short" ? -1 : 1;
  const intrinsic = leg.kind === "put"
    ? Math.max(0, leg.strike - S)
    : Math.max(0, S - leg.strike);
  return sign * (intrinsic - leg.premium) * qty;
}

/** Total strategy P/L at price S (sum of legs). */
export function payoffAt(legs: OptionLeg[], S: number): number {
  let sum = 0;
  for (const leg of legs) sum += legPnl(leg, S);
  return sum;
}

export interface PayoffSeries {
  points: { x: number; y: number }[]; // piecewise-linear vertices, x ascending
  breakevens: number[];               // ascending zero-crossings within range
  strikes: number[];                  // sorted unique leg strikes
  minY: number;
  maxY: number;
}

/** Build the payoff curve, breakevens and strikes from option legs across a price
 *  range. Vertices sit at every strike inside the range plus the two endpoints, so
 *  the returned points reproduce the exact piecewise-linear payoff. */
export function payoffSeries(
  legs: OptionLeg[],
  range?: [number, number],
): PayoffSeries {
  const strikes = Array.from(new Set(legs.map((l) => l.strike))).sort((a, b) => a - b);
  // Auto range: pad 30% below min strike / above max strike (fallback 0..100).
  let [lo, hi] = range ?? [];
  if (lo === undefined || hi === undefined) {
    const kMin = strikes[0] ?? 0;
    const kMax = strikes[strikes.length - 1] ?? 100;
    const pad = Math.max(1, (kMax - kMin) * 0.3 || kMax * 0.3 || 10);
    lo = Math.max(0, kMin - pad);
    hi = kMax + pad;
  }
  if (hi <= lo) hi = lo + 1;
  const xs = Array.from(new Set([lo, ...strikes.filter((k) => k > lo && k < hi), hi]))
    .sort((a, b) => a - b);
  const points = xs.map((x) => ({ x, y: payoffAt(legs, x) }));
  const breakevens: number[] = [];
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i];
    if ((a.y <= 0 && b.y > 0) || (a.y >= 0 && b.y < 0) || (a.y === 0)) {
      if (a.y === 0) { breakevens.push(a.x); continue; }
      const t = a.y / (a.y - b.y);           // exact for a linear segment
      breakevens.push(a.x + t * (b.x - a.x));
    }
  }
  const ys = points.map((p) => p.y);
  return { points, breakevens, strikes, minY: Math.min(0, ...ys), maxY: Math.max(0, ...ys) };
}

const PROFIT_FILL = "rgba(38,166,154,0.10)";  // green band
const LOSS_FILL   = "rgba(239,83,80,0.10)";   // red band
const LINE_COLOR  = "#37474f";                 // payoff line
const ZERO_COLOR  = "#888";
const STRIKE_COLOR = "#9e9e9e";
const BE_COLOR    = "#455a64";

/** Rewrite a payoff config → scatter line + reference-line/box annotations.
 *  Pure; returns the config unchanged for any other type. */
export function transformPayoffConfig(config: any): any {
  if (!config || typeof config !== "object" || config.type !== "payoff") return config;
  const p = config.options?.payoff ?? {};
  const legs: OptionLeg[] = Array.isArray(p.legs) ? p.legs : [];

  // Source the curve: legs → compute, else the first dataset's / payoff.points data.
  let points: { x: number; y: number }[];
  let breakevens: number[];
  let strikes: number[];
  let minY: number, maxY: number;
  if (legs.length > 0) {
    const s = payoffSeries(legs, p.priceRange);
    ({ points, breakevens, strikes, minY, maxY } = s);
  } else {
    const raw = Array.isArray(p.points) ? p.points
      : (config.data?.datasets?.[0]?.data ?? []);
    points = raw
      .map((d: any) => ({ x: Number(d.x), y: Number(d.y) }))
      .filter((d: any) => isFinite(d.x) && isFinite(d.y))
      .sort((a: any, b: any) => a.x - b.x);
    breakevens = [];
    for (let i = 1; i < points.length; i++) {
      const a = points[i - 1], b = points[i];
      if (a.y === 0) { breakevens.push(a.x); continue; }
      if ((a.y < 0 && b.y > 0) || (a.y > 0 && b.y < 0)) {
        breakevens.push(a.x + (a.y / (a.y - b.y)) * (b.x - a.x));
      }
    }
    strikes = Array.isArray(p.strikes) ? p.strikes : [];
    const ys = points.map((d) => d.y);
    minY = Math.min(0, ...(ys.length ? ys : [0]));
    maxY = Math.max(0, ...(ys.length ? ys : [0]));
  }

  const xMin = points.length ? points[0].x : 0;
  const xMax = points.length ? points[points.length - 1].x : 1;

  // Region boxes: partition [xMin..xMax] at breakevens; color by sign at midpoint.
  const bounds = [xMin, ...breakevens.filter((b) => b > xMin && b < xMax), xMax];
  const boxes: any[] = [];
  for (let i = 1; i < bounds.length; i++) {
    const from = bounds[i - 1], to = bounds[i];
    const mid = (from + to) / 2;
    const y = legs.length > 0 ? payoffAt(legs, mid) : yAtPoints(points, mid);
    boxes.push({ axis: "x", from, to, color: y >= 0 ? PROFIT_FILL : LOSS_FILL });
  }
  const lines: any[] = [{ axis: "y", value: 0, color: ZERO_COLOR }];
  for (const k of strikes) lines.push({ axis: "x", value: k, color: STRIKE_COLOR, dash: [4, 4], label: `K ${k}` });
  for (const be of breakevens) lines.push({ axis: "x", value: be, color: BE_COLOR, dash: [2, 2], label: `BE ${Number(be.toFixed(2))}` });

  const out: any = { ...config, type: "scatter" };
  out.data = { ...(config.data ?? {}) };
  out.data.datasets = [{
    label: config.data?.datasets?.[0]?.label ?? "Payoff",
    data: points,
    showLine: true,
    fill: false,
    borderColor: LINE_COLOR,
    borderWidth: 2,
    pointRadius: 0,
    pointHitRadius: 0,
    lineTension: 0,
  }];
  out.options = { ...(config.options ?? {}) };
  // Merge auto annotations under any agent-supplied ones (agent wins on conflict).
  const existing = out.options.annotation ?? {};
  out.options.annotation = {
    lines: [...lines, ...(existing.lines ?? [])],
    boxes: [...boxes, ...(existing.boxes ?? [])],
  };
  // Guarantee 0 is visible on the y-axis.
  out.options.scales = { ...(out.options.scales ?? {}) };
  out.options.scales.yAxes = [{ ticks: { suggestedMin: minY, suggestedMax: maxY } }];
  delete out.options.payoff; // consumed
  return out;
}

/** Linear-interpolate y at price S over ascending {x,y} points (for the points path). */
function yAtPoints(points: { x: number; y: number }[], S: number): number {
  if (points.length === 0) return 0;
  if (S <= points[0].x) return points[0].y;
  if (S >= points[points.length - 1].x) return points[points.length - 1].y;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i];
    if (S >= a.x && S <= b.x) {
      const t = (S - a.x) / (b.x - a.x || 1);
      return a.y + t * (b.y - a.y);
    }
  }
  return points[points.length - 1].y;
}

// ── P&L / equity curve + drawdown (072-4) ──

/** Cumulative running total of per-period P&L. y_i = start + Σ returns[0..i].
 *  x_i = xs?.[i] (numeric, or ISO/date string → ms) else the index i. */
export function cumulativeSeries(
  returns: number[],
  opts?: { x?: (number | string)[]; start?: number },
): { x: number; y: number }[] {
  const start = opts?.start ?? 0;
  const out: { x: number; y: number }[] = [];
  let acc = start;
  for (let i = 0; i < returns.length; i++) {
    acc += Number(returns[i]) || 0;
    out.push({ x: xToNum(opts?.x?.[i], i), y: acc });
  }
  return out;
}

/** ISO/date string → ms; finite number → itself; else the fallback index. */
function xToNum(x: number | string | undefined, index: number): number {
  if (typeof x === "string") { const t = Date.parse(x); return isFinite(t) ? t : index; }
  if (typeof x === "number" && isFinite(x)) return x;
  return index;
}

/** Normalize a returns[] / equity[] / points[] source into a numeric {x,y} level
 *  series. temporal=true when any supplied x was a date-like string (→ time axis). */
export function pnlSeries(src: {
  returns?: number[]; equity?: number[]; points?: { x: any; y: any }[];
  x?: (number | string)[]; start?: number;
}): { points: { x: number; y: number }[]; temporal: boolean } {
  const xs = src.x;
  const temporal =
    (Array.isArray(xs) && xs.some((v) => typeof v === "string")) ||
    (Array.isArray(src.points) && src.points.some((p) => typeof p?.x === "string"));
  let points: { x: number; y: number }[];
  if (Array.isArray(src.equity)) {
    points = src.equity.map((y, i) => ({ x: xToNum(xs?.[i], i), y: Number(y) }));
  } else if (Array.isArray(src.returns)) {
    points = cumulativeSeries(src.returns, { x: xs, start: src.start });
  } else if (Array.isArray(src.points)) {
    points = src.points.map((p, i) => ({ x: xToNum(p?.x ?? xs?.[i], i), y: Number(p?.y) }));
  } else {
    points = [];
  }
  return { points: points.filter((p) => isFinite(p.x) && isFinite(p.y)), temporal };
}

/** Split a level series at the zero line for signed area fill. Inserts an
 *  interpolated y=0 vertex at every strict sign change so the green (≥0) and red
 *  (≤0) fills meet exactly on the baseline. Returns the augmented line plus the two
 *  clamped carrier series (positive = max(y,0), negative = min(y,0)). */
export function splitAtZero(points: { x: number; y: number }[]): {
  line: { x: number; y: number }[];
  positive: { x: number; y: number }[];
  negative: { x: number; y: number }[];
} {
  const line: { x: number; y: number }[] = [];
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    if (i > 0) {
      const a = points[i - 1];
      if (a.y * p.y < 0) {                       // strict sign change → insert crossing
        const t = a.y / (a.y - p.y);             // exact for a linear segment
        line.push({ x: a.x + t * (p.x - a.x), y: 0 });
      }
    }
    line.push({ x: p.x, y: p.y });
  }
  return {
    line,
    positive: line.map((p) => ({ x: p.x, y: Math.max(p.y, 0) })),
    negative: line.map((p) => ({ x: p.x, y: Math.min(p.y, 0) })),
  };
}

/** Running high-water mark of a level series. */
export function runningPeak(ys: number[]): number[] {
  const out: number[] = [];
  let peak = -Infinity;
  for (const y of ys) { peak = Math.max(peak, y); out.push(peak); }
  return out;
}

/** Underwater / drawdown from a level series. Absolute: dd = level − peak (≤0).
 *  percent: (level/peak − 1)·100 when peak>0, else 0. */
export function drawdownSeries(
  points: { x: number; y: number }[],
  opts?: { percent?: boolean },
): { x: number; y: number }[] {
  const peaks = runningPeak(points.map((p) => p.y));
  return points.map((p, i) => {
    const peak = peaks[i];
    const y = opts?.percent
      ? (peak > 0 ? (p.y / peak - 1) * 100 : 0)
      : (p.y - peak);
    return { x: p.x, y };
  });
}

const PNL_TYPES = new Set(["equity", "drawdown"]);
const EQUITY_LINE = "#37474f";                    // neutral equity line over the split fill
const POS_FILL    = "rgba(38,166,154,0.15)";      // green (profit) band
const NEG_FILL    = "rgba(239,83,80,0.15)";       // red (loss) band
const DD_LINE     = "#ef5350";                     // drawdown outline
const DD_FILL     = "rgba(239,83,80,0.20)";        // underwater fill
const PNL_ZERO    = "#888";                         // zero baseline / high-water line

/** Rewrite an equity/drawdown config → scatter line(s) + zero-line annotation.
 *  Pure; returns the config unchanged for any other type. */
export function transformPnlConfig(config: any): any {
  if (!config || typeof config !== "object" || !PNL_TYPES.has(config.type)) return config;
  const p = config.options?.pnl ?? {};
  const { points, temporal } = pnlSeries({
    returns: p.returns,
    equity: p.equity,
    points: Array.isArray(p.points) ? p.points : config.data?.datasets?.[0]?.data,
    x: p.x,
    start: p.start,
  });

  const out: any = { ...config, type: "scatter" };
  out.data = { ...(config.data ?? {}) };
  out.options = { ...(config.options ?? {}) };

  let ys: number[];
  if (config.type === "drawdown") {
    const dd = drawdownSeries(points, { percent: !!p.percent });
    ys = dd.map((d) => d.y);
    out.data.datasets = [{
      label: config.data?.datasets?.[0]?.label ?? (p.percent ? "Drawdown %" : "Drawdown"),
      data: dd, showLine: true, fill: "origin",
      borderColor: DD_LINE, backgroundColor: DD_FILL, borderWidth: 1.5,
      pointRadius: 0, pointHitRadius: 0, lineTension: 0,
    }];
  } else { // equity
    const { line, positive, negative } = splitAtZero(points);
    ys = line.map((d) => d.y);
    out.data.datasets = [
      { label: "", data: positive, showLine: true, fill: "origin",
        backgroundColor: POS_FILL, borderColor: "transparent", borderWidth: 0,
        pointRadius: 0, pointHitRadius: 0, lineTension: 0 },
      { label: "", data: negative, showLine: true, fill: "origin",
        backgroundColor: NEG_FILL, borderColor: "transparent", borderWidth: 0,
        pointRadius: 0, pointHitRadius: 0, lineTension: 0 },
      { label: config.data?.datasets?.[0]?.label ?? "Equity", data: line, showLine: true,
        fill: false, borderColor: EQUITY_LINE, borderWidth: 2,
        pointRadius: 0, pointHitRadius: 0, lineTension: 0 },
    ];
  }

  // Zero baseline (drawdown: the high-water mark). Merge under agent-supplied lines.
  const existing = out.options.annotation ?? {};
  out.options.annotation = {
    lines: [{ axis: "y", value: 0, color: PNL_ZERO }, ...(existing.lines ?? [])],
    boxes: [...(existing.boxes ?? [])],
  };

  // y-range includes 0 + the data extremes; PRESERVE any supplied xAxes (temporal).
  const yMin = Math.min(0, ...(ys.length ? ys : [0]));
  const yMax = Math.max(0, ...(ys.length ? ys : [0]));
  out.options.scales = { ...(out.options.scales ?? {}) };
  out.options.scales.yAxes = [{ ticks: { suggestedMin: yMin, suggestedMax: yMax } }];
  if (temporal && !out.options.scales.xAxes) out.options.scales.xAxes = [{ type: "time" }];

  // Equity draws 3 datasets (2 are internal fill carriers) → hide the legend by default.
  out.options.legend = { ...(out.options.legend ?? {}) };
  if (config.type === "equity" && out.options.legend.display === undefined) {
    out.options.legend.display = false;
  }
  delete out.options.pnl; // consumed
  return out;
}

// ── Waterfall / P&L bridge (072-5) ──

export interface WaterfallStep {
  label: string;
  value: number;          // signed delta; ignored when isTotal
  isTotal?: boolean;      // render a full 0..cumulative "total" bar instead of a delta
}

export interface WaterfallBar {
  label: string;
  base: number;           // transparent carrier height
  delta: number;          // visible segment height (always ≥ 0)
  cumulative: number;     // running total AFTER this step
  kind: "increase" | "decrease" | "total";
}

/** Compute per-bar base/delta/color inputs for a waterfall from signed step
 *  deltas. Rising step → base=prev, delta=value; falling step → base=prev+value,
 *  delta=|value| (the visible bar hangs down from prev). A total step (isTotal or
 *  the auto total) spans 0..cumulative. Pure. */
export function waterfallSeries(
  steps: WaterfallStep[],
  opts?: { start?: number; total?: boolean | string },
): { bars: WaterfallBar[]; labels: string[]; total: number } {
  const bars: WaterfallBar[] = [];
  let running = opts?.start ?? 0;
  for (const s of steps) {
    if (s.isTotal) {
      bars.push({ label: s.label, base: 0, delta: running, cumulative: running, kind: "total" });
      continue;
    }
    const v = Number(s.value) || 0;
    const prev = running;
    running = prev + v;
    if (v >= 0) bars.push({ label: s.label, base: prev, delta: v, cumulative: running, kind: "increase" });
    else bars.push({ label: s.label, base: running, delta: -v, cumulative: running, kind: "decrease" });
  }
  if (opts?.total) {
    const label = typeof opts.total === "string" ? opts.total : "Total";
    bars.push({ label, base: 0, delta: running, cumulative: running, kind: "total" });
  }
  return { bars, labels: bars.map((b) => b.label), total: running };
}

const WF_UP    = "#26a69a";                    // increase (green)
const WF_DOWN  = "#ef5350";                    // decrease (red)
const WF_TOTAL = "#546e7a";                    // total (neutral blue-grey)
const WF_TOTAL_LINE = "#546e7a";

/** Rewrite a waterfall config → native stacked bar (transparent base carrier +
 *  colored delta series). Optional total reference line reuses the existing
 *  annotation primitive. Pure; no-op for any other type. */
export function transformWaterfallConfig(config: any): any {
  if (!config || typeof config !== "object" || config.type !== "waterfall") return config;
  const w = config.options?.waterfall ?? {};
  const steps: WaterfallStep[] = Array.isArray(w.steps) ? w.steps : [];
  const { bars, labels, total } = waterfallSeries(steps, { start: w.start, total: w.total });

  const colors = bars.map((b) =>
    b.kind === "total" ? WF_TOTAL : b.kind === "increase" ? WF_UP : WF_DOWN);

  const out: any = { ...config, type: "bar" };
  out.data = { ...(config.data ?? {}) };
  out.data.labels = labels;
  out.data.datasets = [
    { label: "", data: bars.map((b) => b.base),
      backgroundColor: "rgba(0,0,0,0)", borderColor: "rgba(0,0,0,0)", borderWidth: 0 },
    { label: config.data?.datasets?.[0]?.label ?? "Bridge",
      data: bars.map((b) => b.delta), backgroundColor: colors, borderWidth: 0 },
  ];

  out.options = { ...(config.options ?? {}) };
  out.options.scales = { ...(out.options.scales ?? {}) };
  out.options.scales.xAxes = [{ stacked: true, ...(out.options.scales.xAxes?.[0] ?? {}) }];
  out.options.scales.yAxes = [{ stacked: true, ...(out.options.scales.yAxes?.[0] ?? {}) }];

  // Base dataset is an internal carrier → hide legend by default.
  out.options.legend = { display: false, ...(out.options.legend ?? {}) };

  // Optional total reference line — reuses financePlugin's annotation primitive.
  if (w.showTotalLine) {
    const existing = out.options.annotation ?? {};
    out.options.annotation = {
      lines: [{ axis: "y", value: total, color: WF_TOTAL_LINE, dash: [4, 4], label: `Total ${total}` },
              ...(existing.lines ?? [])],
      boxes: [...(existing.boxes ?? [])],
    };
  }
  delete out.options.waterfall; // consumed
  return out;
}

