# @dragon-ai/web-agent-core

Framework-agnostic core for the web-agent in-app browser agent: the agent loop,
tool and skill definitions, datasource registry, and provider transports.

No UI. This package renders nothing — pair it with
[`@dragon-ai/web-agent-lit`](../web-agent-lit) for the chat interface.

## Install

```bash
pnpm add @dragon-ai/web-agent-core
```

## Usage

```ts
import {
  createPageAgent,
  ContextManager,
  buildTools,
  coreSkills,
} from "@dragon-ai/web-agent-core";

const agent = createPageAgent(config, toolContext, new ContextManager(/* … */));
```

The package is ESM-only (`"type": "module"`) and targets ES2022 with the DOM
libs — it is built to run in the browser.

## License

Apache-2.0
