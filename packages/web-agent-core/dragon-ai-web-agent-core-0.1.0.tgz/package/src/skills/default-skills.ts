import type { SkillDef } from "../tools/build-tools.js";

export const DEFAULT_SKILLS: SkillDef[] = [
  {
    name: "query_data_advanced",
    description: "Guide for complex data queries: filters, aggregation, sorting, and pagination.",
    definition: `# query_data_advanced

Use \`query_data\` for all tabular reads. First call \`list_data_sources\` to see available sources and their schemas.

## Filters (MongoDB-style)
- Exact match shorthand: \`{ status: "delivered" }\`
- Range: \`{ total: { $gt: 10, $lt: 100 } }\`
- Logical: \`{ $and: [{ status: "delivered" }, { total: { $gt: 50 } }] }\`
- Negation: \`{ status: { $ne: "cancelled" } }\`

## Aggregation
Pass an \`aggregation\` block with:
- \`groupBy\`: array of dimension field names
- Date dimensions accept \`granularity\`: minute/hour/day/week/month/quarter/year (e.g. \`{ "field": "ts", "granularity": "hour" }\`)
- \`measures\`: array of \`{ field, op }\` where op is count/sum/avg/min/max/countDistinct/first/last (first/last = open/close within each group, ordered by the group's date dimension)
- Optional: \`having\`, \`sort\`, \`limit\`

Example: total revenue per category, top 5:
\`\`\`json
{
  "source": "orders",
  "aggregation": {
    "groupBy": ["category"],
    "measures": [{ "field": "total", "op": "sum" }],
    "sort": [{ "field": "total", "dir": "desc" }],
    "limit": 5
  }
}
\`\`\`

## Pagination
Use \`offset\` and \`limit\` for large result sets.
`,
  },
  {
    name: "present_to_user",
    description:
      "How to present rich UI to the user — when and how to call show_chart and " +
      "show_generative_ui (charts, buttons, forms) with the intent→render→confirm pattern.",
    definition: `# Presenting rich UI to the user

Use the present_to_user tools instead of writing markdown tables or fenced blocks.

## Tools
- **show_chart({title?, config})** — Chart.js chart. Call \`load_skill("chart")\`
  first for the config shape, type rules, and worked examples.
- **show_generative_ui(spec)** — type:"buttons" (≤6 {label, prompt} quick replies)
  or type:"form" ({id, fields:[{kind,name,label,...}], submit_label}).

## Pattern (interleaves text and UI in one turn)
1. Send a short line: what you're about to show.
2. Call the tool (the block renders inline at that point).
3. Send a brief closing line.

## On error
The tool returns a precise field-path error when the spec is invalid. Read it,
fix the offending field, and call the tool again. Do NOT fall back to fenced
blocks or markdown.`,
  },
  {
    name: "multi_step_ui",
    description: "How to handle multi-step UI interactions and recover from stale snapshot refs.",
    definition: `# multi_step_ui

## The snapshot → act → verify cycle
1. Always call \`snapshot_page\` before any click/fill/select_option.
2. Refs (e.g. [12]) are only valid from the **most recent** snapshot (check the generation number).
3. After an action that changes the page, call \`wait_for\` then \`snapshot_page\` again before claiming success.

## Stale ref recovery
If a tool returns "ref not found" or "stale snapshot":
1. Re-run \`snapshot_page\` to get fresh refs.
2. Locate the target element in the new snapshot.
3. Retry the action with the new ref.

## Multi-step form flows
- Snapshot the initial state.
- Fill fields one by one; each fill does not need a re-snapshot unless the page re-renders.
- After the final submit/click, always wait_for + snapshot to confirm the outcome.
- Never claim a form was submitted without verifying the success state.
`,
  },
];

export function coreSkills(): SkillDef[] {
  return DEFAULT_SKILLS;
}
