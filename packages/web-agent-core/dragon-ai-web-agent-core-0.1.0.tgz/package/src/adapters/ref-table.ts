// ref-table.ts — numbered-ref ↔ DOM-element registry.
// Each new snapshot bumps the generation and invalidates all prior refs.
// Pure DOM/TS; no loop or SDK imports (§3).

// ---------------------------------------------------------------------------
// ResolveResult discriminated union (§5.1 S2 + §10 matrix)
// ---------------------------------------------------------------------------
export type ResolveResult =
  | { status: "ok"; el: Element; generation: number }
  // ref exists conceptually but from a prior generation (tracked via lastSeenGeneration)
  | { status: "stale"; fromGeneration: number; generation: number }
  // WeakRef cleared or element not connected to document
  | { status: "detached" }
  // never assigned in current generation and no prior record
  | { status: "unknown" };

// ---------------------------------------------------------------------------
// Internal per-ref record
// ---------------------------------------------------------------------------
interface RefEntry {
  /** Weak reference to the element — avoids leaking DOM nodes. */
  weakRef: WeakRef<Element>;
  /** The generation in which this ref was assigned. */
  fromGeneration: number;
}

// ---------------------------------------------------------------------------
// RefTable
// ---------------------------------------------------------------------------
export class RefTable {
  #generation = 0;
  /** Current-generation map: ref → entry. */
  #map = new Map<number, RefEntry>();
  /** Cross-generation: ref number → last known generation it was assigned in.
   *  Kept small — entries are added on assign, cleared indirectly via WeakRef
   *  (no explicit cleanup needed; stale entries just cause "stale" instead of "unknown"). */
  #lastSeenGeneration = new Map<number, number>();
  /** Monotonic ref counter (resets to 1 each generation). */
  #nextRef = 1;

  // -----------------------------------------------------------------------
  // Public API
  // -----------------------------------------------------------------------

  /** Current generation number (monotonically increasing). */
  get generation(): number {
    return this.#generation;
  }

  /** Bump generation, clear current map, reset ref counter.
   *  Returns the new generation number.
   *  Called by dom-adapter at the start of each snapshot (task 007). */
  invalidateAll(): number {
    this.#generation++;
    this.#map.clear();
    this.#nextRef = 1;
    return this.#generation;
  }

  /** Assign a ref to `el`. Returns the numeric ref (1-based per generation). */
  assign(el: Element): number {
    const ref = this.#nextRef++;
    const entry: RefEntry = {
      weakRef: new WeakRef(el),
      fromGeneration: this.#generation,
    };
    this.#map.set(ref, entry);
    this.#lastSeenGeneration.set(ref, this.#generation);
    return ref;
  }

  /** Resolve a ref. Accepts `number | string`; coerce non-numeric → unknown. */
  resolve(ref: number | string): ResolveResult {
    // Accept "7" → 7; non-numeric string → unknown.
    const num = typeof ref === "string" ? Number(ref) : ref;
    if (!Number.isFinite(num) || num < 1 || Math.floor(num) !== num) {
      return { status: "unknown" };
    }

    const entry = this.#map.get(num);

    if (entry) {
      // Ref exists in current generation.
      const el = entry.weakRef.deref();
      if (!el || !el.isConnected) {
        return { status: "detached" };
      }
      return { status: "ok", el, generation: this.#generation };
    }

    // Not in current map — check cross-generation history.
    const lastGen = this.#lastSeenGeneration.get(num);
    if (lastGen !== undefined && lastGen < this.#generation) {
      return {
        status: "stale",
        fromGeneration: lastGen,
        generation: this.#generation,
      };
    }

    return { status: "unknown" };
  }
}
