// dom-adapter.ts — builds accessibility-style DOM snapshots with numbered refs.
// Pure DOM/TS; no loop or SDK imports (§3).

import { RefTable } from "./ref-table.js";
import { staleRef, detachedRef, disabledRef, selectOptionMissing } from "../tools/error-messages.js";
import { downscaleImage, DEFAULT_IMAGE_LIMITS, type ImageLimits } from "../utils/image.js";
import * as htmlToImage from "html-to-image";
import type { CueKind } from "../config.js";
import { resolveAgentPermission, type ConfirmInteractionFn } from "./permission-resolver.js";

/** Await-able hook fired by the adapter before a synthetic event is
 *  dispatched. Resolves after any cue animation completes. */
export type ActionCueFn = (
  el: Element | undefined,
  kind: CueKind,
  detail?: {
    value?: string;
    speedMs?: number;
    point?: { x: number; y: number };
    rect?: { x: number; y: number; width: number; height: number };
  },
) => Promise<void>;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
export interface SnapshotInput {
  scope?: string;
  interactive_only?: boolean;
}

export interface DomAdapterOptions {
  refTable?: RefTable;
  root?: ParentNode;
  snapshotMaxChars?: number;
  /** Hard cap on significant-nesting depth emitted per snapshot. Default 12. */
  snapshotMaxDepth?: number;
  /** Max significant descendants a single node may emit before the rest of
   *  its subtree collapses into a drillable marker. Default 50. */
  snapshotSubtreeMaxNodes?: number;
  /** Overall cap on significant lines emitted per snapshot. Default 400. */
  snapshotMaxNodes?: number;
  agentUiSelector?: string;
  /** Confirmation hook for "ask" permission tier. */
  confirmInteraction?: ConfirmInteractionFn;
  /** Limits applied to a rendered screenshot before it leaves the adapter. */
  imageLimits?: ImageLimits;
  /** Visual action-cue hook. Optional; if unset no cue is fired. */
  actionCue?: ActionCueFn;
  /** ms-per-word typing pace supplier. Undefined/0 ⇒ instant set. */
  typingPaceMs?: () => number;
}

// ---------------------------------------------------------------------------
// Implicit ARIA role mapping (pragmatic subset per §5.1 S1)
// ---------------------------------------------------------------------------
const TAG_ROLES: Record<string, string> = {
  nav: "navigation",
  main: "main",
  header: "banner",
  footer: "contentinfo",
  aside: "complementary",
  section: "region",
  article: "article",
  form: "form",
  table: "table",
  ul: "list",
  ol: "list",
  li: "listitem",
  dialog: "dialog",
  h1: "heading",
  h2: "heading",
  h3: "heading",
  h4: "heading",
  h5: "heading",
  h6: "heading",
  img: "img",
  select: "combobox",
  textarea: "textbox",
  button: "button",
};

const INPUT_TYPE_ROLES: Record<string, string> = {
  text: "textbox",
  search: "searchbox",
  email: "textbox",
  url: "textbox",
  tel: "textbox",
  number: "spinbutton",
  password: "textbox",
  checkbox: "checkbox",
  radio: "radio",
  submit: "button",
  reset: "button",
  button: "button",
  file: "file",
  range: "slider",
  date: "datepicker",
  time: "timepicker",
  color: "colorpicker",
};

// Elements with no meaningful role to show — skip their line but recurse.
const SKIP_TAGS = new Set(["div", "span", "slot"]);

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Walk DOM to collect text, skipping agent UI subtrees. */
function getNonAgentUiText(root: Node, agentUiSelector: string): string {
  let text = "";
  const walk = (node: Node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      text += (node.textContent || "") + " ";
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as Element;
      if (el.closest(agentUiSelector)) {
        return;
      }
      if (el.shadowRoot) {
        for (let i = 0; i < el.shadowRoot.childNodes.length; i++) {
          walk(el.shadowRoot.childNodes[i]);
        }
      }
      for (let i = 0; i < el.childNodes.length; i++) {
        walk(el.childNodes[i]);
      }
    }
  };
  walk(root);
  return text.trim();
}

/** Traverse children recursively, resolving open shadow roots and slot elements. */
function getTextContentWithSlots(node: Node): string {
  if (node.nodeType === Node.TEXT_NODE) {
    return node.textContent || "";
  }
  if (node.nodeType === Node.ELEMENT_NODE) {
    const el = node as Element;
    if (tagLC(el) === "slot") {
      const assigned = (el as HTMLSlotElement).assignedNodes({ flatten: true });
      return assigned.map(getTextContentWithSlots).join("");
    }
    let text = "";
    if (el.shadowRoot) {
      for (let i = 0; i < el.shadowRoot.childNodes.length; i++) {
        text += getTextContentWithSlots(el.shadowRoot.childNodes[i]);
      }
    } else {
      for (let i = 0; i < el.childNodes.length; i++) {
        text += getTextContentWithSlots(el.childNodes[i]);
      }
    }
    return text;
  }
  return "";
}

/** Determine ARIA role for an element. */
function getRole(el: Element): string {
  const explicit = el.getAttribute("role");
  if (explicit) return explicit;

  const tag = el.tagName.toLowerCase();

  if (tag === "a" && el.hasAttribute("href")) return "link";

  if (tag === "input") {
    const type = (el as HTMLInputElement).type || "text";
    return INPUT_TYPE_ROLES[type] || "textbox";
  }

  return TAG_ROLES[tag] || "";
}

const INTERACTIVE_ROLES = new Set([
  "button",
  "link",
  "tab",
  "menuitem",
  "checkbox",
  "radio",
  "combobox",
  "switch",
]);

/** Is the element interactive per §5.1 S2? */
function isInteractive(el: Element): boolean {
  const tag = el.tagName.toLowerCase();

  if (
    (tag === "a" && el.hasAttribute("href")) ||
    tag === "button" ||
    tag === "input" ||
    tag === "select" ||
    tag === "textarea"
  ) {
    return true;
  }

  if (el.getAttribute("contenteditable") === "true") return true;
  if (el.hasAttribute("onclick")) return true;

  const role = el.getAttribute("role");
  if (role && INTERACTIVE_ROLES.has(role)) return true;

  return false;
}

/** Compute an accessible name (pragmatic §5.1 S1). */
function getName(el: Element): string {
  // aria-label
  const aLabel = el.getAttribute("aria-label");
  if (aLabel?.trim()) return aLabel.trim();

  // aria-labelledby
  const aLabelledBy = el.getAttribute("aria-labelledby");
  if (aLabelledBy) {
    const texts = aLabelledBy
      .split(/\s+/)
      .map((id) => document.getElementById(id)?.textContent?.trim())
      .filter(Boolean);
    if (texts.length > 0) return texts.join(" ");
  }

  // <label for="elId">
  const id = el.getAttribute("id");
  if (id) {
    const escaped = id.replace(/["\\]/g, "\\$&");
    const label = document.querySelector(`label[for="${escaped}"]`);
    if (label?.textContent?.trim()) return label.textContent.trim();
  }

  // wrapping <label>
  const parentLabel = el.closest("label");
  if (parentLabel?.textContent?.trim()) return parentLabel.textContent.trim();

  // alt
  const alt = el.getAttribute("alt");
  if (alt?.trim()) return alt.trim();

  // title
  const title = el.getAttribute("title");
  if (title?.trim()) return title.trim();

  // button textContent
  if (tagLC(el) === "button") {
    const t = getTextContentWithSlots(el).trim();
    if (t && t.length <= 120) return t;
  }

  // Generic fallback: short text content
  const text = getTextContentWithSlots(el).trim();
  if (text.length > 0 && text.length <= 120) return text;
  if (text.length > 120) return text.slice(0, 120) + "…";

  return "";
}

function tagLC(el: Element): string {
  return el.tagName.toLowerCase();
}

/** Escape special chars for display in a quoted snapshot string. */
function esc(s: string): string {
  return s.replace(/"/g, "&quot;").replace(/\\/g, "\\\\").replace(/\n/g, "\\n");
}

/** Build state-annotation string per §5.1 S3. */
function stateTags(el: Element, role: string): string {
  const parts: string[] = [];

  const valueRoles = new Set(["textbox", "searchbox", "spinbutton", "textarea"]);
  if (valueRoles.has(role) || (role === "combobox" && tagLC(el) === "select")) {
    const v = (el as HTMLInputElement | HTMLTextAreaElement).value;
    if (v !== undefined) parts.push(`value="${esc(v)}"`);
  }

  const checkRoles = new Set(["checkbox", "radio", "switch"]);
  if (checkRoles.has(role) && (el as HTMLInputElement).checked) {
    parts.push("checked");
  }

  if ((el as HTMLInputElement).disabled) parts.push("disabled");
  if ((el as HTMLInputElement).required) parts.push("required");

  const ac = el.getAttribute("aria-current");
  if (ac === "true" || ac === "page") parts.push("(current)");

  // Select options
  if (role === "combobox" && tagLC(el) === "select") {
    const sel = el as HTMLSelectElement;
    const opts = Array.from(sel.options).map((o) => o.label || o.value);
    const shown = opts.length > 20 ? opts.slice(0, 20) : opts;
    const list = shown.map((o) => `"${esc(o)}"`).join(",");
    let optsStr = `options=[${list}]`;
    if (opts.length > 20) optsStr += ` …+${opts.length - 20} more`;
    parts.push(optsStr);
  }

  return parts.length > 0 ? " " + parts.join(" ") : "";
}

/** Check if element should be skipped per §5.1 S4. */
function skipElement(el: Element): boolean {
  const tag = tagLC(el);
  if (tag === "script" || tag === "style") return true;
  if (el.hasAttribute("hidden")) return true;
  if (el.getAttribute("aria-hidden") === "true") return true;

  const style = el.getAttribute("style");
  if (style) {
    const s = style.toLowerCase().replace(/\s+/g, "");
    if (s.includes("display:none") || s.includes("visibility:hidden")) {
      return true;
    }
  }
  return false;
}

function reducedMotion(): boolean {
  return typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches === true;
}

// An ELEMENT emits its own snapshot line iff it has a role or is interactive.
function isSignificantElement(el: Element): boolean {
  return !!getRole(el) || isInteractive(el);
}

function countSignificant(
  node: Node,
  interactiveOnly: boolean,
  agentUiEl: Element | null,
): number {
  let n = 0;
  const visit = (nd: Node): void => {
    if (nd.nodeType === Node.TEXT_NODE) {
      if (interactiveOnly) return;
      const t = nd.textContent?.trim();
      if (!t) return;
      const p = nd.parentElement;
      if (p && isInteractive(p)) return;
      n++;
      return;
    }
    if (nd.nodeType !== Node.ELEMENT_NODE) return;
    const el = nd as Element;
    if (skipElement(el)) return;
    if (agentUiEl && (el === agentUiEl || agentUiEl.contains(el))) return;
    if (isSignificantElement(el)) n++;
    // recurse: slot → assigned nodes; else light DOM + open shadow root
    if (tagLC(el) === "slot") {
      for (const a of (el as HTMLSlotElement).assignedNodes({ flatten: true })) visit(a);
    } else {
      el.childNodes.forEach(visit);
      if (el.shadowRoot) el.shadowRoot.childNodes.forEach(visit);
    }
  };
  // count DESCENDANTS of `node`, not `node` itself
  if (node.nodeType === Node.ELEMENT_NODE) {
    const el = node as Element;
    if (tagLC(el) === "slot") {
      for (const a of (el as HTMLSlotElement).assignedNodes({ flatten: true })) visit(a);
    } else {
      el.childNodes.forEach(visit);
      if (el.shadowRoot) el.shadowRoot.childNodes.forEach(visit);
    }
  }
  return n;
}

/** Pure {role, name} for an element — same logic the snapshot/describe use.
 *  Exported so UI (pick mode) can label elements without a DomAdapter. */
export function describeElementParts(el: Element): { role: string; name: string } {
  return { role: getRole(el) || el.tagName.toLowerCase(), name: getName(el) };
}

// ---------------------------------------------------------------------------
// DomAdapter
// ---------------------------------------------------------------------------
export class DomAdapter {
  readonly refTable: RefTable;
  readonly root: ParentNode;
  readonly snapshotMaxChars: number;
  readonly snapshotMaxDepth: number;
  readonly snapshotSubtreeMaxNodes: number;
  readonly snapshotMaxNodes: number;
  readonly agentUiSelector: string;
  readonly confirmInteraction?: ConfirmInteractionFn;
  readonly imageLimits: ImageLimits;
  readonly actionCue?: ActionCueFn;
  readonly typingPaceMs?: () => number;
  #agentUiEl: Element | null = null;

  constructor(opts?: DomAdapterOptions) {
    this.refTable = opts?.refTable ?? new RefTable();
    this.root = opts?.root ?? document;
    this.snapshotMaxChars = opts?.snapshotMaxChars ?? 12_000;
    this.snapshotMaxDepth = opts?.snapshotMaxDepth ?? 12;
    this.snapshotSubtreeMaxNodes = opts?.snapshotSubtreeMaxNodes ?? 50;
    this.snapshotMaxNodes = opts?.snapshotMaxNodes ?? 400;
    this.agentUiSelector = opts?.agentUiSelector ?? "[data-agent-ui]";
    this.confirmInteraction = opts?.confirmInteraction;
    this.imageLimits = opts?.imageLimits ?? DEFAULT_IMAGE_LIMITS;
    this.actionCue = opts?.actionCue;
    this.typingPaceMs = opts?.typingPaceMs;
  }

  async snapshot(input: SnapshotInput): Promise<string> {
    // Determine traversal root
    let walkRoot: Node;
    if (input.scope) {
      const r = this.refTable.resolve(input.scope);
      if (r.status === "ok") {
        walkRoot = r.el;
      } else if (r.status === "stale") {
        // inline §10-style message (avoid circular import with tools/)
        return `Ref ${input.scope} is stale (generation ${r.fromGeneration}, current ${r.generation}). Take a new snapshot.`;
      } else if (r.status === "detached") {
        return `Ref ${input.scope} no longer exists in the DOM. Take a new snapshot.`;
      } else {
        return `Unknown ref ${input.scope}. Take a new snapshot.`;
      }
    } else {
      walkRoot = this.root instanceof Document ? (this.root as Document).body : this.root;
    }

    const gen = this.refTable.invalidateAll();

    // Capture agent UI element for exclusion (SEC6).
    this.#agentUiEl = this.root.querySelector(this.agentUiSelector);

    if (!walkRoot) {
      return `generation: ${gen}\n<empty page>`;
    }

    const prefix = `generation: ${gen}\n`;
    const { text } = this.#walkFromRoot(walkRoot, !!input.interactive_only, { charPrefixLen: prefix.length });
    return prefix + text;
  }

  /**
   * Focused snapshot of each given element's subtree, all assigned within a
   * SINGLE ref-table generation (016-2). `snapshot({scope})` bumps the
   * generation and resets the ref counter on every call, so calling it once
   * per pinned element would silently misresolve refs across items (item 2's
   * call wipes item 1's assignments; because the per-generation ref counter
   * restarts at 1, a reused ref number can resolve to the WRONG element, not
   * just go stale). This method invalidates once for the whole batch instead,
   * so every returned ref stays valid and unambiguous together.
   */
  async snapshotFocused(elements: Element[]): Promise<{ ref: number; text: string }[]> {
    this.#agentUiEl = this.root.querySelector(this.agentUiSelector);
    this.refTable.invalidateAll();
    return elements.map((el) => {
      const { text, rootRef } = this.#walkFromRoot(el, false, { forceRootRef: true });
      return { ref: rootRef as number, text };
    });
  }

  /** Shared traversal core for `snapshot()` and `snapshotFocused()` — walks
   *  from `walkRoot`, respecting the same depth/subtree/node budgets, and
   *  returns the rendered lines (no `generation: N` prefix — callers add
   *  that). `forceRootRef` guarantees `walkRoot` itself gets a ref even when
   *  it isn't "interactive" per `isInteractive()` (e.g. a pinned element with
   *  a non-interactive ARIA role like `role="listitem"`), by reusing
   *  `emitCollapseMarker`'s existing "assign + prefix onto the pushed line"
   *  trick. */
  #walkFromRoot(
    walkRoot: Node,
    interactiveOnly: boolean,
    opts?: { forceRootRef?: boolean; charPrefixLen?: number },
  ): { text: string; rootRef: number | undefined } {
    const maxDepth = (typeof window !== "undefined" && (window as any).__TINY_BUDGETS__) ? 3 : this.snapshotMaxDepth;
    const subtreeMaxNodes = (typeof window !== "undefined" && (window as any).__TINY_BUDGETS__) ? 5 : this.snapshotSubtreeMaxNodes;
    const maxNodes = (typeof window !== "undefined" && (window as any).__TINY_BUDGETS__) ? 15 : this.snapshotMaxNodes;

    const lines: string[] = [];
    const assignedRefs = new Map<Element, number>();
    const lineIndices = new Map<Element, number>();
    let emitted = 0;
    const budgetLeft = () => maxNodes - emitted;

    const emitCollapseMarker = (el: Element, renderedUnder: number): void => {
      const total = countSignificant(el, interactiveOnly, this.#agentUiEl);
      const hidden = Math.max(0, total - renderedUnder);
      if (hidden <= 0) return; // nothing actually hidden

      // ensure the boundary node has a ref (assign if it was non-interactive)
      let boundaryRef = assignedRefs.get(el);
      if (!boundaryRef) {
        boundaryRef = this.refTable.assign(el);
        assignedRefs.set(el, boundaryRef);
        // prefix the ref onto el's already-pushed line
        const lineIdx = lineIndices.get(el);
        if (lineIdx !== undefined) {
          lines[lineIdx] = lines[lineIdx].replace(/^(\s*)/, `$1[${boundaryRef}] `);
        }
      }

      const lineIdx = lineIndices.get(el);
      if (lineIdx !== undefined) {
        lines[lineIdx] += ` … +${hidden} nodes hidden — snapshot_page(scope="${boundaryRef}") to expand`;
      }
    };

    const walkChildrenBudgeted = (parent: Element, depth: number, startEmitted: number, cap: number): boolean => {
      const handleChild = (child: Node): boolean => {
        if (emitted - startEmitted >= cap || budgetLeft() <= 0) {
          return true; // overflowed
        }
        walk(child, depth);
        return false;
      };

      if (tagLC(parent) === "slot") {
        const assigned = (parent as HTMLSlotElement).assignedNodes({ flatten: true });
        for (const child of assigned) {
          if (handleChild(child)) return true;
        }
      } else {
        // Light DOM children
        for (let i = 0; i < parent.childNodes.length; i++) {
          if (handleChild(parent.childNodes[i])) return true;
        }
        // Shadow DOM children if open
        if (parent.shadowRoot) {
          const shadowRootEl = parent.shadowRoot as unknown as Element;
          for (let i = 0; i < shadowRootEl.childNodes.length; i++) {
            if (handleChild(shadowRootEl.childNodes[i])) return true;
          }
        }
      }
      return false;
    };

    const walk = (node: Node, depth: number): void => {
      // --- Text node ---
      if (node.nodeType === Node.TEXT_NODE) {
        if (interactiveOnly) return;
        const text = node.textContent?.trim();
        if (!text) return;
        // Skip text that is a direct child of an interactive element
        // (its role/name already covers it).
        const parent = node.parentElement;
        if (parent && isInteractive(parent)) return;

        if (budgetLeft() <= 0) return;

        const indent = "  ".repeat(depth);
        lines.push(`${indent}text "${esc(text)}"`);
        emitted++;
        return;
      }

      if (node.nodeType !== Node.ELEMENT_NODE) return;
      const el = node as Element;

      // Skip S4 elements
      if (skipElement(el)) return;

      // Skip agent UI subtree (SEC6) — also check across shadow boundaries
      if (this.#agentUiEl && (el === this.#agentUiEl || this.#agentUiEl.contains(el))) {
        return;
      }

      const role = getRole(el);
      const interactive = isInteractive(el);

      // If no meaningful role and not interactive, skip the line but recurse kids
      if (!role && !interactive) {
        if (budgetLeft() <= 0) return;
        // Still recurse into children (light DOM + shadow root) at SAME depth
        for (let i = 0; i < el.childNodes.length; i++) {
          if (budgetLeft() <= 0) return;
          walk(el.childNodes[i], depth);
        }
        if (el.shadowRoot) {
          const shadowRootEl = el.shadowRoot as unknown as Element;
          for (let i = 0; i < shadowRootEl.childNodes.length; i++) {
            if (budgetLeft() <= 0) return;
            walk(shadowRootEl.childNodes[i], depth);
          }
        }
        return;
      }

      if (budgetLeft() <= 0) return;

      const indent = "  ".repeat(depth);

      // --- Build line ---
      let line = indent;

      // Ref for interactive elements (§5.1 S2)
      let ref = 0;
      if (interactive) {
        ref = this.refTable.assign(el);
        assignedRefs.set(el, ref);
        line += `[${ref}] `;
      }

      line += role;

      const name = getName(el);
      if (name) line += ` "${esc(name)}"`;

      // State tags (§5.1 S3)
      line += stateTags(el, role);

      // Extra annotation for headings
      if (role === "heading") {
        line += ` (${tagLC(el)})`;
      }

      // §022-002: self-attribute permission annotation (no ancestor walk)
      if (interactive) {
        const selfPerm = el.getAttribute("data-agent-permission");
        if (selfPerm === "ask" || selfPerm === "block") {
          line += ` (${selfPerm})`;
        }
      }

      lineIndices.set(el, lines.length);
      lines.push(line);
      emitted++;

      // Recurse children (increase depth)
      const collapseDepth = depth + 1 > maxDepth;
      if (collapseDepth) {
        emitCollapseMarker(el, 0); // whole subtree hidden
        return;
      }

      const startEmitted = emitted;
      const childBudget = subtreeMaxNodes;
      const overflowed = walkChildrenBudgeted(el, depth + 1, startEmitted, childBudget);
      if (overflowed) {
        emitCollapseMarker(el, emitted - startEmitted);
      }
    };

    walk(walkRoot, 0);

    if (opts?.forceRootRef && walkRoot.nodeType === Node.ELEMENT_NODE) {
      const rootEl = walkRoot as Element;
      if (!assignedRefs.has(rootEl)) {
        const ref = this.refTable.assign(rootEl);
        assignedRefs.set(rootEl, ref);
        const lineIdx = lineIndices.get(rootEl);
        if (lineIdx !== undefined) {
          lines[lineIdx] = lines[lineIdx].replace(/^(\s*)/, `$1[${ref}] `);
        }
      }
    }

    const totalSignificant = countSignificant(walkRoot, interactiveOnly, this.#agentUiEl);
    let output = lines.join("\n");
    if (emitted < totalSignificant && budgetLeft() <= 0) {
      const missed = totalSignificant - emitted;
      output += `\n… TRUNCATED: ${missed} more significant nodes not shown ` +
        `(node budget ${maxNodes} reached). ` +
        `Narrow with scope="<ref>" on a section above, or interactive_only=true.`;
    }

    // Final safety net: hard char cap (should now rarely trigger). Accounts
    // for a prefix the caller will prepend (e.g. snapshot()'s "generation: N\n"
    // line) so the cap applies to the full string the caller returns, matching
    // pre-refactor behavior where the prefix was already part of `output`.
    const charPrefixLen = opts?.charPrefixLen ?? 0;
    if (charPrefixLen + output.length > this.snapshotMaxChars) {
      output = output.slice(0, Math.max(0, this.snapshotMaxChars - charPrefixLen)) +
        `\n… TRUNCATED (char cap ${this.snapshotMaxChars}). Use scope or interactive_only to narrow.`;
    }

    const rootRef = walkRoot.nodeType === Node.ELEMENT_NODE
      ? assignedRefs.get(walkRoot as Element)
      : undefined;

    return { text: output, rootRef };
  }

  /**
   * Rasterize a DOM target to an image data URL.
   * - no `scope` → the whole agent-visible viewport (document.body), excluding
   *   the agent chat panel.
   * - `scope` ref → that element's subtree (resolved via the ref table).
   * The chat panel ([data-agent-ui]) is always excluded via a node filter.
   * Result is downscaled via `downscaleImage` to honour `imageLimits`.
   */
  async screenshot(scope?: string): Promise<{
    dataUrl: string;
    mediaType: string;
    width: number;
    height: number;
  }> {
    let target: Element;
    if (scope) {
      target = this.#resolveOrThrow(scope);
    } else {
      const body = this.root instanceof Document ? this.root.body : (this.root as Element);
      if (!body) throw new Error("No document body to screenshot.");
      target = body;
    }

    const agentSel = this.agentUiSelector;
    // Skip the cue (and any flash) when the captured region is/contains
    // the chat panel — matches the existing filter exclusion.
    const skipCue = !!(
      typeof (target as Element).matches === "function" &&
      ((target as Element).matches?.(agentSel) ||
        (target as Element).closest?.(agentSel))
    );

    const rect = (target as HTMLElement).getBoundingClientRect?.() ?? {
      x: 0, y: 0, width: 0, height: 0,
    };

    if (this.actionCue && !skipCue) {
      await this.actionCue(target, "see", {
        rect: {
          x: rect.left ?? 0,
          y: rect.top ?? 0,
          width: rect.width ?? 0,
          height: rect.height ?? 0,
        },
      });
    }

    const filter = (node: HTMLElement) => {
      return !(node instanceof Element && (node.matches?.(agentSel) || node.closest?.(agentSel)));
    };

    const pngDataUrl = await htmlToImage.toPng(target as HTMLElement, {
      filter,
      cacheBust: true,
      pixelRatio: 1,
    });

    const dataUrl = await downscaleImage(pngDataUrl, this.imageLimits);
    const mediaType = dataUrl.startsWith("data:image/png") ? "image/png" : "image/jpeg";

    return {
      dataUrl, mediaType,
      width: Math.round(rect.width ?? 0),
      height: Math.round(rect.height ?? 0),
    };
  }

  // -----------------------------------------------------------------------
  // Stubs — implemented in tasks 009–011.
  // -----------------------------------------------------------------------

  #resolveOrThrow(ref: string): Element {
    const result = this.refTable.resolve(ref);
    if (result.status === "stale") {
      throw new Error(staleRef(ref, result.fromGeneration, this.refTable.generation));
    }
    if (result.status === "detached" || result.status === "unknown") {
      throw new Error(detachedRef(ref));
    }
    return result.el;
  }

  describeElement(el: Element): string {
    const { role, name } = describeElementParts(el);
    return name ? `${role} "${name}"` : role;
  }

  async click(ref: string): Promise<string> {
    const el = this.#resolveOrThrow(ref);
    const name = getName(el);
    const isDisabled = el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true";
    if (isDisabled) {
      throw new Error(disabledRef(ref, name));
    }

    const { permission, reason } = resolveAgentPermission(el);
    if (permission === "block") {
      const desc = name ? ` "${name}"` : "";
      const extra = reason ? ` (${reason})` : "";
      return `Blocked by interaction policy ("block"): not allowed to operate [${ref}]${desc}${extra}; ask the user to do it themselves.`;
    }
    if (permission === "ask") {
      if (this.confirmInteraction) {
        const ok = await this.confirmInteraction({ tool: "click", ref, name, action: "click", reason });
        if (!ok) {
          return `Action "click" on [${ref}]${name ? ` "${name}"` : ""} was not confirmed by the user; not performed.`;
        }
      } else {
        return `Interaction required confirmation ("ask" policy) but no confirmation dialog is configured; not performed.`;
      }
    }

    if (this.actionCue) {
      const rect = el.getBoundingClientRect?.();
      await this.actionCue(el, "click", {
        point: rect ? { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 } : undefined,
      });
    }

    const eventInit = { bubbles: true, cancelable: true, composed: true };
    const PointerClass = typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent;
    const pointerdown = new PointerClass("pointerdown", eventInit);
    const mousedown = new MouseEvent("mousedown", eventInit);
    const pointerup = new PointerClass("pointerup", eventInit);
    const mouseup = new MouseEvent("mouseup", eventInit);
    const clickEvent = new MouseEvent("click", eventInit);

    const tagName = el.tagName.toLowerCase();
    const isInput = tagName === "input";
    const isCheckbox = isInput && (el as HTMLInputElement).type === "checkbox";
    const isRadio = isInput && (el as HTMLInputElement).type === "radio";
    const isCheckboxOrRadio = isCheckbox || isRadio;
    const initialChecked = isCheckboxOrRadio ? (el as HTMLInputElement).checked : null;

    el.dispatchEvent(pointerdown);
    el.dispatchEvent(mousedown);
    el.dispatchEvent(pointerup);
    el.dispatchEvent(mouseup);
    const notPrevented = el.dispatchEvent(clickEvent);

    const stateChanged = (initialChecked !== null) && ((el as HTMLInputElement).checked !== initialChecked);
    const isLink = tagName === "a" && el.hasAttribute("href");

    if (notPrevented && !stateChanged && (isLink || isCheckboxOrRadio)) {
      (el as HTMLElement).click?.();
    }

    await new Promise((r) => setTimeout(r, 0));
    if (typeof window !== "undefined" && typeof window.requestAnimationFrame === "function") {
      await new Promise((r) => window.requestAnimationFrame(() => r(null)));
    } else if (typeof requestAnimationFrame === "function") {
      await new Promise((r) => requestAnimationFrame(() => r(null)));
    }

    const description = this.describeElement(el);
    return `Clicked [${ref}] ${description}. Page may have changed; snapshot again if you need to verify.`;
  }

  async fill(ref: string, value: string, signal?: AbortSignal): Promise<string> {
    const el = this.#resolveOrThrow(ref);
    const name = getName(el);
    const isDisabled = el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true";
    if (isDisabled) {
      throw new Error(disabledRef(ref, name));
    }

    const { permission, reason } = resolveAgentPermission(el);
    if (permission === "block") {
      const desc = name ? ` "${name}"` : "";
      const extra = reason ? ` (${reason})` : "";
      return `Blocked by interaction policy ("block"): not allowed to operate [${ref}]${desc}${extra}; ask the user to do it themselves.`;
    }
    if (permission === "ask") {
      const action = "fill";
      if (this.confirmInteraction) {
        const ok = await this.confirmInteraction({ tool: action, ref, name, action, reason });
        if (!ok) {
          return `Action "${action}" on [${ref}]${name ? ` "${name}"` : ""} was not confirmed by the user; not performed.`;
        }
      } else {
        return `Interaction required confirmation ("ask" policy) but no confirmation dialog is configured; not performed.`;
      }
    }

    if (this.actionCue) {
      await this.actionCue(el, "fill", { value });
    }

    const tagName = el.tagName.toLowerCase();
    const isInput = tagName === "input";
    const isTextarea = tagName === "textarea";
    const isContentEditable = (el as HTMLElement).isContentEditable || el.getAttribute("contenteditable") === "true";

    let readBack = "";

    if (isInput || isTextarea) {
      const proto = isTextarea ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (!setter) {
        throw new Error(`Failed to find value setter prototype for ${tagName}`);
      }
      const paceMs = this.typingPaceMs?.() ?? 0;
      const instant = paceMs <= 0 || reducedMotion() || value.length === 0;
      if (instant) {
        setter.call(el, value);
        el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        el.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      } else {
        await this.#typeWordByWord(el, setter, value, paceMs, signal);
      }
      readBack = (el as HTMLInputElement).value;
    } else if (isContentEditable) {
      (el as HTMLElement).focus?.();
      el.textContent = value;
      el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));

      readBack = el.textContent || "";
    } else {
      throw new Error(`Ref ${ref} is not a text input, textarea, or contenteditable.`);
    }

    const description = this.describeElement(el);
    if (readBack === value) {
      return `Filled [${ref}] ${description} → value="${readBack}"`;
    } else {
      return `Filled [${ref}] ${description} → set "${value}" but value read back as "${readBack}" (input may have validation/mask).`;
    }
  }

  async selectOption(ref: string, option: string): Promise<string> {
    const el = this.#resolveOrThrow(ref);
    const name = getName(el);
    const isDisabled = el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true";
    if (isDisabled) {
      throw new Error(disabledRef(ref, name));
    }

    const { permission: selPermission, reason: selReason } = resolveAgentPermission(el);
    if (selPermission === "block") {
      const desc = name ? ` "${name}"` : "";
      const extra = selReason ? ` (${selReason})` : "";
      return `Blocked by interaction policy ("block"): not allowed to operate [${ref}]${desc}${extra}; ask the user to do it themselves.`;
    }
    if (selPermission === "ask") {
      if (this.confirmInteraction) {
        const ok = await this.confirmInteraction({ tool: "selectOption", ref, name, action: "selectOption", reason: selReason });
        if (!ok) {
          return `Action "selectOption" on [${ref}]${name ? ` "${name}"` : ""} was not confirmed by the user; not performed.`;
        }
      } else {
        return `Interaction required confirmation ("ask" policy) but no confirmation dialog is configured; not performed.`;
      }
    }

    if (!(el instanceof HTMLSelectElement)) {
      throw new Error(`Ref ${ref} is not a native <select>. Custom dropdowns: click to open then click the option.`);
    }

    const selectEl = el as HTMLSelectElement;
    const options = Array.from(selectEl.options);

    if (this.actionCue) {
      await this.actionCue(selectEl, "select", { value: option });
    }

    let matchedOption: HTMLOptionElement | undefined;

    matchedOption = options.find((opt) => (opt.label || opt.text || "").trim() === option.trim());

    if (!matchedOption) {
      matchedOption = options.find((opt) => opt.value === option);
    }

    if (!matchedOption) {
      const lowerOpt = option.trim().toLowerCase();
      matchedOption = options.find((opt) => (opt.label || opt.text || "").trim().toLowerCase() === lowerOpt);
    }

    if (!matchedOption) {
      const optionNames = options.map((opt) => (opt.label || opt.text || opt.value || "").trim()).filter(Boolean);
      throw new Error(selectOptionMissing(option, optionNames));
    }

    selectEl.value = matchedOption.value;
    selectEl.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    selectEl.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));

    const label = (matchedOption.label || matchedOption.text || "").trim();
    const description = this.describeElement(selectEl);
    return `Selected "${label}" in [${ref}] ${description}`;
  }

  async waitForIdle(timeoutMs: number, signal?: AbortSignal): Promise<boolean> {
    if (signal?.aborted) {
      return false;
    }

    return new Promise<boolean>((resolve) => {
      let timer: NodeJS.Timeout | null = null;
      let timeoutTimer: NodeJS.Timeout | null = null;
      let observer: MutationObserver | null = null;

      const cleanup = () => {
        if (timer) clearTimeout(timer);
        if (timeoutTimer) clearTimeout(timeoutTimer);
        if (observer) observer.disconnect();
        signal?.removeEventListener("abort", onAbort);
      };

      const onAbort = () => {
        cleanup();
        resolve(false);
      };

      if (signal) {
        signal.addEventListener("abort", onAbort);
      }

      const resetTimer = () => {
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => {
          cleanup();
          resolve(true);
        }, 300);
      };

      timeoutTimer = setTimeout(() => {
        cleanup();
        resolve(false);
      }, timeoutMs);

      resetTimer();

      const target = this.root instanceof Document ? this.root.body : (this.root as HTMLElement);
      if (typeof MutationObserver !== "undefined" && target) {
        observer = new MutationObserver((mutations) => {
          let hasExternalMutation = false;
          
          for (const mutation of mutations) {
            const node = mutation.target;
            if (node instanceof Element) {
              const insideAgentUi = node.closest(this.agentUiSelector) !== null;
              if (!insideAgentUi) {
                hasExternalMutation = true;
                break;
              }
            } else {
              const parent = node.parentElement;
              if (parent) {
                const insideAgentUi = parent.closest(this.agentUiSelector) !== null;
                if (!insideAgentUi) {
                  hasExternalMutation = true;
                  break;
                }
              } else {
                hasExternalMutation = true;
                break;
              }
            }
          }

          if (hasExternalMutation) {
            resetTimer();
          }
        });

        observer.observe(target, {
          childList: true,
          subtree: true,
          attributes: true,
          characterData: true,
        });
      }
    });
  }

  async waitForText(text: string, timeoutMs: number, signal?: AbortSignal): Promise<boolean> {
    if (signal?.aborted) {
      return false;
    }

    return new Promise<boolean>((resolve) => {
      let intervalTimer: NodeJS.Timeout | null = null;
      let timeoutTimer: NodeJS.Timeout | null = null;

      const cleanup = () => {
        if (intervalTimer) clearInterval(intervalTimer);
        if (timeoutTimer) clearTimeout(timeoutTimer);
        signal?.removeEventListener("abort", onAbort);
      };

      const onAbort = () => {
        cleanup();
        resolve(false);
      };

      if (signal) {
        signal.addEventListener("abort", onAbort);
      }

      const check = () => {
        const body = this.root instanceof Document ? this.root.body : (this.root as HTMLElement);
        if (!body) return;
        const pageText = getNonAgentUiText(body, this.agentUiSelector);
        if (pageText.includes(text)) {
          cleanup();
          resolve(true);
        }
      };

      timeoutTimer = setTimeout(() => {
        cleanup();
        resolve(false);
      }, timeoutMs);

      check();

      intervalTimer = setInterval(check, 250);
    });
  }

  #typeWordByWord(
    el: Element,
    setter: (this: any, v: string) => void,
    value: string,
    paceMs: number,
    signal?: AbortSignal,
  ): Promise<void> {
    return new Promise<void>((resolve) => {
      const rawChunks = value.split(/(?<=\s)(?=\S)/);
      const chunks = rawChunks.length > 0 ? rawChunks : [value];
      const pending = new Set<ReturnType<typeof setTimeout>>();
      let settled = false;

      const settle = () => {
        if (settled) return;
        settled = true;
        pending.forEach(clearTimeout);
        pending.clear();
        if (signal) signal.removeEventListener("abort", onAbort);
        resolve();
      };

      const onAbort = () => {
        // Leave the current partial value; no final change event.
        settle();
      };

      if (signal?.aborted) {
        resolve();
        return;
      }
      if (signal) signal.addEventListener("abort", onAbort);

      let acc = "";
      chunks.forEach((chunk, i) => {
        const id = setTimeout(() => {
          pending.delete(id);
          if (settled) return;
          if (signal?.aborted) { settle(); return; }
          acc += chunk;
          setter.call(el, acc);
          el.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
          if (i === chunks.length - 1) {
            el.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
            settle();
          }
        }, i * paceMs);
        pending.add(id);
      });
    });
  }
}
