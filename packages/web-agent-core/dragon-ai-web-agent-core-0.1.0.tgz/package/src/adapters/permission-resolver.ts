export type AgentPermission = "allow" | "ask" | "block";

export interface PermissionResolution {
  permission: AgentPermission;
  reason?: string;
}

export type ConfirmInteractionFn = (detail: {
  tool: string;
  ref: string;
  name?: string;
  action: string;
  reason?: string;
}) => Promise<boolean>;

const VALID_PERMISSIONS = new Set(["allow", "ask", "block"]);

export function resolveAgentPermission(el: Element): PermissionResolution {
  const target = el.closest("[data-agent-permission]");
  if (!target) {
    return { permission: "allow" };
  }
  const raw = target.getAttribute("data-agent-permission") ?? "";
  if (!VALID_PERMISSIONS.has(raw)) {
    return { permission: "allow" };
  }
  const reason = target.getAttribute("data-agent-permission-reason") ?? undefined;
  return { permission: raw as AgentPermission, reason };
}
