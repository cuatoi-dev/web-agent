import type { FieldSchema, DataQuery, QueryResult, SourceInfo } from "./types.js";
import { runQuery } from "./query-engine.js";

/**
 * A registered data source. Both describe and query are async.
 */
export interface SourceEntry {
  describe(): Promise<SourceInfo> | SourceInfo;
  query(q: DataQuery): Promise<QueryResult>;
}

/**
 * Registry of named data sources.
 */
export class SourceRegistry {
  private _sources = new Map<string, SourceEntry>();

  /** Register a source entry. Overwrites if name already exists. */
  register(name: string, entry: SourceEntry): void {
    this._sources.set(name, entry);
  }

  /** Register a source backed by a static in-memory row array (wraps runQuery). */
  registerStatic(name: string, description: string, fields: FieldSchema[], rows: Record<string, unknown>[]): void {
    this._sources.set(name, {
      describe(): SourceInfo {
        return { name, description, fields, rowCount: rows.length };
      },
      async query(q: DataQuery): Promise<QueryResult> {
        return runQuery(rows, fields, q);
      },
    });
  }

  /** Look up a source by name. Returns undefined if not found. */
  get(name: string): SourceEntry | undefined {
    return this._sources.get(name);
  }

  /** List all registered source names. */
  names(): string[] {
    return [...this._sources.keys()];
  }

  /** Describe all registered sources. Awaits sources whose describe() is async. */
  async listSources(): Promise<SourceInfo[]> {
    const result: SourceInfo[] = [];
    for (const entry of this._sources.values()) {
      result.push(await entry.describe());
    }
    return result;
  }
}
