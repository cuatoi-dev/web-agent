import { z } from "zod";

export type FieldType = "string" | "number" | "boolean" | "date" | "enum";

export const FieldTypeSchema = z.enum(["string", "number", "boolean", "date", "enum"]);

export interface FieldSchema {
  name: string;
  type: FieldType;
  enumValues?: string[];
  description?: string;
}

export const FieldSchemaSchema = z.object({
  name: z.string(),
  type: FieldTypeSchema,
  enumValues: z.array(z.string()).optional(),
  description: z.string().optional(),
}).strict();

export interface SourceInfo {
  name: string;
  description: string;
  fields: FieldSchema[];
  rowCount: number;
}

export type Scalar = string | number | boolean;
export const ScalarSchema = z.union([z.string(), z.number(), z.boolean()]);

export const ConditionSchema = z.union([
  ScalarSchema,
  z.object({
    $eq: ScalarSchema.optional(),
    $ne: ScalarSchema.optional(),
    $gt: ScalarSchema.optional(),
    $gte: ScalarSchema.optional(),
    $lt: ScalarSchema.optional(),
    $lte: ScalarSchema.optional(),
    $in: z.array(ScalarSchema).optional(),
    $nin: z.array(ScalarSchema).optional(),
    $contains: z.string().optional(),
    $startsWith: z.string().optional(),
    $endsWith: z.string().optional(),
    $regex: z.string().optional(),
    $between: z.tuple([ScalarSchema, ScalarSchema]).optional(),
    $exists: z.boolean().optional(),
    $isNull: z.boolean().optional(),
  }).strict(),
]);

export type Condition = Scalar | {
  $eq?: Scalar;
  $ne?: Scalar;
  $gt?: Scalar;
  $gte?: Scalar;
  $lt?: Scalar;
  $lte?: Scalar;
  $in?: Scalar[];
  $nin?: Scalar[];
  $contains?: string;
  $startsWith?: string;
  $endsWith?: string;
  $regex?: string;
  $between?: [Scalar, Scalar];
  $exists?: boolean;
  $isNull?: boolean;
};

export type FilterExpr =
  | { $and: FilterExpr[] }
  | { $or: FilterExpr[] }
  | { $not: FilterExpr }
  | { [field: string]: Condition };

const BaseFilterExpr = z.record(z.string(), ConditionSchema);

const FilterExprL1 = z.union([
  z.object({ $and: z.array(BaseFilterExpr) }).strict(),
  z.object({ $or: z.array(BaseFilterExpr) }).strict(),
  z.object({ $not: BaseFilterExpr }).strict(),
  BaseFilterExpr,
]);

const FilterExprL2 = z.union([
  z.object({ $and: z.array(FilterExprL1) }).strict(),
  z.object({ $or: z.array(FilterExprL1) }).strict(),
  z.object({ $not: FilterExprL1 }).strict(),
  BaseFilterExpr,
]);

export const FilterExprSchema: z.ZodType<FilterExpr> = z.union([
  z.object({ $and: z.array(FilterExprL2) }).strict(),
  z.object({ $or: z.array(FilterExprL2) }).strict(),
  z.object({ $not: FilterExprL2 }).strict(),
  BaseFilterExpr,
]) as any;

export interface Dimension {
  field: string;
  granularity?: "hour" | "minute" | "day" | "week" | "month" | "quarter" | "year";
  as?: string;
}

export const DimensionSchema = z.object({
  field: z.string(),
  granularity: z.enum(["hour", "minute", "day", "week", "month", "quarter", "year"]).optional(),
  as: z.string().optional(),
}).strict();

export type MeasureOp = "count" | "sum" | "avg" | "min" | "max" | "countDistinct" | "first" | "last";

export interface Measure {
  op: MeasureOp;
  field?: string;
  as?: string;
}

export const MeasureSchema = z.object({
  op: z.enum(["count", "sum", "avg", "min", "max", "countDistinct", "first", "last"]),
  field: z.string().optional(),
  as: z.string().optional(),
}).strict();

export interface Aggregation {
  groupBy: Dimension[];
  measures: Measure[];
  having?: FilterExpr;
  sort?: { field: string; dir?: "asc" | "desc" }[];
  limit?: number;
}

export const AggregationSchema: z.ZodType<Aggregation> = z.object({
  groupBy: z.array(DimensionSchema),
  measures: z.array(MeasureSchema),
  having: FilterExprSchema.optional(),
  sort: z.array(
    z.object({
      field: z.string(),
      dir: z.enum(["asc", "desc"]).optional(),
    }).strict()
  ).optional(),
  limit: z.number().optional(),
}).strict();

export interface DataQuery {
  source: string;
  select?: string[];
  filter?: FilterExpr;
  sort?: { field: string; dir?: "asc" | "desc" }[];
  page?: { limit?: number; offset?: number };
  aggregate?: Aggregation;
}

export const DataQuerySchema = z.object({
  source: z.string(),
  select: z.array(z.string()).optional(),
  filter: FilterExprSchema.optional(),
  sort: z.array(
    z.object({
      field: z.string(),
      dir: z.enum(["asc", "desc"]).optional(),
    }).strict()
  ).optional(),
  page: z.object({
    limit: z.number().optional(),
    offset: z.number().optional(),
  }).strict().optional(),
  aggregate: AggregationSchema.optional(),
}).strict();

export interface QueryResult {
  source: string;
  aggregated: boolean;
  fields: FieldSchema[];
  rows: Record<string, unknown>[];
  page: {
    limit: number;
    offset: number;
    total: number;
    hasMore: boolean;
  };
}

export function validateDataQuery(raw: unknown): 
  | { ok: true; value: DataQuery }
  | { ok: false; message: string } {
  const res = DataQuerySchema.safeParse(raw);
  if (res.success) {
    return { ok: true, value: res.data };
  } else {
    const formattedErrors = res.error.errors.map(err => {
      const path = err.path.join(".");
      return `${path ? path + ": " : ""}${err.message}`;
    }).join("; ");
    return { ok: false, message: `Invalid DataQuery: ${formattedErrors}` };
  }
}
