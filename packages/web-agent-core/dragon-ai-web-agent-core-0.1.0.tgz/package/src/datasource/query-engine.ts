import { FieldSchema, DataQuery, QueryResult } from "./types.js";
import { matchesFilter, compareValues } from "./filter.js";
import { aggregate } from "./aggregate.js";

export function runQuery(rows: Record<string, unknown>[], schema: FieldSchema[], q: DataQuery): QueryResult {
  // Validate that select fields exist in schema
  if (q.select) {
    for (const fieldName of q.select) {
      if (!schema.some(f => f.name === fieldName)) {
        throw new Error(`Unknown field "${fieldName}". Fields: ${schema.map(f => f.name).join(", ")}`);
      }
    }
  }

  // 1. Filter
  let filtered = [...rows];
  if (q.filter) {
    filtered = filtered.filter(row => matchesFilter(row, q.filter!, schema));
  }

  if (q.aggregate) {
    // Aggregation path: filter → aggregate → having → sort → limit → paginate
    // Top-level q.sort/q.select are ignored when aggregating.
    const { rows: aggRows, fields: aggFields } = aggregate(filtered, schema, q.aggregate);
    const aggTotal = aggRows.length;

    // Paginate aggregated rows
    const offset = q.page?.offset ?? 0;
    const rawLimit = q.page?.limit ?? 50;
    const limit = Math.min(Math.max(rawLimit, 1), 500);
    const paginated = aggRows.slice(offset, offset + limit);

    // Truncate leaves
    const truncated = paginated.map(row => truncateLeaves(row) as Record<string, unknown>);

    return {
      source: q.source,
      aggregated: true,
      fields: aggFields,
      rows: truncated,
      page: {
        limit,
        offset,
        total: aggTotal,
        hasMore: offset + limit < aggTotal
      }
    };
  }

  // 2. Sort (non-aggregation path)
  if (q.sort && q.sort.length > 0) {
    for (const item of q.sort) {
      const fieldSchema = schema.find(f => f.name === item.field);
      if (!fieldSchema) {
        throw new Error(`Unknown field "${item.field}". Fields: ${schema.map(f => f.name).join(", ")}`);
      }
    }
    filtered.sort((a, b) => {
      for (const item of q.sort!) {
        const fieldSchema = schema.find(f => f.name === item.field)!;
        const type = fieldSchema.type;
        const valA = a[item.field];
        const valB = b[item.field];
        const cmp = compareValues(valA, valB, type);
        if (cmp !== 0) {
          return item.dir === "desc" ? -cmp : cmp;
        }
      }
      return 0;
    });
  }

  // 3. Total (filtered count)
  const total = filtered.length;

  // 4. Paginate
  const offset = q.page?.offset ?? 0;
  const rawLimit = q.page?.limit ?? 50;
  const limit = Math.min(Math.max(rawLimit, 1), 500);
  const paginated = filtered.slice(offset, offset + limit);

  // 5. Project (select)
  let projected = paginated.map(row => {
    if (q.select) {
      const proj: Record<string, unknown> = {};
      for (const key of q.select) {
        proj[key] = row[key];
      }
      return proj;
    }
    return { ...row };
  });

  // 6. Truncate leaves
  const truncated = projected.map(row => truncateLeaves(row) as Record<string, unknown>);

  // Projected schema fields
  const resultFields = q.select
    ? q.select.map(name => schema.find(f => f.name === name)!)
    : schema;

  return {
    source: q.source,
    aggregated: false,
    fields: resultFields,
    rows: truncated,
    page: {
      limit,
      offset,
      total,
      hasMore: offset + limit < total
    }
  };
}

export function serializeResult(result: QueryResult, maxChars = 6000): string {
  // 1. Try pretty print
  let output = JSON.stringify(result, null, 2);
  if (output.length <= maxChars) {
    return output;
  }

  // 2. Try pretty print with fewer rows
  const cloned = { ...result, rows: [...result.rows] };
  while (cloned.rows.length > 0) {
    cloned.rows.pop();
    output = JSON.stringify(cloned, null, 2);
    if (output.length <= maxChars) {
      return output;
    }
  }

  // 3. Try compact print
  output = JSON.stringify(result);
  if (output.length <= maxChars) {
    return output;
  }

  // 4. Try compact print with fewer rows
  const compactCloned = { ...result, rows: [...result.rows] };
  while (compactCloned.rows.length > 0) {
    compactCloned.rows.pop();
    output = JSON.stringify(compactCloned);
    if (output.length <= maxChars) {
      return output;
    }
  }

  // 5. Final fallback: slice
  return output.slice(0, maxChars - 4) + "\n...";
}

function truncateLeaves(val: unknown, depth = 0): unknown {
  if (depth > 6) return "…";
  if (val === null || val === undefined) return val;
  if (typeof val === "string") {
    if (val.length > 300) {
      return val.slice(0, 300) + "…";
    }
    return val;
  }
  if (Array.isArray(val)) {
    return val.map(v => truncateLeaves(v, depth + 1));
  }
  if (typeof val === "object") {
    if (val instanceof Date) return val;
    if (val instanceof RegExp) return val;
    const res: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(val)) {
      res[k] = truncateLeaves(v, depth + 1);
    }
    return res;
  }
  return val;
}
