import type { DataQuery, QueryResult, SourceInfo } from "./types.js";
import { SourceRegistry, SourceEntry } from "./registry.js";

// ---------------------------------------------------------------------------
// Interface
// ---------------------------------------------------------------------------
export interface DataSourceProvider {
  listSources(): Promise<SourceInfo[]>;
  describeSource(name: string): Promise<SourceInfo>;
  query(q: DataQuery): Promise<QueryResult>;
}

// ---------------------------------------------------------------------------
// Factory
// ---------------------------------------------------------------------------
export interface ProviderOptions {
  /** Optional function to get the latest state. */
  getState?: () => Record<string, unknown>;
  /** The data sources to register. */
  sources: SourceEntry[];
}

export function createDataSourceProvider(opts: ProviderOptions): DataSourceProvider {
  const { sources } = opts;
  const registry = new SourceRegistry();

  // describe() may be async (e.g. cat-store's orders source fetches
  // /api/orders/describe), so registration is a promise every method awaits.
  const ready = Promise.all(
    sources.map(async (source) => {
      try {
        const info = await source.describe();
        registry.register(info.name, source);
      } catch (err) {
        console.error("Failed to describe source", err);
      }
    })
  );

  // Build the provider
  const provider: DataSourceProvider = {
    async listSources(): Promise<SourceInfo[]> {
      await ready;
      return registry.listSources();
    },

    async describeSource(name: string): Promise<SourceInfo> {
      await ready;
      const entry = registry.get(name);
      if (!entry) {
        throw new Error(`Unknown source "${name}". Available: ${registry.names().join(", ")}.`);
      }
      return entry.describe();
    },

    async query(q: DataQuery): Promise<QueryResult> {
      await ready;
      const entry = registry.get(q.source);
      if (!entry) {
        throw new Error(`Unknown source "${q.source}". Available: ${registry.names().join(", ")}.`);
      }
      return entry.query(q);
    },
  };

  return provider;
}
