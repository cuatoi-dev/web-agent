import type { CustomToolDef, JsonSchemaObject, ToolOutcome } from "../tools/build-tools.js";

export interface McpClientSession {
  serverName: string;
  serverUrl: string;
  tools: CustomToolDef[];
  client: unknown;
  transport: unknown;
  close: () => Promise<void>;
}

export interface ConnectMcpOptions {
  clientName?: string;
  clientVersion?: string;
  timeoutMs?: number;
  fetch?: typeof fetch;
}

export interface McpToolInfo {
  name: string;
  description?: string;
  inputSchema?: Record<string, unknown>;
}

export interface McpContentBlock {
  type: string;
  text?: string;
  [key: string]: unknown;
}

export interface McpCallToolResult {
  content?: McpContentBlock[];
  isError?: boolean;
  [key: string]: unknown;
}

/** Sanitize server name to produce a valid tool name prefix (alphanumeric + underscore). */
export function sanitizeServerName(name: string): string {
  return name.replace(/[^a-zA-Z0-9_]/g, "_").replace(/^_+|_+$/g, "") || "mcp";
}

/** Resolve a relative or absolute MCP server URL against window.location or a base URL. */
export function resolveMcpServerUrl(url: string, baseUrl?: string): string {
  if (/^https?:\/\//i.test(url)) {
    return url;
  }
  const base = baseUrl ?? (typeof window !== "undefined" ? window.location.href : "http://localhost");
  return new URL(url, base).href;
}

/** Format MCP content blocks into a single ToolOutcome string. */
export function formatMcpContent(content: McpContentBlock[] | undefined): string {
  if (!content || content.length === 0) {
    return "";
  }
  const texts = content
    .filter((b) => b.type === "text" && typeof b.text === "string")
    .map((b) => b.text as string);
  return texts.join("\n").trim();
}

/** Map an MCP tool definition to a CustomToolDef with prefixed name and draft-07 inputSchema. */
export function mapMcpToolToCustomToolDef(
  serverName: string,
  mcpTool: McpToolInfo,
  callToolFn: (args: Record<string, unknown>) => Promise<McpCallToolResult>,
): CustomToolDef {
  const prefix = sanitizeServerName(serverName);
  const toolName = `${prefix}_${mcpTool.name}`;
  const inputSchema = (mcpTool.inputSchema as JsonSchemaObject) ?? { type: "object", properties: {} };

  return {
    name: toolName,
    description: mcpTool.description ?? `MCP tool ${mcpTool.name} from ${serverName}`,
    inputSchema,
    execute: async (input: Record<string, unknown>): Promise<ToolOutcome> => {
      try {
        const res = await callToolFn(input);
        const contentStr = formatMcpContent(res.content);
        return {
          content: contentStr,
          isError: res.isError ?? false,
        };
      } catch (err: unknown) {
        return {
          content: err instanceof Error ? err.message : String(err),
          isError: true,
        };
      }
    },
  };
}

/** Connect to a remote MCP server via StreamableHTTPClientTransport and discover tools. */
export async function connectMcpClient(
  serverName: string,
  serverUrl: string,
  options?: ConnectMcpOptions,
): Promise<McpClientSession> {
  const resolvedUrl = resolveMcpServerUrl(serverUrl);

  // Literal specifiers only — a variable specifier here makes webpack emit
  // "Critical dependency: the request of a dependency is an expression" and
  // drop the module from the build (see task 004).
  const { Client } = await import(
    /* webpackChunkName: "mcp-sdk-client" */
    "@modelcontextprotocol/sdk/client/index.js"
  );
  const { StreamableHTTPClientTransport } = await import(
    /* webpackChunkName: "mcp-sdk-transport" */
    "@modelcontextprotocol/sdk/client/streamableHttp.js"
  );

  const transport = new StreamableHTTPClientTransport(new URL(resolvedUrl), {
    fetch: options?.fetch,
  });

  const client = new Client(
    {
      name: options?.clientName ?? "web-agent-client",
      version: options?.clientVersion ?? "0.1.0",
    },
    { capabilities: {} },
  );

  await client.connect(transport);

  const toolsResult = await client.listTools();
  const rawTools: McpToolInfo[] = toolsResult?.tools ?? [];

  const tools: CustomToolDef[] = rawTools.map((t) =>
    mapMcpToolToCustomToolDef(serverName, t, (args) =>
      client.callTool({ name: t.name, arguments: args }),
    ),
  );

  return {
    serverName,
    serverUrl: resolvedUrl,
    tools,
    client,
    transport,
    close: async () => {
      await client.close();
    },
  };
}
