import type { CustomToolDef } from "../tools/build-tools.js";
import {
  connectMcpClient,
  type ConnectMcpOptions,
  type McpClientSession,
} from "./client.js";

/**
 * One remote MCP server a host wants the agent to use.
 *
 * All four fields are required on purpose: `required` has **no default**, so a
 * host must state its degrade intent explicitly rather than inherit one.
 *
 * `url` may be relative (e.g. "/mcp"); it is resolved against the page origin by
 * {@link resolveMcpServerUrl}. A same-origin relative path avoids CORS entirely.
 *
 * Servers are connected **once, at session start**. Assigning `mcpServers` after
 * the session exists does not reconnect.
 */
export interface McpServerConfig {
  /** Short id; also the tool-name prefix after sanitization ("cat-store" → "cat_store_"). */
  name: string;
  /** What this group of tools is for. Surfaced to the model as a tool guideline. */
  description: string;
  /** Streamable-HTTP MCP endpoint. Absolute, or relative to the page origin. */
  url: string;
  /** true → a connect/discover failure is a hard startup error. false → logged and skipped. */
  required: boolean;
}

export interface McpServerFailure {
  server: McpServerConfig;
  error: unknown;
}

export interface ConnectMcpServersResult {
  /** Tools from every server that connected, in configured order. */
  tools: CustomToolDef[];
  /** Open sessions, so the caller can close them on dispose. */
  sessions: McpClientSession[];
  /** Every server that failed (optional ones only — a required failure throws). */
  failures: McpServerFailure[];
}

/** Thrown when a server declared `required: true` fails to connect or discover. */
export class McpRequiredServerError extends Error {
  readonly failures: McpServerFailure[];
  constructor(failures: McpServerFailure[]) {
    const detail = failures
      .map((f) => `"${f.server.name}" (${f.server.url}): ${errText(f.error)}`)
      .join("; ");
    super(`Required MCP server(s) failed to connect — ${detail}`);
    this.name = "McpRequiredServerError";
    this.failures = failures;
  }
}

function errText(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

/**
 * Connect to every configured MCP server **concurrently** and collect their tools.
 *
 * - Every connect is started in the same tick, so a slow server never serialises a fast one.
 * - A `required: false` server that fails is `console.warn`-logged and contributes no tools.
 * - If any `required: true` server fails, every session opened by this call is closed and
 *   an {@link McpRequiredServerError} is thrown.
 */
export async function connectMcpServers(
  servers: McpServerConfig[] | undefined,
  options?: ConnectMcpOptions & {
    /** Test seam: overrides the network call. Defaults to `connectMcpClient`. */
    connect?: typeof connectMcpClient;
  },
): Promise<ConnectMcpServersResult> {
  if (!servers || servers.length === 0) {
    return { tools: [], sessions: [], failures: [] };
  }

  const connect = options?.connect ?? connectMcpClient;
  const settled = await Promise.allSettled(
    servers.map((s) => connect(s.name, s.url, options)),
  );

  const tools: CustomToolDef[] = [];
  const sessions: McpClientSession[] = [];
  const failures: McpServerFailure[] = [];
  const requiredFailures: McpServerFailure[] = [];

  for (let i = 0; i < servers.length; i++) {
    const server = servers[i];
    const outcome = settled[i];
    if (outcome.status === "fulfilled") {
      const session = outcome.value;
      sessions.push(session);
      // Identical snippet on every tool from this server: buildSystemPromptParts
      // de-duplicates identical snippet strings (system-prompt.ts:99), so this
      // yields exactly one "# Tool guidelines" line per server.
      const snippet = `${server.name} (MCP server) — ${server.description}`;
      for (const t of session.tools) {
        tools.push({ ...t, promptSnippet: snippet });
      }
      continue;
    }
    const failure: McpServerFailure = { server, error: outcome.reason };
    if (server.required) {
      requiredFailures.push(failure);
    } else {
      failures.push(failure);
      console.warn(
        `[mcp] optional server "${server.name}" (${server.url}) failed to connect — ` +
          `its tools are unavailable this session: ${errText(outcome.reason)}`,
        outcome.reason,
      );
    }
  }

  if (requiredFailures.length > 0) {
    await Promise.allSettled(sessions.map((s) => s.close()));
    throw new McpRequiredServerError(requiredFailures);
  }

  return { tools, sessions, failures };
}
