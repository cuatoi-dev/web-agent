import { z } from "zod";

export const FormFieldSchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("text"),
    name: z.string(),
    label: z.string(),
    placeholder: z.string().optional(),
    required: z.boolean().optional(),
  }),
  z.object({
    kind: z.literal("number"),
    name: z.string(),
    label: z.string(),
    min: z.number().optional(),
    max: z.number().optional(),
    required: z.boolean().optional(),
  }),
  z.object({
    kind: z.literal("select"),
    name: z.string(),
    label: z.string(),
    options: z.array(z.string()),
    default: z.string().optional(),
  }),
  z.object({
    kind: z.literal("checkbox"),
    name: z.string(),
    label: z.string(),
    default: z.boolean().optional(),
  }),
  z.object({
    kind: z.literal("date"),
    name: z.string(),
    label: z.string(),
    required: z.boolean().optional(),
  }),
]);

export const FormBlockSchema = z.object({
  type: z.literal("form"),
  id: z.string(),
  title: z.string().optional(),
  fields: z.array(FormFieldSchema),
  submit_label: z.string().optional(),
});

export const ButtonsBlockSchema = z.object({
  type: z.literal("buttons"),
  options: z.array(
    z.object({
      label: z.string(),
      prompt: z.string().max(500),
    })
  ).max(6),
});

// A block whose `type` core does not know (e.g. the chart block which lives
// in its own package). Validate only that it carries a string
// `type`; pass every other field through unchanged so a host/package-defined
// block flows through core → lit without core knowing its shape. Core-owned
// blocks keep their strong schemas above.
export const PluginBlockSchema = z.object({ type: z.string() }).passthrough();

export const UIBlockSchema = z.discriminatedUnion("type", [
  FormBlockSchema,
  ButtonsBlockSchema,
]);

// Full renderable-block validator. Strong core union FIRST (a valid core block
// matches its strong schema), plugin passthrough LAST (an unknown `type` still
// validates instead of failing). z.union tries options in order and returns the
// first success — order matters: putting PluginBlockSchema first would let a
// malformed core block slip through as a plugin block.
export const RenderableBlockSchema = z.union([UIBlockSchema, PluginBlockSchema]);

export type UIBlock = FormBlock | ButtonsBlock;

export interface FormBlock {
  type: "form";
  id: string;
  title?: string;
  fields: FormField[];
  submit_label?: string;
}

export type FormField =
  | { kind: "text"; name: string; label: string; placeholder?: string; required?: boolean }
  | { kind: "number"; name: string; label: string; min?: number; max?: number; required?: boolean }
  | { kind: "select"; name: string; label: string; options: string[]; default?: string }
  | { kind: "checkbox"; name: string; label: string; default?: boolean }
  | { kind: "date"; name: string; label: string; required?: boolean };

export interface ButtonsBlock {
  type: "buttons";
  options: { label: string; prompt: string }[];
}

export interface ErrorCardBlock {
  type: "error_card";
  raw: string;
  error: string;
}

// TS shape of a package/host-contributed block core doesn't own. The index
// signature is required: it keeps existing `block.type === "error_card"`
// narrowing in lit's BlockRendererRegistry compiling (block.error / block.raw
// resolve to `unknown` rather than a "property does not exist" error) and lets
// package blocks carry arbitrary fields. Runtime validation is PluginBlockSchema.
export interface PluginBlock {
  type: string;
  [key: string]: unknown;
}

export type RenderableBlock = UIBlock | ErrorCardBlock | PluginBlock;
