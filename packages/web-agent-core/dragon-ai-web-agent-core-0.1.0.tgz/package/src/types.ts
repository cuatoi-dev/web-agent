export type TextPart             = { type: "text";              text: string };
export type ImagePart            = { type: "image";             image: string; mediaType: string };
export type FilePart             = { type: "file";              data: string;  mediaType: string };
export type ToolCallPart         = { type: "tool-call";         toolCallId: string; toolName: string; input: Record<string, unknown> };
export type ToolResultPart       = { type: "tool-result";       toolCallId: string; toolName: string; output: unknown; isError?: boolean };
export type ThinkingPart         = { type: "thinking";          thinking: string; signature: string };
export type RedactedThinkingPart = { type: "redacted_thinking"; data: string };
export type ContentPart          = TextPart | ImagePart | FilePart | ToolCallPart | ToolResultPart | ThinkingPart | RedactedThinkingPart;

export type ModelMessage =
  | { role: "user";      content: string | ContentPart[]; providerOptions?: Record<string, unknown> }
  | { role: "assistant"; content: string | ContentPart[]; providerOptions?: Record<string, unknown> }
  | { role: "tool";      content: ContentPart[];          providerOptions?: Record<string, unknown> }
  | { role: "system";    content: string | ContentPart[]; providerOptions?: Record<string, unknown> };

export interface Tool {
  name: string;
  description: string;
  input_schema: { type: "object"; [key: string]: unknown };
}

export type ToolExecutor = (
  input: Record<string, unknown>,
  options: { abortSignal?: AbortSignal; toolCallId: string },
) => Promise<string>;

export interface TextBlock             { type: "text";              text: string }
export interface ThinkingBlock         { type: "thinking";          thinking: string; signature?: string }
export interface ToolUseBlock          { type: "tool_use";          id: string; name: string; input: Record<string, unknown> }
export interface RedactedThinkingBlock { type: "redacted_thinking"; data: string }
export type ResponseBlock = TextBlock | ThinkingBlock | ToolUseBlock | RedactedThinkingBlock;

export type StopReason = "end_turn" | "tool_use" | "max_tokens" | "stop_sequence" | "error";

export interface GenerateResult {
  content: ResponseBlock[];
  stopReason: StopReason;
  usage: {
    inputTokens: number;
    outputTokens: number;
    cacheReadTokens?: number;
    cacheCreationTokens?: number;
  };
}

export interface ToolResultRecord {
  toolCallId: string;
  toolName: string;
  output: string;
  isError?: boolean;
}
