import type { ConfirmInteractionFn } from "./adapters/permission-resolver.js";
import type { SessionStore } from "./loop/session-store.js";

export interface ContextConfig {
  kObsWindow: number;
  kTurnsVerbatim: number;
  contextLength: number;
  autoCompactPercent: number;
  hardPercent: number;
  panicPercent: number;
  charsPerToken: number;
  jsonOverhead: number;
  compactionModel: string;
  compactionMaxTokens: number;
  passes: { p1: boolean; p2: boolean; p3: boolean; p4: boolean; p5: boolean };
  mode?: "assert" | "warn";
}

export interface GenerationConfig {
  temperature?: number;
  topP?: number;
  topK?: number;
  maxOutputTokens?: number;
  stopSequences?: string[];
  frequencyPenalty?: number;
  presencePenalty?: number;
  seed?: number;
  maxRetries?: number;
}

/** Kinds of adapter actions that can be cued visually by the agent cursor. */
export type CueKind = "click" | "fill" | "select" | "see";

/** Host-configurable agent-cursor behavior. */
export interface CuesConfig {
  /** Master on/off for the agent cursor (was mode: "off"). Default true. */
  enabled?: boolean;
  /** Cursor travel + typing pace (replaces speedMs/dwellMs/"demo"|"instant"). */
  speed?: "slow" | "fast";
}

export interface SpeedPreset { travelPxPerSec: number; msPerWord: number; }
export const SPEED_PRESETS: Record<"slow" | "fast", SpeedPreset> = {
  slow: { travelPxPerSec: 600,  msPerWord: 220 },
  fast: { travelPxPerSec: 1400, msPerWord: 90 },
};

export interface ImageConfig {
  /** Longest edge in px. Images wider/taller are scaled down. Default 1024. */
  maxDimension?: number;
  /** Max encoded byte size after downscaling (bytes). Default 524288 (512 KB). */
  maxBytes?: number;
  /** JPEG/WebP re-encode quality 0–1. Default 0.82. */
  quality?: number;
}

/** A user-selectable model entry for the runtime model switcher (067). */
export interface ModelOption {
  /** Backend model id sent on the wire (e.g. "m"). */
  id: string;
  /** Friendly display label (e.g. "Leo"). Falls back to `id` when omitted. */
  label?: string;
}

export interface AgentConfig {
  baseURL: string;
  model: string;
  maxIterations: number;
  turnTimeoutMs: number;
  snapshotMaxChars: number;
  snapshotMaxDepth?: number;
  snapshotSubtreeMaxNodes?: number;
  snapshotMaxNodes?: number;
  queryResultMaxChars: number;
  context: ContextConfig;
  persist: boolean;
  /** Confirmation hook for "ask" permission tier. When set, the adapter awaits this before proceeding. */
  confirmInteraction?: ConfirmInteractionFn;
  /** Endpoint type: "anthropic" (default), "openai", or "mock" (deterministic e2e). */
  endpointType: "openai" | "anthropic" | "mock";
  /** Thinking config (anthropic endpoint only; openai ignores it). */
  thinking: { enabled: boolean; budgetTokens?: number };
  /** Standard Vercel AI SDK generation knobs. */
  generation: GenerationConfig;
  /** Extra instructions appended to the built system prompt. */
  appendSystemPrompt?: string;
  /** Guidelines for the generated UI blocks. */
  blockGuidelines?: string;
  /** Agent-cursor cues config. Optional; defaults to `{ enabled: true, speed: "slow" }`. */
  cues?: CuesConfig;
  /** Host-configurable image downscaling limits applied before images enter a message. */
  images?: ImageConfig;
  /**
   * Host capability toggle. When false, hides image attach UI, disables
   * paste/drag ingest, and omits the `see` tool and its prompt snippet.
   * Default true.
   */
  imageInput?: boolean;
  /**
   * Host-supplied list of user-selectable models for the runtime model switcher
   * (067-ui). UI-only metadata — the transport ignores it; the active model is
   * `model`. When fewer than 2 entries, 067-ui hides the switcher.
   */
  models?: ModelOption[];
  /**
   * Host-supplied tool composition. Returns the FULL explicit tool-def list for
   * a turn (spread the exported builders, e.g. `[...defaultTools(ctx), myTool]`).
   * When unset, core uses `defaultTools` (the pre-refactor built-in toolset).
   */
  tools?: (ctx: import("./tools/build-tools.js").ToolContext) => import("./tools/build-tools.js").CustomToolDef[];
  /** Host-supplied skill composition. Default coreSkills(). */
  skills?: import("./tools/build-tools.js").SkillDef[];
  /**
   * Remote MCP servers to connect at session start. Every server is connected
   * **concurrently** and its tools are appended to whatever `tools` produced,
   * prefixed with the sanitized server name (`cat-store` → `cat_store_<tool>`).
   *
   * A server with `required: true` that fails to connect is a hard startup error
   * (the session's `initPromise` rejects and `state.error` is set). A server with
   * `required: false` that fails is logged and contributes no tools.
   *
   * Connect happens **once**, at session start — assigning this after the session
   * exists does not reconnect.
   */
  mcpServers?: import("./mcp/connect-servers.js").McpServerConfig[];
  /**
   * When true, uses `messages.stream().finalMessage()` instead of `messages.create()`.
   * Required for gateways (e.g. 9router) that only return valid Anthropic format over SSE.
   * Default false (non-streaming) so existing hosts are unaffected.
   */
  streaming?: boolean;
  /**
   * Per-request timeout (ms) applied by the withRetry transport middleware. A
   * request whose stream/response does not complete within this window is
   * aborted and (if retries remain) retried. Default 30000.
   */
  requestTimeoutMs?: number;
  /**
   * Max transport-level retries (withRetry middleware) for empty/dead streams
   * and transient network/parse failures. Default 2. Deterministic client
   * errors (400/401/403) and user aborts are never retried.
   */
  maxRetries?: number;
  /**
   * Called just before the withRetry transport middleware sleeps ahead of a
   * retry attempt. `attempt` is 1-based (1..maxRetries); `error` is the
   * classified failure that triggered the retry.
   */
  onRetryAttempt?: (attempt: number, maxRetries: number, error: unknown) => void;
  /**
   * Host-swappable session persistence seam. When set, core (task 002)
   * will call createSession/appendMessages/saveMeta at turn boundaries.
   * Omit to disable multi-session persistence (default: undefined).
   *
   * @deprecated or whatever
   */
  sessionStore?: SessionStore;
  /**
   * Namespace for the default IdbSessionStore. When set, sessions are stored in
   * a separate IndexedDB DB ("web-agent-<namespace>") isolated from other hosts
   * sharing the same origin. Ignored when `sessionStore` is supplied by the host.
   */
  sessionNamespace?: string;
}

/**
 * Return the default proxy base URL for a given endpoint type.
 */
export function defaultBaseURLFor(type: "anthropic" | "openai"): string {
  return type === "anthropic" ? "/api/anthropic/v1" : "/api/openai/v1";
}

export const DEFAULT_CONTEXT_CONFIG: ContextConfig = {
  kObsWindow: 2,
  kTurnsVerbatim: 3,
  contextLength: 128_000,
  autoCompactPercent: 0.75,
  hardPercent: 0.85,
  panicPercent: 0.95,
  charsPerToken: 4,
  jsonOverhead: 1.15,
  compactionModel: "gpt-oss:120b-cloud",
  compactionMaxTokens: 700,
  passes: { p1: true, p2: true, p3: true, p4: true, p5: true },
};

export const DEFAULT_CONFIG: AgentConfig = {
  model: "gpt-oss:120b-cloud",
  baseURL: "/api/anthropic/v1",
  maxIterations: 50,
  turnTimeoutMs: 120_000,
  snapshotMaxChars: 12_000,
  snapshotMaxDepth: 12,
  snapshotSubtreeMaxNodes: 50,
  snapshotMaxNodes: 400,
  queryResultMaxChars: 6_000,
  persist: false,
  context: DEFAULT_CONTEXT_CONFIG,
  endpointType: "anthropic",
  thinking: { enabled: false },
  generation: { maxOutputTokens: 4096, maxRetries: 3 },
  cues: { enabled: true, speed: "slow" },
  images: { maxDimension: 1024, maxBytes: 512 * 1024, quality: 0.82 },
  imageInput: true,
  streaming: false,
  requestTimeoutMs: 30_000,
  maxRetries: 5,
  appendSystemPrompt: undefined,
};

/**
 * Resolve a model id to its friendly label from the host `models` list.
 * Falls back to the raw id when the id is absent or has no label.
 */
export function resolveModelLabel(models: ModelOption[] | undefined, id: string): string {
  const hit = models?.find((m) => m.id === id);
  return hit?.label || id;
}
