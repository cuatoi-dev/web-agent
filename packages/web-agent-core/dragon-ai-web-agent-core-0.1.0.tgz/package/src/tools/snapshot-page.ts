import type { ToolOutcome, ToolContext } from "./build-tools.js";

/** Dispatch to domAdapter.snapshot(). */
export async function runSnapshotPage(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  const result = await ctx.domAdapter.snapshot(
    input as { scope?: string; interactive_only?: boolean },
  );
  return { content: result };
}
