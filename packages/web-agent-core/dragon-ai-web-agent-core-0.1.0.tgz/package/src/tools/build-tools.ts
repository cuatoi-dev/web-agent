import { z } from "zod";
import { zodToJsonSchema } from "zod-to-json-schema";
import type { Tool, ToolExecutor } from "../types.js";

import { runSnapshotPage } from "./snapshot-page.js";
import { runQueryState } from "./query-state.js";
import { runClick } from "./click.js";
import { runFill } from "./fill.js";
import { runSelectOption } from "./select-option.js";
import { runWaitFor } from "./wait-for.js";
import { runWait } from "./wait.js";
import { runSee } from "./see.js";
import { runListDataSources } from "./list-data-sources.js";
import { runQueryData } from "./query-data.js";
import { runShowGenerativeUi } from "./show-generative-ui.js";
import type { DomAdapter } from "../adapters/dom-adapter.js";
import type { StateAdapter } from "../adapters/state-adapter.js";
import type { DataSourceProvider } from "../datasource/provider.js";
import type { RenderableBlock } from "../ui-blocks/schema.js";

export interface ToolOutcome {
  content: string;
  isError?: boolean;
  _screenshot?: { dataUrl: string; mediaType: string };
  block?: RenderableBlock;
}

export interface ToolContext {
  domAdapter: DomAdapter;
  stateAdapter: StateAdapter;
  dataSource?: DataSourceProvider;
  app: AppContext;
  signal: AbortSignal;
  _pendingScreenshot?: { dataUrl: string; mediaType: string } | null;
  imageInput?: boolean;
  skills?: SkillDef[];
  _onToolBlock?: (toolCallId: string, block: RenderableBlock) => void;
};

export interface AppContext {
  appName?: string;
  appDescription?: string;
  appInstructions?: string;
  route?: string;
  stateShapeSummary?: string;
  /** Host-supplied display name for the current user, e.g. "Alex". */
  userName?: string;
  /**
   * Freestyle background info about the current user (e.g. preferences).
   * Treated as data, not instructions, in the prompt. Keep it short —
   * under ~200 characters — it's re-sent on every turn.
   */
  userInfo?: string;
}

/**
 * Optional host-supplied friendly renderer for a custom tool-call row.
 * Returns SIMPLE inline HTML (`<i>`/`<b>`/`<em>`/`<strong>` only) — the host UI
 * sanitizes it (block-level/script/attributes stripped) before display.
 *  - `input`  : the model-provided tool arguments (same object passed to `execute`).
 *  - `result` : the tool's returned content string (i.e. `ToolOutcome.content`,
 *               surfaced as the audit `outcomeSummary`). Empty while in progress.
 * Sync only. NOTE: a tool that returns `outcome.block` renders as a UI block, not
 * a tool-step row, so its `renderer` never fires — use `renderer` for text-outcome
 * tools. The renderer is not persisted; it is re-applied on session rehydration.
 */
export type ToolRenderer = (input: Record<string, unknown>, result: string) => string;

/**
 * A raw JSON Schema object describing a tool's arguments. MCP servers advertise
 * tool schemas in draft-07; core converts them to draft 2020-12 for the model
 * (see {@link draft07ToDraft2020}) and validates arguments against the converted
 * schema before `execute` runs.
 */
export type JsonSchemaObject = { type: "object"; [key: string]: unknown };

/** A tool's argument schema: either a zod type or a raw JSON Schema object. */
export type ToolInputSchema = z.ZodType | JsonSchemaObject;

export interface CustomToolDef {
  name: string;
  description: string;
  inputSchema: ToolInputSchema;
  promptSnippet?: string;
  execute: (input: Record<string, unknown>, ctx: ToolContext) => Promise<ToolOutcome>;
  /** Optional friendly tool-call renderer — see {@link ToolRenderer}. */
  renderer?: ToolRenderer;
}

export interface SkillDef {
  name: string;
  description: string;
  definition: string;
}

function wrapExecutor(
  name: string,
  fn: (input: Record<string, unknown>, ctx: ToolContext) => Promise<ToolOutcome>,
  ctx: ToolContext,
  jsonSchema?: Tool["input_schema"],
): ToolExecutor {
  return async (
    input: Record<string, unknown>,
    options: { abortSignal?: AbortSignal; toolCallId: string },
  ): Promise<string> => {
    if (options.abortSignal?.aborted) {
      return "Tool execution aborted.";
    }
    try {
      // JSON-Schema tools only. Lazily imported so ajv stays out of core's
      // static import graph — hosts with no JSON-Schema tool never load it.
      if (jsonSchema) {
        const { validateJsonSchemaInput } = await import("./validate-json-schema.js");
        const error = await validateJsonSchemaInput(name, jsonSchema, input);
        if (error) return error;
      }
      const turnCtx: ToolContext = {
        ...ctx,
        signal: options.abortSignal ?? ctx.signal,
      };
      const outcome = await fn(input, turnCtx);
      if (outcome.block && ctx._onToolBlock) {
        ctx._onToolBlock(options.toolCallId, outcome.block);
      }
      if (outcome._screenshot) {
        ctx._pendingScreenshot = outcome._screenshot;
      }
      return outcome.content;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return msg;
    }
  };
}

export function draft07ToDraft2020(node: unknown): unknown {
  if (Array.isArray(node)) {
    return node.map(draft07ToDraft2020);
  }
  if (node !== null && typeof node === "object") {
    const obj = node as Record<string, unknown>;
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(obj)) {
      result[key] = draft07ToDraft2020(obj[key]);
    }
    if (Array.isArray(result.items)) {
      result.prefixItems = result.items;
      delete result.items;
      if ("additionalItems" in result) {
        result.items = result.additionalItems;
        delete result.additionalItems;
      }
    }
    return result;
  }
  return node;
}

function zodToInputSchema(schema: z.ZodType): Tool["input_schema"] {
  const raw = zodToJsonSchema(schema) as Record<string, unknown>;
  const { $schema, ...input_schema } = raw;
  const processed = draft07ToDraft2020(input_schema);
  return processed as Tool["input_schema"];
}

/**
 * Duck-typed, not `instanceof` — a host bundling its own copy of zod would fail an
 * `instanceof z.ZodType` check. `safeParse` is the same surface `validateInput`
 * (tools/definitions.ts) relies on.
 */
function isZodSchema(schema: ToolInputSchema): schema is z.ZodType {
  return typeof (schema as z.ZodType).safeParse === "function";
}

/** Raw JSON Schema → model-facing draft 2020-12, mirroring `zodToInputSchema`. */
function jsonSchemaToInputSchema(schema: JsonSchemaObject): Tool["input_schema"] {
  const { $schema, ...rest } = schema as Record<string, unknown>;
  return draft07ToDraft2020(rest) as Tool["input_schema"];
}

export function buildTools(
  ctx: ToolContext,
  defs: CustomToolDef[],
): { tools: Tool[]; executors: Record<string, ToolExecutor> } {
  const toolsArr: Tool[] = [];
  const executors: Record<string, ToolExecutor> = {};

  for (const def of defs) {
    if (executors[def.name]) {
      console.warn(`Tool "${def.name}" is already defined — skipping duplicate.`);
      continue;
    }
    let input_schema: Tool["input_schema"];
    let jsonSchemaForValidation: Tool["input_schema"] | undefined;
    if (isZodSchema(def.inputSchema)) {
      input_schema = zodToInputSchema(def.inputSchema);
    } else {
      input_schema = jsonSchemaToInputSchema(def.inputSchema);
      jsonSchemaForValidation = input_schema;
    }
    toolsArr.push({
      name: def.name,
      description: def.description,
      input_schema,
    });
    executors[def.name] = wrapExecutor(
      def.name,
      def.execute,
      ctx,
      jsonSchemaForValidation,
    );
  }

  return { tools: toolsArr, executors };
}

function getHandler(
  name: string,
): (input: Record<string, unknown>, ctx: ToolContext) => Promise<ToolOutcome> {
  switch (name) {
    case "snapshot_page":
      return runSnapshotPage;
    case "query_state":
      return runQueryState;
    case "click":
      return runClick;
    case "fill":
      return runFill;
    case "select_option":
      return runSelectOption;
    case "wait_for":
      return runWaitFor;
    case "wait":
      return runWait;
    case "see":
      return runSee;
    case "list_data_sources":
      return runListDataSources;
    case "query_data":
      return runQueryData;
    case "show_generative_ui":
      return runShowGenerativeUi;
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

export async function executeToolByName(
  name: string,
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  if (ctx.signal.aborted) {
    return { content: "Tool execution aborted.", isError: true };
  }
  const handler = getHandler(name);
  try {
    return await handler(input, ctx);
  } catch (err: unknown) {
    return {
      content: err instanceof Error ? err.message : String(err),
      isError: true,
    };
  }
}
