import type { ToolOutcome, ToolContext } from "./build-tools.js";

/** Dispatch to domAdapter.waitForIdle() / waitForText() or stateAdapter.waitForPathTruthy(). */
export async function runWaitFor(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  const condition = input.condition as string;
  const argument = input.argument as string | undefined;
  const timeoutMs = (input.timeout_ms as number | undefined) ?? 5000;

  let ok: boolean;
  switch (condition) {
    case "dom_idle":
      ok = await ctx.domAdapter.waitForIdle(timeoutMs, ctx.signal);
      break;
    case "text_present":
      if (!argument) {
        return { content: "text_present requires an 'argument'." };
      }
      ok = await ctx.domAdapter.waitForText(argument, timeoutMs, ctx.signal);
      break;
    case "state_path_truthy":
      if (!argument) {
        return { content: "state_path_truthy requires an 'argument' (JSONPath)." };
      }
      ok = await ctx.stateAdapter.waitForPathTruthy(argument, timeoutMs, ctx.signal);
      break;
    default:
      return { content: `Unknown condition: ${condition}.` };
  }

  if (ok) {
    return { content: `Condition "${condition}" met.` };
  }
  return { content: `Timed out after ${timeoutMs}ms waiting for ${condition}${argument ? ` "${argument}"` : ""}. Condition not met.` };
}
