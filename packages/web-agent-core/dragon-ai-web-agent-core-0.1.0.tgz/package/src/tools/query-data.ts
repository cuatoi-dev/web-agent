import type { ToolOutcome, ToolContext } from "./build-tools.js";
import { DataQuery } from "../datasource/types.js";
import { serializeResult } from "../datasource/query-engine.js";

/**
 * Executor for query_data.
 * Validates, delegates to provider, serializes with caps, honours abort signal.
 */
export async function runQueryData(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  const { dataSource } = ctx;
  if (!dataSource) {
    return { content: "Error: dataSource not available in context." };
  }

  if (ctx.signal.aborted) {
    return { content: "Tool execution aborted." };
  }

  // runQuery / aggregate / describeSource already throw descriptive errors
  // (unknown source/field, op/type mismatch, bad agg). Let them bubble to the
  // catch-all in wrapExecutor which turns them into §10-style strings.
  const result = await dataSource.query(input as unknown as DataQuery);

  if (ctx.signal.aborted) {
    return { content: "Tool execution aborted." };
  }

  // Cap at configured maxChars (default 6000)
  const maxChars = (ctx as any).queryResultMaxChars ?? 6000;
  const output = serializeResult(result, maxChars);

  return { content: output };
}
