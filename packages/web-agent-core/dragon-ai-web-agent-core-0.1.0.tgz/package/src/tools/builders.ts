import { z } from "zod";
import type { CustomToolDef, ToolContext } from "./build-tools.js";
import {
  SNAPSHOT_PAGE_DEF, QUERY_STATE_DEF, CLICK_DEF, FILL_DEF,
  SELECT_OPTION_DEF, WAIT_FOR_DEF, WAIT_DEF, SEE_DEF,
  LIST_DATA_SOURCES_DEF, QUERY_DATA_DEF, type ToolDef,
} from "./definitions.js";
import { runSnapshotPage } from "./snapshot-page.js";
import { runQueryState } from "./query-state.js";
import { runClick } from "./click.js";
import { runFill } from "./fill.js";
import { runSelectOption } from "./select-option.js";
import { runWaitFor } from "./wait-for.js";
import { runWait } from "./wait.js";
import { runSee } from "./see.js";
import { runListDataSources } from "./list-data-sources.js";
import { runQueryData } from "./query-data.js";
import { runShowGenerativeUi, SHOW_GENERATIVE_UI_SCHEMA } from "./show-generative-ui.js";

/** Convert a §5 ToolDef + its handler into a CustomToolDef. */
function fromDef(
  def: ToolDef,
  execute: CustomToolDef["execute"],
): CustomToolDef {
  return {
    name: def.name,
    description: def.description,
    inputSchema: def.inputSchema,
    promptSnippet: def.promptSnippet,
    execute,
  };
}

/** snapshot_page, query_state, and see (see is gated off when imageInput===false). */
export function domReadTools(ctx: ToolContext): CustomToolDef[] {
  const defs: CustomToolDef[] = [
    fromDef(SNAPSHOT_PAGE_DEF, runSnapshotPage),
    fromDef(QUERY_STATE_DEF, runQueryState),
  ];
  if (ctx.imageInput !== false) {
    defs.push({
      name: SEE_DEF.name,
      description: SEE_DEF.description,
      inputSchema: SEE_DEF.inputSchema,
      promptSnippet: SEE_DEF.promptSnippet,
      execute: async (input, c) => {
        const result = await runSee(input, c);
        const ss = result._screenshot!;
        return {
          content:
            "Screenshot captured. A screenshot has been added as a user image message for visual analysis.",
          _screenshot: { dataUrl: ss.dataUrl, mediaType: ss.mediaType },
        };
      },
    });
  }
  return defs;
}

/** click, fill, select_option, wait_for, wait. */
export function domWriteTools(): CustomToolDef[] {
  return [
    fromDef(CLICK_DEF, runClick),
    fromDef(FILL_DEF, runFill),
    fromDef(SELECT_OPTION_DEF, runSelectOption),
    fromDef(WAIT_FOR_DEF, runWaitFor),
    fromDef(WAIT_DEF, runWait),
  ];
}

/** list_data_sources, query_data. */
export function dataTools(): CustomToolDef[] {
  return [
    fromDef(LIST_DATA_SOURCES_DEF, runListDataSources),
    fromDef(QUERY_DATA_DEF, runQueryData),
  ];
}

/** show_generative_ui (stays in core). No prompt snippet (matches current). */
export function genuiTools(): CustomToolDef[] {
  return [
    {
      name: "show_generative_ui",
      description:
        "Present an interactive generative-UI block to the user at the current turn position. " +
        'Use type="buttons" for up to 6 quick-reply buttons, or type="form" for an input form. ' +
        "On invalid input the tool returns a precise error so you can fix and retry.",
      inputSchema: SHOW_GENERATIVE_UI_SCHEMA,
      execute: runShowGenerativeUi,
    },
  ];
}

/** search_skills, load_skill — read ctx.skills at execute time. No prompt snippet
 *  (the # Skills prompt section is rendered separately in system-prompt.ts). */
export function skillTools(): CustomToolDef[] {
  const searchSkillsSchema = z
    .object({ query: z.string().describe("Search term to match against skill names and descriptions") })
    .strict();
  const loadSkillSchema = z
    .object({ name: z.string().describe("Exact skill name as listed in # Skills") })
    .strict();
  return [
    {
      name: "search_skills",
      description:
        "Search the skill registry by name or description. Returns matching skill names and descriptions.",
      inputSchema: searchSkillsSchema,
      execute: async (input, ctx) => {
        const q = (input.query as string).toLowerCase();
        const matches = (ctx.skills ?? []).filter(
          (s) => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q),
        );
        if (matches.length === 0) return { content: "No skills matched the query." };
        return { content: matches.map((s) => `${s.name} — ${s.description}`).join("\n") };
      },
    },
    {
      name: "load_skill",
      description: "Load the full definition of a skill by exact name.",
      inputSchema: loadSkillSchema,
      execute: async (input, ctx) => {
        const skill = (ctx.skills ?? []).find((s) => s.name === (input.name as string));
        if (!skill)
          return {
            content: `Skill "${input.name}" not found. Use search_skills to discover available skills.`,
          };
        return { content: skill.definition };
      },
    },
  ];
}

/** The default preset: the full toolset core shipped before this refactor. */
export function defaultTools(ctx: ToolContext): CustomToolDef[] {
  return [
    ...domReadTools(ctx),
    ...domWriteTools(),
    ...dataTools(),
    ...genuiTools(),
    ...skillTools(),
  ];
}
