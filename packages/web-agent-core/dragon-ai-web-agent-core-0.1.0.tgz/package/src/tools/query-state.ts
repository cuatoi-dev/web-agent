import type { ToolOutcome, ToolContext } from "./build-tools.js";

/** Dispatch to stateAdapter.query(). */
export async function runQueryState(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  const result = await ctx.stateAdapter.query(
    input as { path: string; keys_only?: boolean; limit?: number },
  );
  return { content: result };
}
