import type { ToolOutcome, ToolContext } from "./build-tools.js";

/** Dispatch to domAdapter.fill(). */
export async function runFill(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  const result = await ctx.domAdapter.fill(
    input.ref as string,
    input.value as string,
    ctx.signal,
  );
  return { content: result };
}
