// §10 Tool Error Message Matrix — pure builder functions.
// Every function returns an actionable message string.
// Never build raw stack traces here.

/** Stale ref: generation mismatch. */
export function staleRef(ref: string, gen: number, cur: number): string {
  return `Ref ${ref} is stale (generation ${gen}, current ${cur}). Take a new snapshot.`;
}

/** Element disconnected from DOM. */
export function detachedRef(ref: string): string {
  return `Ref ${ref} no longer exists in the DOM. Take a new snapshot.`;
}

/** Element found but disabled. */
export function disabledRef(ref: string, name: string): string {
  return `Ref ${ref} ("${name}") is disabled. Inspect the form for unmet requirements.`;
}

/** Unknown tool name. */
export function unknownTool(name: string, list: string[]): string {
  return `Unknown tool "${name}". Available: ${list.join(", ")}.`;
}

/** Zod schema violation. */
export function schemaViolation(name: string, msg: string): string {
  return `Invalid input for ${name}: ${msg}.`;
}

/** Wait-for timeout (not an error — normal outcome). */
export function waitTimeout(ms: number, cond: string): string {
  return `Timed out after ${ms}ms waiting for ${cond}. Condition not met.`;
}

/** Invalid JSONPath expression. */
export function invalidJsonPath(reason: string): string {
  return `Invalid JSONPath: ${reason}. Paths must start with $.`;
}

/** Select-option match failure. */
export function selectOptionMissing(opt: string, options: string[]): string {
  const listed = options.slice(0, 20);
  return `No option "${opt}". Available: ${listed.join(", ")}${options.length > 20 ? ` …+${options.length - 20} more` : ""}.`;
}

/** Cross-origin navigation attempt. */
export function navigationBlocked(): string {
  return "Only same-origin paths are allowed.";
}
