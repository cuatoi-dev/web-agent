import type { ToolOutcome, ToolContext } from "./build-tools.js";

export async function runSee(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  if (ctx.signal.aborted) {
    throw new DOMException("Tool execution aborted.", "AbortError");
  }
  const ref = input.ref as string | undefined;
  const result = await ctx.domAdapter.screenshot(ref);
  return {
    content: "Screenshot captured.",
    _screenshot: result,
  };
}
