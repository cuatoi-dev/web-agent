import type { ToolOutcome, ToolContext } from "./build-tools.js";

/** Dispatch to domAdapter.selectOption(). */
export async function runSelectOption(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  const result = await ctx.domAdapter.selectOption(
    input.ref as string,
    input.option as string,
  );
  return { content: result };
}
