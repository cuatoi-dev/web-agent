import { z } from "zod";
import { FormBlockSchema, ButtonsBlockSchema } from "../ui-blocks/schema.js";
import type { ToolContext, ToolOutcome } from "./build-tools.js";
import type { RenderableBlock } from "../ui-blocks/schema.js";

const GenerativeUiBlockSchema = z.discriminatedUnion("type", [
  FormBlockSchema,
  ButtonsBlockSchema,
]);

export const SHOW_GENERATIVE_UI_SCHEMA = z
  .object({
    type: z.string().describe('Block type: "buttons" or "form"'),
    options: z
      .array(z.object({ label: z.string(), prompt: z.string() }))
      .optional()
      .describe(
        'For type="buttons": up to 6 quick-reply buttons; each {label, prompt} — prompt is the message sent when the button is clicked',
      ),
    id: z.string().optional().describe('For type="form": unique form id'),
    title: z.string().optional().describe("Optional title (form)"),
    fields: z
      .array(z.record(z.unknown()))
      .optional()
      .describe(
        'For type="form": field defs — each {kind: "text"|"number"|"select"|"checkbox"|"date", name, label, ...}',
      ),
    submit_label: z.string().optional().describe('For type="form": submit button label'),
  })
  .strict();

export async function runShowGenerativeUi(
  input: Record<string, unknown>,
  _ctx: ToolContext,
): Promise<ToolOutcome> {
  const parsed = GenerativeUiBlockSchema.safeParse(input);
  if (!parsed.success) {
    const msg = parsed.error.errors
      .map((e) => `${e.path.join(".") || "block"}: ${e.message}`)
      .join("; ");
    return { content: msg, isError: true };
  }

  const block: RenderableBlock = parsed.data as RenderableBlock;
  return { content: "ui rendered", block };
}
