import type { ToolOutcome, ToolContext } from "./build-tools.js";

/** Dispatch to domAdapter.click(). */
export async function runClick(
  input: Record<string, unknown>,
  ctx: ToolContext,
): Promise<ToolOutcome> {
  const result = await ctx.domAdapter.click(input.ref as string);
  return { content: result };
}
