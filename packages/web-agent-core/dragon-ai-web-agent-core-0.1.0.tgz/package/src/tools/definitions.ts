import { z } from "zod";
import { DataQuerySchema } from "../datasource/types.js";

// ---------------------------------------------------------------------------
// §5 Tool definitions — single source of truth for Zod schemas + metadata.
// All schemas are .strict() to reject unknown keys.
// ---------------------------------------------------------------------------

export const snapshotPageSchema = z
  .object({
    scope: z
      .string()
      .optional()
      .describe("Optional ref from a previous snapshot, e.g. '34', to snapshot only that subtree."),
    interactive_only: z
      .boolean()
      .optional()
      .describe("If true, omit non-interactive text nodes. Default false."),
  })
  .strict();

export const queryStateSchema = z
  .object({
    path: z.string().describe("JSONPath expression starting with $"),
    keys_only: z
      .boolean()
      .optional()
      .describe("Return only the keys of matched objects (for exploration). Default false."),
    limit: z
      .number()
      .int()
      .min(1)
      .max(100)
      .optional()
      .describe("Max matches to return. Default 20."),
  })
  .strict();

export const clickSchema = z
  .object({
    ref: z.string().describe("Ref number, e.g. '7'"),
  })
  .strict();

export const fillSchema = z
  .object({
    ref: z.string().describe("Ref number, e.g. '7'"),
    value: z.string().describe("Value to set"),
  })
  .strict();

export const selectOptionSchema = z
  .object({
    ref: z.string().describe("Ref number, e.g. '7'"),
    option: z.string().describe("Option label or value to select"),
  })
  .strict();

export const waitForSchema = z
  .object({
    condition: z
      .enum(["dom_idle", "text_present", "state_path_truthy"])
      .describe("What to wait for"),
    argument: z
      .string()
      .optional()
      .describe("Text for text_present; JSONPath for state_path_truthy; ignored for dom_idle."),
    timeout_ms: z
      .number()
      .int()
      .min(100)
      .max(15000)
      .optional()
      .describe("Default 5000."),
  })
  .strict();

/** Hard cap for the `wait` tool — kept as a single named constant so it's one
 *  place to change. Not host-configurable (see refine plan's decision). */
export const WAIT_MAX_SECONDS = 30;

export const waitSchema = z
  .object({
    seconds: z
      .number()
      .int()
      .min(1)
      .max(WAIT_MAX_SECONDS)
      .describe(`Seconds to pause, unconditionally. 1-${WAIT_MAX_SECONDS}.`),
  })
  .strict();

export const seeSchema = z
  .object({
    ref: z
      .string()
      .optional()
      .describe("Ref from a snapshot to screenshot just that element; omit for the whole visible page."),
  })
  .strict();

// ---------------------------------------------------------------------------
// Tool descriptor — carries everything needed by the SDK + system-prompt builder.
// ---------------------------------------------------------------------------
export interface ToolDef {
  name: string;
  description: string;
  inputSchema: z.ZodType;
  /** Prose snippet that the system-prompt builder (§7) can insert. */
  promptSnippet: string;
}

// ---------------------------------------------------------------------------
// The seven §5 tools.
// ---------------------------------------------------------------------------
export const SNAPSHOT_PAGE_DEF: ToolDef = {
  name: "snapshot_page",
  description:
    "Take a snapshot of the page as a compact, breadth-first outline. Interactive elements (and any collapsed container) get numbered refs like [12]. Large subtrees are shown shallow: a collapsed node ends with '… +N nodes hidden — snapshot_page(scope=\"<ref>\") to expand'. To see inside, call snapshot_page again with scope set to that ref — do NOT blindly re-snapshot the whole page. You MUST snapshot before click/fill/select_option; refs are only valid from the most recent snapshot.",
  inputSchema: snapshotPageSchema,
  promptSnippet:
    "snapshot_page: observe the page as a shallow tree. Collapsed nodes show '+N nodes hidden — snapshot_page(scope=\"<ref>\")'; drill in with that scope instead of re-snapshotting. interactive_only skips text.",
};

export const QUERY_STATE_DEF: ToolDef = {
  name: "query_state",
  description:
    "Query the application's Redux state with a JSONPath expression. Returns matching values as JSON. Results are truncated; use narrower paths or 'keys_only' to explore large objects. Examples: '$.orders.items[*].status', '$.user.profile', '$..error'.",
  inputSchema: queryStateSchema,
  promptSnippet:
    "query_state: explore Redux state with JSONPath. Use keys_only for exploration, limit to cap results.",
};

export const CLICK_DEF: ToolDef = {
  name: "click",
  description:
    "Click an interactive element by its ref from the MOST RECENT snapshot.",
  inputSchema: clickSchema,
  promptSnippet:
    "click: activate an element by its snapshot ref.",
};

export const FILL_DEF: ToolDef = {
  name: "fill",
  description:
    "Set the value of a text input, textarea, or contenteditable identified by ref, replacing existing content.",
  inputSchema: fillSchema,
  promptSnippet:
    "fill: type a value into a form field by ref. Replaces existing content.",
};

export const SELECT_OPTION_DEF: ToolDef = {
  name: "select_option",
  description:
    "Choose an option in a native <select> by visible label or value.",
  inputSchema: selectOptionSchema,
  promptSnippet:
    "select_option: pick an option in a native select by label or value.",
};

export const WAIT_FOR_DEF: ToolDef = {
  name: "wait_for",
  description:
    "Wait until a condition is met. Use after actions that trigger async updates.",
  inputSchema: waitForSchema,
  promptSnippet:
    "wait_for: pause until dom_idle, text_present, or state_path_truthy. Timeout is not an error — report what happened.",
};

export const WAIT_DEF: ToolDef = {
  name: "wait",
  description:
    `Pause for a fixed number of seconds (1-${WAIT_MAX_SECONDS}), unconditionally. ` +
    "Use only when there is no observable condition to wait on — prefer wait_for when one exists.",
  inputSchema: waitSchema,
  promptSnippet:
    `wait: pause for a fixed number of seconds (max ${WAIT_MAX_SECONDS}s) with no condition to check. ` +
    "Prefer wait_for when a condition is knowable; use wait only for genuine unconditional pacing.",
};

export const SEE_DEF: ToolDef = {
  name: "see",
  description:
    "Render the page (or an element by ref) to an image and look at it. Use when layout, appearance, colors, charts, or visual details matter and the text snapshot is insufficient.",
  inputSchema: seeSchema,
  promptSnippet:
    "see: visually inspect the page when appearance matters; prefer snapshot_page for structure/refs.",
};

// ---------------------------------------------------------------------------
// §9 Data-source tools
// ---------------------------------------------------------------------------
export const listDataSourcesSchema = z
  .object({
    source: z.string().optional().describe("Optional source name to describe a specific data source."),
  })
  .strict();

export const queryDataSchema = DataQuerySchema;

export const LIST_DATA_SOURCES_DEF: ToolDef = {
  name: "list_data_sources",
  description:
    "List available data sources and their schemas (fields + row counts). If 'source' is given, describe that source in detail.",
  inputSchema: listDataSourcesSchema,
  promptSnippet:
    "list_data_sources: discover available data sources (orders, products, cart) and their field schemas.",
};

export const QUERY_DATA_DEF: ToolDef = {
  name: "query_data",
  description:
    "Query a data source. Supports filtering (Mongo-like $and/$or/$gt/$lt/$in/$regex…), sorting, pagination (offset/limit), and Cube-style aggregation (groupBy + measures + having + sort + limit). Returns rows as JSON. Prefer this over query_state for tabular/aggregated data.",
  inputSchema: queryDataSchema,
  promptSnippet:
    "query_data: read/filter/aggregate data from a source. Supports MongoDB-style filters, Cube aggregation, offset/limit pagination.",
};

// ---------------------------------------------------------------------------
// Lookup convenience.
// ---------------------------------------------------------------------------
export const TOOL_DEFS: Record<string, ToolDef> = {
  snapshot_page: SNAPSHOT_PAGE_DEF,
  query_state: QUERY_STATE_DEF,
  click: CLICK_DEF,
  fill: FILL_DEF,
  select_option: SELECT_OPTION_DEF,
  wait_for: WAIT_FOR_DEF,
  wait: WAIT_DEF,
  see: SEE_DEF,
  list_data_sources: LIST_DATA_SOURCES_DEF,
  query_data: QUERY_DATA_DEF,
};

export const TOOL_NAMES: string[] = Object.keys(TOOL_DEFS);

// ---------------------------------------------------------------------------
// Schema-based input validation (§11.3 AC).
// Returns { ok: true, value } or { ok: false, message }.
// ---------------------------------------------------------------------------
export function validateInput(
  name: string,
  raw: unknown,
): { ok: true; value: Record<string, unknown> } | { ok: false; message: string } {
  const def = TOOL_DEFS[name];
  if (!def) {
    const available = TOOL_NAMES;
    return { ok: false, message: `Unknown tool "${name}". Available: ${available.join(", ")}.` };
  }
  const parsed = def.inputSchema.safeParse(raw);
  if (!parsed.success) {
    const flat = parsed.error.flatten();
    const issues = [...(flat.formErrors ?? []), ...Object.values(flat.fieldErrors ?? {}).flat()];
    const msg = issues.join("; ");
    return {
      ok: false,
      message: `Invalid input for ${name}: ${msg}.`,
    };
  }
  return { ok: true, value: parsed.data as Record<string, unknown> };
}
