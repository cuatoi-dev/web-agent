/** Limits that control automatic image downscaling before it enters a message. */
export interface ImageLimits {
  /** Longest edge (px). Images wider/taller than this are scaled down. Default 1024. */
  maxDimension?: number;
  /** Max encoded byte size of the final base64 data-URL (bytes). Default 512 KB. */
  maxBytes?: number;
  /** JPEG/WebP quality 0–1. Default 0.82. */
  quality?: number;
}

export const DEFAULT_IMAGE_LIMITS: ImageLimits = {
  maxDimension: 1024,
  maxBytes: 512 * 1024,  // 512 KB
  quality: 0.82,
};

/**
 * Downscale a data-URL image using an OffscreenCanvas (browser) or HTMLCanvasElement
 * (jsdom). Returns a new data-URL that fits within the given limits.
 *
 * Algorithm:
 *   1. Decode the data-URL into an Image / ImageBitmap.
 *   2. If max(w, h) > maxDimension → scale both sides proportionally so the
 *      longest edge equals maxDimension.
 *   3. Draw onto a canvas and re-encode as image/jpeg at `quality`.
 *   4. If the result still exceeds maxBytes, reduce quality by 0.1 and retry
 *      (floor at quality 0.3 to avoid unrecognisable output).
 *   5. Return the resulting data-URL.
 *
 * Environment notes:
 *   - Browser: uses OffscreenCanvas when available, falls back to HTMLCanvasElement.
 *   - Node/jsdom (tests): HTMLCanvasElement.toDataURL is a no-op in jsdom — the
 *     function still resolves, returning the (mock) data-URL unchanged, so tests
 *     can stub window.HTMLCanvasElement or mock this module entirely.
 *
 * @param dataUrl   Original data-URL (data:image/...;base64,...).
 * @param limits    Scaling limits (merged with DEFAULT_IMAGE_LIMITS).
 * @returns         Promise resolving to a downscaled data-URL.
 */
/**
 * Load an image into an ImageBitmap, falling back to HTMLImageElement + canvas
 * if createImageBitmap fails (e.g., Chromium rejects 1x1 PNGs).
 */
async function loadImageAsBitmap(
  dataUrl: string,
  maxDimension?: number,
): Promise<{ bitmap: ImageBitmap; width: number; height: number }> {
  const res = await fetch(dataUrl);
  const blob = await res.blob();

  // Primary path: createImageBitmap (fastest, most memory-efficient)
  try {
    const bmp = await createImageBitmap(blob);
    return { bitmap: bmp, width: bmp.width, height: bmp.height };
  } catch {
    // Fallback: decode via HTMLImageElement (handles degenerate sizes)
  }

  // Fallback: HTMLImageElement → canvas → ImageBitmap
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image();
    i.onload = () => resolve(i);
    i.onerror = () => reject(new Error("Image decode failed"));
    i.src = dataUrl;
  });

  let w = img.naturalWidth;
  let h = img.naturalHeight;
  if (maxDimension) {
    const longest = Math.max(w, h);
    if (longest > maxDimension) {
      const scale = maxDimension / longest;
      w = Math.round(w * scale);
      h = Math.round(h * scale);
    }
  }

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, w, h);
  const bmp = await createImageBitmap(canvas);
  return { bitmap: bmp, width: w, height: h };
}

export async function downscaleImage(
  dataUrl: string,
  limits: ImageLimits = {},
): Promise<string> {
  const { maxDimension, maxBytes, quality } = { ...DEFAULT_IMAGE_LIMITS, ...limits };

  // --- jsdom / no-createImageBitmap guard ---
  if (typeof createImageBitmap === "undefined") {
    // Test/jsdom environment: can't decode, return original.
    return dataUrl;
  }

  // --- load image (with createImageBitmap fallback) ---
  let loaded: { bitmap: ImageBitmap; width: number; height: number };
  try {
    loaded = await loadImageAsBitmap(dataUrl, maxDimension);
  } catch {
    // If even the fallback fails, return original unchanged.
    return dataUrl;
  }

  const { bitmap: srcBmp, width: srcW, height: srcH } = loaded;

  // --- compute target dimensions ---
  let dstW = srcW;
  let dstH = srcH;
  if (dstW <= 0 || dstH <= 0) return dataUrl; // degenerate
  const longest = Math.max(srcW, srcH);
  if (maxDimension && longest > maxDimension) {
    const scale = maxDimension / longest;
    dstW = Math.round(srcW * scale);
    dstH = Math.round(srcH * scale);
  }

  // --- draw & encode ---
  async function encode(q: number): Promise<string> {
    let canvas: HTMLCanvasElement | OffscreenCanvas;
    let ctx2d: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;

    if (typeof OffscreenCanvas !== "undefined") {
      canvas = new OffscreenCanvas(dstW, dstH);
      ctx2d = canvas.getContext("2d") as OffscreenCanvasRenderingContext2D;
    } else {
      canvas = document.createElement("canvas");
      (canvas as HTMLCanvasElement).width = dstW;
      (canvas as HTMLCanvasElement).height = dstH;
      ctx2d = (canvas as HTMLCanvasElement).getContext("2d")!;
    }

    ctx2d.drawImage(srcBmp as any, 0, 0, dstW, dstH);

    if (canvas instanceof OffscreenCanvas) {
      const outBlob = await canvas.convertToBlob({ type: "image/jpeg", quality: q });
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(outBlob);
      });
    } else {
      return (canvas as HTMLCanvasElement).toDataURL("image/jpeg", q);
    }
  }

  let q = quality ?? 0.82;
  let result = await encode(q);

  // --- byte-size reduction loop ---
  if (maxBytes) {
    let byteSize = (result.length - result.indexOf(",") - 1) * 0.75;
    while (byteSize > maxBytes && q > 0.3) {
      q = Math.max(q - 0.1, 0.3);
      result = await encode(q);
      byteSize = (result.length - result.indexOf(",") - 1) * 0.75;
      if (byteSize <= maxBytes) break;
    }
  }

  srcBmp.close();
  return result;
}
