/** A single image attachment. mediaType is the MIME type (e.g. "image/png"). */
export interface ImageAttachment {
  dataUrl: string;
  mediaType: string;   // e.g. "image/png", "image/jpeg", "image/webp"
}

/**
 * Richer user-message input: text (required) plus optional image attachments.
 * Pass a plain `string` anywhere this type is accepted as a convenience —
 * call sites normalise via `normaliseInput()`.
 */
export interface UserMessageInput {
  text: string;
  images?: ImageAttachment[];
  /** 016-2: role/name of each pinned element folded into `text` as a
   *  "# Pointed elements" block — carried separately so the journal can
   *  render a chip-only bubble instead of the raw block. */
  pointedItems?: { role: string; name: string }[];
  /** 016-2: the user's original typed prose, BEFORE the pointed-elements
   *  block was appended to `text` for the LLM. Empty string for an
   *  empty-pick send ("tell me about these" with no text). Only meaningful
   *  when `pointedItems` is set. */
  userDisplayText?: string;
}

/** Normalise a string | UserMessageInput to UserMessageInput. */
export function normaliseInput(input: string | UserMessageInput): UserMessageInput {
  if (typeof input === "string") return { text: input };
  return input;
}

/**
 * Build the AI SDK `content` array for a user message.
 * - If no images: returns the plain string (avoid wrapping in an array when
 *   unnecessary).
 * - If images present: returns a parts array:
 *     [{type:"text", text}, {type:"image", image: dataUrl, mediaType}, ...]
 */
export function buildUserContent(
  input: UserMessageInput,
): string | Array<{ type: string; [k: string]: unknown }> {
  if (!input.images || input.images.length === 0) {
    return input.text;
  }
  const parts: Array<{ type: string; [k: string]: unknown }> = [
    { type: "text", text: input.text },
  ];
  for (const img of input.images) {
    parts.push({ type: "image", image: img.dataUrl, mediaType: img.mediaType });
  }
  return parts;
}
