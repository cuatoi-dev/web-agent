export { createPageAgent, runBareTurn, buildGenerateSettings, createLlmSummarizer } from "./loop/agent.js";
export { runTurn } from "./loop/run-turn.js";
export type { UserMessageInput, ImageAttachment } from "./utils/types.js";
export { normaliseInput, buildUserContent } from "./utils/types.js";
export { downscaleImage } from "./utils/image.js";
export type { ImageLimits } from "./utils/image.js";
export type { ImageConfig, CueKind, CuesConfig, SpeedPreset, ModelOption } from "./config.js";
export { SPEED_PRESETS, resolveModelLabel } from "./config.js";
export { ContextManager } from "./loop/context-manager.js";
export type { JournalEntry, AuditEntry } from "./loop/context-manager.js";
export type { SessionStore, SessionMeta } from "./loop/session-store.js";
export { IdbSessionStore } from "./loop/session-store.js";
export type { TurnFlushRecord } from "./loop/session-lifecycle.js";
export { buildFlushRecord, reconstructState } from "./loop/session-lifecycle.js";

export { buildTools } from "./tools/build-tools.js";
export type {
  ToolContext,
  CustomToolDef,
  ToolRenderer,
  SkillDef,
  ToolOutcome,
  ToolInputSchema,
  JsonSchemaObject,
} from "./tools/build-tools.js";
export {
  defaultTools,
  domReadTools,
  domWriteTools,
  dataTools,
  genuiTools,
  skillTools,
} from "./tools/builders.js";
export { TOOL_DEFS } from "./tools/definitions.js";
export { sampleGreetingTool, sampleQuickReplyTool } from "./tools/sample-tools.js";
export * from "./mcp/index.js";


export { DomAdapter, describeElementParts } from "./adapters/dom-adapter.js";
export type { ActionCueFn } from "./adapters/dom-adapter.js";
export { resolveAgentPermission } from "./adapters/permission-resolver.js";
export type { AgentPermission, PermissionResolution, ConfirmInteractionFn } from "./adapters/permission-resolver.js";
export { StateAdapter } from "./adapters/state-adapter.js";
export { RefTable } from "./adapters/ref-table.js";

export { createDataSourceProvider } from "./datasource/provider.js";
export type { DataSourceProvider, ProviderOptions } from "./datasource/provider.js";
export { SourceRegistry } from "./datasource/registry.js";
export type { SourceEntry } from "./datasource/registry.js";
export { runQuery, serializeResult } from "./datasource/query-engine.js";

export type {
  FieldType,
  FieldSchema,
  SourceInfo,
  Scalar,
  Condition,
  FilterExpr,
  Dimension,
  MeasureOp,
  Measure,
  Aggregation,
  DataQuery,
  QueryResult,
} from "./datasource/types.js";

export {
  DEFAULT_CONFIG,
  defaultBaseURLFor,
} from "./config.js";
export { coreSkills, DEFAULT_SKILLS } from "./skills/default-skills.js";
export type {
  AgentConfig,
  GenerationConfig,
  ContextConfig,
} from "./config.js";

export { createAnthropicClient, createOpenAIClient } from "./transport/provider.js";

export type { StreamPart } from "./transport/stream-parts.js";
export { reassembleStream } from "./transport/stream-parts.js";

export { createMockProvider, ECHO_SCRIPT } from "./transport/mock-provider.js";
export type { MockResponse, MockScript } from "./transport/mock-provider.js";
export { wrapProvider, isRetryableError } from "./transport/middleware.js";
export type { LanguageModelMiddleware } from "./transport/middleware.js";
export { setMockScript } from "./transport/registry.js";
export type { LanguageModel, ProviderCallOptions, ProviderResult } from "./transport/provider-types.js";

export { runCompaction, buildSummaryPrompt } from "./loop/compaction.js";

export { buildSystemPrompt, buildSystemPromptParts } from "./prompt/system-prompt.js";
export type { SystemPromptParts } from "./prompt/system-prompt.js";

export * from "./ui-blocks/schema.js";

export { buttonToMessage, formSubmitToMessage, isInteractive } from "./ui-blocks/bridge.js";

export {
  createAgentSession,
  type MessagePart,
  type SessionMessagePart,
  type SessionMessage,
  type SessionState,
  type SessionConfig,
  type AgentSession,
  type SessionEvent,
  type QueuedMessage,
} from "./controller.js";
