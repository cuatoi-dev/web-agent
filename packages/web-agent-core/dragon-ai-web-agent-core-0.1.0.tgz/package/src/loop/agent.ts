import { DEFAULT_CONFIG, type AgentConfig } from "../config.js";
import { AgentError, classifyHttpError, agentErrorLabel, mapToAgentError } from "./errors.js";
import { buildTools, ToolContext, AppContext } from "../tools/build-tools.js";
import { defaultTools } from "../tools/builders.js";
import { coreSkills } from "../skills/default-skills.js";
import { ContextManager, AuditEntry } from "./context-manager.js";
import { buildSystemPromptParts } from "../prompt/system-prompt.js";
import type { ModelMessage, ContentPart, ToolResultPart, ToolCallPart } from "../types.js";
import { providerRegistry } from "../transport/registry.js";
import type { LanguageModel, ProviderCallOptions } from "../transport/provider-types.js";
import { reassembleStream } from "../transport/stream-parts.js";
import type { StreamPart } from "../transport/stream-parts.js";
import type { AnthropicLanguageModel } from "../transport/anthropic-provider.js";

interface StepToolResult {
  toolCallId: string;
  toolName: string;
  input: Record<string, unknown>;
  output: string;
}

// ---------------------------------------------------------------------------
// Helper: build the standard generation settings from config + app.
// Used by BOTH runBareTurn and createPageAgent.
// ---------------------------------------------------------------------------
export function buildGenerateSettings(
  cfg: AgentConfig,
  app?: AppContext,
  toolSnippets?: string[],
  toolNames?: string[],
): {
  model: string;
  instructions: string;
  maxRetries: number;
  maxOutputTokens?: number;
  temperature?: number;
  topP?: number;
  topK?: number;
  stopSequences?: string[];
  frequencyPenalty?: number;
  presencePenalty?: number;
  seed?: number;
  /** Anthropic STATIC block (byte-stable, cache breakpoint A). undefined when no app. */
  systemStatic?: string;
  /** Anthropic DYNAMIC block (route+state, cache breakpoint B). undefined when no app. */
  systemDynamic?: string;
} {
  const gen = cfg.generation || {};

  // Build system instructions: base prompt + optional appended prompt
  const skills = cfg.skills ?? coreSkills();
  const append = cfg.appendSystemPrompt ? "\n\n" + cfg.appendSystemPrompt : "";
  const parts = app
    ? buildSystemPromptParts(app, {
        blockGuidelines: cfg.blockGuidelines,
        imageInput: cfg.imageInput,
        toolSnippets,
        skills,
        toolNames,
      })
    : undefined;
  const instructions = parts ? parts.full + append : (cfg.appendSystemPrompt || "");

  return {
    model: cfg.model,
    instructions,
    // Anthropic cache split (append belongs in the STATIC block — it is stable)
    systemStatic: parts ? parts.static + append : undefined,
    systemDynamic: parts ? parts.dynamic : undefined,
    // Generation knobs
    temperature: gen.temperature,
    topP: gen.topP,
    topK: gen.topK,
    maxOutputTokens: gen.maxOutputTokens,
    stopSequences: gen.stopSequences,
    frequencyPenalty: gen.frequencyPenalty,
    presencePenalty: gen.presencePenalty,
    seed: gen.seed,
    maxRetries: gen.maxRetries ?? 3,
  };
}

// Helper to derive audits from step result
function deriveAudit(step: { toolResults: StepToolResult[] }): AuditEntry[] {
  const list: AuditEntry[] = [];
  const ts = Date.now();
  if (step.toolResults && Array.isArray(step.toolResults)) {
    for (const tr of step.toolResults) {
      let outputVal = "";
      if (tr.output !== undefined && tr.output !== null) {
        if (typeof tr.output === "string") {
          outputVal = tr.output;
        } else if (typeof tr.output === "object") {
          if ("value" in tr.output) {
            outputVal = String((tr.output as any).value);
          } else if ("content" in tr.output) {
            outputVal = String((tr.output as any).content);
          } else {
            outputVal = JSON.stringify(tr.output);
          }
        } else {
          outputVal = String(tr.output);
        }
      }

      list.push({
        ts,
        name: tr.toolName,
        input: tr.input,
        outcomeSummary: outputVal,
      });
    }
  }
  return list;
}

// Tees each part to the callback then re-yields it, for the onStreamPart seam.
async function* tapStream<T>(
  iter: AsyncIterable<T>,
  fn: (item: T) => void,
): AsyncIterable<T> {
  for await (const item of iter) {
    fn(item);
    yield item;
  }
}

export function createPageAgent(cfg: AgentConfig, ctx: ToolContext, cm: ContextManager) {
  const skills = cfg.skills ?? coreSkills();
  ctx.imageInput = ctx.imageInput ?? cfg.imageInput;
  ctx.skills = skills;
  const defs = (cfg.tools ?? defaultTools)(ctx);
  const toolSnippets = defs
    .map((d) => d.promptSnippet)
    .filter((s): s is string => !!s);
  const toolNames = defs.map((d) => d.name);
  const settings = buildGenerateSettings(cfg, ctx.app, toolSnippets, toolNames);
  const { tools: toolDefs, executors } = buildTools(ctx, defs);

  // Anthropic client — settable at runtime for tests (_client property).
  let _model: LanguageModel = providerRegistry.get(cfg, { fetch: (cfg as any).fetch });
  // Runtime-swappable active model id (067). Initialised from config; changed
  // via setModel() for the NEXT turn without rebuilding the transport/session.
  let _modelId: string = cfg.model;

  let prevMsgCount = 0;

  const agent = {
    // Backward-compat seam: tests set (agent as any)._client directly.
    // Forward the get/set to the underlying AnthropicLanguageModel._client.
    get _client() { return (_model as AnthropicLanguageModel)._client; },
    set _client(c: any) { (_model as AnthropicLanguageModel)._client = c; },
    // Advanced seam: swap the entire model (e.g. mock LanguageModel in unit tests).
    get _model() { return _model; },
    set _model(m: LanguageModel) { _model = m; },
    // Runtime model swap (067): read the active id, or change it for the next turn.
    get modelId() { return _modelId; },
    setModel(id: string) { _modelId = id; },

    async generate(opts: { messages: ModelMessage[]; abortSignal: AbortSignal; onStreamPart?: (part: StreamPart) => void; onStep?: () => void }) {
      const { abortSignal } = opts;
      const workingMessages: ModelMessage[] = [...opts.messages];
      const accumulatedMessages: ModelMessage[] = [];
      const steps: Array<{
        finishReason: "tool-calls" | "stop";
        usage: {
          inputTokens: number;
          outputTokens: number;
          cacheReadTokens?: number;
          cacheCreationTokens?: number;
        };
      }> = [];

      prevMsgCount = 0; // reset per generate() call (prepareStep stepNumber===0 equiv)

      for (let i = 0; i < cfg.maxIterations; i++) {
        // ---- prepareStep equivalent ----
        // screenshot inject: when the `see` tool captured a screenshot in the previous step,
        // append a user image message so the model can see it in this LLM call.
        let stepMessages = workingMessages;
        if (ctx._pendingScreenshot && workingMessages.length > 0) {
          const ss = ctx._pendingScreenshot;
          ctx._pendingScreenshot = null;
          stepMessages = [
            ...workingMessages,
            {
              role: "user" as const,
              content: [
                { type: "image" as const, image: ss.dataUrl, mediaType: ss.mediaType },
                { type: "text" as const, text: "Screenshot of the page for visual analysis." },
              ],
            },
          ];
        }

        // Convert our messages to Anthropic format.
        // System messages (if any) are extracted; instructions from settings are used as
        // the primary system prompt.
        const systemPrompt = settings.instructions || "";

        const thinkingEnabled = !!cfg.thinking?.enabled;
        const anthropicPO: Record<string, unknown> = {};
        if (settings.systemStatic) {
          anthropicPO.systemStatic = settings.systemStatic;
          if (settings.systemDynamic) anthropicPO.systemDynamic = settings.systemDynamic;
        }
        if (thinkingEnabled) {
          anthropicPO.thinking = { type: "enabled", budget_tokens: cfg.thinking?.budgetTokens ?? 1024 };
        }
        const callOpts: ProviderCallOptions = {
          messages: stepMessages,
          systemPrompt: systemPrompt,
          model: _modelId,
          tools: toolDefs.length > 0 ? toolDefs : undefined,
          maxOutputTokens: settings.maxOutputTokens ?? 4096,
          ...(Object.keys(anthropicPO).length ? { providerOptions: { anthropic: anthropicPO } } : {}),
          ...(thinkingEnabled
            ? {}
            : { temperature: settings.temperature, topP: settings.topP, topK: settings.topK }),
          stopSequences: settings.stopSequences,
          streaming: cfg.streaming,
          abortSignal,
        };

        let genResult: import("../transport/provider-types.js").ProviderResult;
        try {
          if (abortSignal.aborted) {
            throw new DOMException("The user aborted a request.", "AbortError");
          }
          if (cfg.streaming && _model.doStream && opts.onStreamPart) {
            const { stream } = await _model.doStream(callOpts);
            genResult = await reassembleStream(tapStream(stream, opts.onStreamPart));
          } else {
            genResult = await _model.generate(callOpts);
          }
        } catch (err) {
          throw mapToAgentError(err);
        }

        const stepUsage = {
          inputTokens: genResult.usage.inputTokens,
          outputTokens: genResult.usage.outputTokens,
          cacheReadTokens: genResult.usage.cachedInputTokens,   // normalized rename
          cacheCreationTokens: genResult.usage.cacheCreationTokens,
        };
        cm.recordUsage(stepUsage);

        // ---- Build assistant message ----
        const assistantContent: ContentPart[] = [];
        for (const block of genResult.content) {
          if (block.type === "text") {
            assistantContent.push({ type: "text", text: block.text });
          } else if (block.type === "tool_use") {
            assistantContent.push({
              type: "tool-call",
              toolCallId: block.id,
              toolName: block.name,
              input: block.input,
            } as ToolCallPart);
          } else if (block.type === "thinking") {
            assistantContent.push({
              type: "thinking",
              thinking: block.thinking,
              signature: block.signature ?? "",
            });
          } else if (block.type === "redacted_thinking") {
            assistantContent.push({
              type: "redacted_thinking",
              data: block.data,
            });
          }
        }
        const assistantMsg: ModelMessage = { role: "assistant", content: assistantContent };
        const stepNewMessages: ModelMessage[] = [assistantMsg];
        const stepToolResults: StepToolResult[] = [];

        // ---- Execute tools if stop_reason === tool_use ----
        if (genResult.finishReason === "tool-calls") {
          const toolResultParts: ToolResultPart[] = [];
          for (const block of genResult.content) {
            if (block.type !== "tool_use") continue;
            const executor = executors[block.name];
            let output: string;
            if (executor) {
              output = await executor(block.input, {
                abortSignal,
                toolCallId: block.id,
              });
            } else {
              output = `Unknown tool: ${block.name}`;
            }
            toolResultParts.push({
              type: "tool-result",
              toolCallId: block.id,
              toolName: block.name,
              output,
            });
            stepToolResults.push({
              toolCallId: block.id,
              toolName: block.name,
              input: block.input,
              output,
            });
          }
          stepNewMessages.push({ role: "tool", content: toolResultParts });
        }

        // Append new messages to the working conversation (feeds next iteration)
        workingMessages.push(...stepNewMessages);
        // Track all new messages accumulated this turn (for response.messages + delta)
        accumulatedMessages.push(...stepNewMessages);

        // ---- onStepFinish equivalent: delta-slice + cm.recordStep ----
        const delta = accumulatedMessages.slice(prevMsgCount);
        prevMsgCount = accumulatedMessages.length;
        cm.recordStep(delta, deriveAudit({ toolResults: stepToolResults }));
        // Live repaint seam (074): let the host repaint the transcript the moment
        // this step's messages are journaled, instead of waiting for turn end.
        opts.onStep?.();

        steps.push({
          finishReason: genResult.finishReason === "tool-calls" ? "tool-calls" : "stop",
          usage: stepUsage,
        });

        if (genResult.finishReason !== "tool-calls") break;
      }

      // Extract final text from the last assistant message in workingMessages
      const lastMsg = workingMessages[workingMessages.length - 1];
      let text = "";
      if (lastMsg?.role === "assistant") {
        const parts = Array.isArray(lastMsg.content) ? (lastMsg.content as ContentPart[]) : [];
        text = parts
          .filter((p): p is Extract<ContentPart, { type: "text" }> => p.type === "text")
          .map((p) => p.text)
          .join("");
      }

      return {
        text,
        response: { messages: accumulatedMessages },
        steps,
      };
    },
  };

  return agent;
}

export function createLlmSummarizer(cfg: AgentConfig): (prompt: string) => Promise<string> {
  return (prompt: string) =>
    runBareTurn(prompt, {
      ...cfg,
      model: cfg.context.compactionModel || cfg.model,
      generation: { ...cfg.generation, maxOutputTokens: cfg.context.compactionMaxTokens || 700 },
    });
}

/**
 * Run a bare, zero-tool single turn.
 * Returns the assistant text reply.
 */
export async function runBareTurn(
  prompt: string,
  cfg: AgentConfig = DEFAULT_CONFIG,
  opts?: { fetch?: typeof fetch; signal?: AbortSignal },
): Promise<string> {
  const settings = buildGenerateSettings(cfg, undefined);
  const model = providerRegistry.get(cfg, { fetch: opts?.fetch });
  const thinkingEnabled = !!cfg.thinking?.enabled;

  if (opts?.signal?.aborted) {
    throw new AgentError(agentErrorLabel("aborted"), "aborted");
  }

  const callOpts: ProviderCallOptions = {
    messages: [{ role: "user", content: prompt }],
    model: cfg.model,
    maxOutputTokens: settings.maxOutputTokens ?? 4096,
    ...(settings.instructions ? { systemPrompt: settings.instructions } : {}),
    ...(thinkingEnabled
      ? { providerOptions: { anthropic: { thinking: { type: "enabled", budget_tokens: cfg.thinking?.budgetTokens ?? 1024 } } } }
      : {
          temperature: settings.temperature,
          topP: settings.topP,
          topK: settings.topK,
        }),
    stopSequences: settings.stopSequences,
    streaming: cfg.streaming,
    abortSignal: opts?.signal,
  };

  try {
    const result = await model.generate(callOpts);
    return result.content
      .filter((b): b is import("../types.js").TextBlock => b.type === "text")
      .map((b) => b.text)
      .join("");
  } catch (err: unknown) {
    throw mapToAgentError(err);
  }
}
