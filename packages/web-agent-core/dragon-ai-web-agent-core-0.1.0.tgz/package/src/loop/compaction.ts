import type { ContextManager } from "./context-manager.js";

export type Summarize = (prompt: string) => Promise<string>;

export function buildSummaryPrompt(existingMemo: string | null, serializedTurns: string): string {
  if (existingMemo) {
    return `You need to update the existing conversation summary with the new turns provided below.
Follow the update rules:
- PRESERVE: Retain goals, constraints, and decisions that are still active and relevant.
- ADD: Integrate new progress, decisions, next steps, and values/actions from the new turns.
- UPDATE: Move next steps to progress if completed, and update current status.

<previous-summary>
${existingMemo}
</previous-summary>

New Turns to compact:
${serializedTurns}

Please provide the updated structured summary incorporating these new turns.`;
  } else {
    return `You need to create a new structured conversation summary from the turns provided below.
Turns to compact:
${serializedTurns}

Please provide the structured summary.`;
  }
}

export async function runCompaction(
  cm: ContextManager,
  opts: { summarize: Summarize; timeoutMs?: number }
): Promise<boolean> {
  const timeoutMs = opts.timeoutMs ?? 10000;
  try {
    const toCompact = cm.turnsToCompact();
    if (toCompact.turnIds.length === 0) {
      return false;
    }

    const lastTurnId = toCompact.turnIds[toCompact.turnIds.length - 1];
    const existingMemoText = cm.memo ? cm.memo.text : null;
    const prompt = buildSummaryPrompt(existingMemoText, toCompact.serialized);

    const summarizePromise = opts.summarize(prompt);
    let timerId: any;
    const timeoutPromise = new Promise<string>((_, reject) => {
      timerId = setTimeout(() => reject(new Error("Compaction timeout")), timeoutMs);
    });

    const summaryText = await Promise.race([
      summarizePromise.then((res) => {
        clearTimeout(timerId);
        return res;
      }),
      timeoutPromise
    ]);

    const nextVersion = (cm.memo?.version ?? 0) + 1;
    cm.setMemo({
      version: nextVersion,
      coveredThroughTurnId: lastTurnId,
      text: summaryText
    });
    cm.clearNeedsCompaction();
    return true;
  } catch (err) {
    return false;
  }
}

let inFlight = false;

export function maybeScheduleCompaction(
  cm: ContextManager,
  opts: { summarize: Summarize; timeoutMs?: number }
): boolean {
  if (inFlight) {
    return false;
  }

  const needsComp = cm.needsCompaction || cm.completedTurnsSinceMemo() > 10;
  if (!needsComp) {
    return false;
  }

  inFlight = true;

  setTimeout(async () => {
    try {
      await runCompaction(cm, opts);
    } finally {
      inFlight = false;
    }
  }, 0);

  return true;
}

// Export internal state for tests
export function getInFlightStatus(): boolean {
  return inFlight;
}

export function resetInFlight(): void {
  inFlight = false;
}
