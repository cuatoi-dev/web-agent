import type { JournalEntry, AuditEntry, Memo } from "./context-manager.js";

export interface TurnFlushRecord {
  _kind: "turn_flush";
  journalDelta: JournalEntry[];
  memo: Memo | null;
  audit: AuditEntry[];
}

export function buildFlushRecord(
  journalDelta: JournalEntry[],
  memo: Memo | null,
  audit: AuditEntry[]
): TurnFlushRecord {
  return { _kind: "turn_flush", journalDelta, memo, audit };
}

export function reconstructState(records: any[]): {
  journal: JournalEntry[];
  memo: Memo | null;
  audit: AuditEntry[];
} {
  const flushRecords = records.filter(
    (r): r is TurnFlushRecord => r?._kind === "turn_flush"
  );
  const journal: JournalEntry[] = flushRecords.flatMap(r => r.journalDelta);
  const last = flushRecords[flushRecords.length - 1];
  return {
    journal,
    memo: last?.memo ?? null,
    audit: last?.audit ?? [],
  };
}
