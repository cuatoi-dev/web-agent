import { AgentError } from "./errors.js";
import { ContextManager } from "./context-manager.js";
import { ToolContext } from "../tools/build-tools.js";
import { maybeScheduleCompaction } from "./compaction.js";
import { createLlmSummarizer } from "./agent.js";
import { AgentConfig } from "../config.js";
import { normaliseInput, buildUserContent, UserMessageInput } from "../utils/types.js";
import { downscaleImage } from "../utils/image.js";

export interface TurnResult {
  assistantText: string;
  blocks: unknown[];
  stopReason: "end_turn" | "max_iterations" | "aborted" | "error";
  error?: AgentError;
  usage?: { input: number; output: number };
}

export async function runTurn(
  agent: any,
  cm: ContextManager,
  ctx: ToolContext,
  userInput: string | UserMessageInput,
  signal: AbortSignal,
  cfg: AgentConfig,
  onStep?: () => void
): Promise<TurnResult> {
  // 1. Reassign signal per turn (F5)
  ctx.signal = signal;

  // 2. Normalise input, downscale images, build content, append user message
  const input = normaliseInput(userInput);
  if (input.images && input.images.length > 0 && cfg.images) {
    input.images = await Promise.all(
      input.images.map((img) =>
        downscaleImage(img.dataUrl, cfg.images!).then((scaled) => ({
          ...img,
          dataUrl: scaled,
        }))
      )
    );
  }
  const content = buildUserContent(input);
  cm.appendUser({ role: "user", content: content as any }, input.pointedItems, input.userDisplayText);

  try {
    if (signal.aborted) {
      throw new DOMException("The user aborted a request.", "AbortError");
    }

    // 3. Generate
    const result = await agent.generate({
      messages: cm.compose(),
      abortSignal: signal,
      onStep,
    });

    // 4. Commit turn (idempotent additions)
    cm.commitTurn(result.response.messages);

    // 5. Compaction (fire-and-forget)
    const summarize = createLlmSummarizer(cfg);
    maybeScheduleCompaction(cm, { summarize });

    // Determine stopReason
    let stopReason: TurnResult["stopReason"] = "end_turn";
    if (result.steps && result.steps.length > 0) {
      const lastStep = result.steps[result.steps.length - 1];
      if (lastStep.finishReason === "tool-calls" && result.steps.length >= cfg.maxIterations) {
        stopReason = "max_iterations";
      }
    }

    // Extract token usage
    let promptTokens = 0;
    let completionTokens = 0;
    if (result.steps && Array.isArray(result.steps)) {
      for (const step of result.steps) {
        if (step.usage) {
          promptTokens += (step.usage.inputTokens ?? 0) + (step.usage.cacheReadTokens ?? 0) + (step.usage.cacheCreationTokens ?? 0);
          completionTokens += step.usage.outputTokens ?? step.usage.completionTokens ?? 0;
        }
      }
    } else if (result.usage) {
      promptTokens = (result.usage.inputTokens ?? result.usage.promptTokens ?? 0) + (result.usage.cacheReadTokens ?? 0) + (result.usage.cacheCreationTokens ?? 0);
      completionTokens = result.usage.outputTokens ?? result.usage.completionTokens ?? 0;
    }

    return {
      assistantText: result.text || "",
      blocks: [],
      stopReason,
      usage: { input: promptTokens, output: completionTokens }
    };
  } catch (err: any) {
    let isAbort = false;
    if (err instanceof DOMException && err.name === "AbortError") {
      isAbort = true;
    } else if (err instanceof Error && err.name === "AbortError") {
      isAbort = true;
    } else if (err && err.name === "AbortError") {
      isAbort = true;
    } else if (err instanceof AgentError && err.kind === "aborted") {
      isAbort = true;
    }

    if (isAbort) {
      return {
        assistantText: "",
        blocks: [],
        stopReason: "aborted",
        error: new AgentError("Turn was aborted.", "aborted")
      };
    }

    const agentErr = err instanceof AgentError
      ? err
      : new AgentError(err instanceof Error ? err.message : String(err), "network");

    return {
      assistantText: "",
      blocks: [],
      stopReason: "error",
      error: agentErr
    };
  }
}
