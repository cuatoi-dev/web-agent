import { get, set, del, createStore } from "idb-keyval";
import type { UseStore } from "idb-keyval";

const INDEX_KEY = "web-agent-session-index";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface SessionMeta {
  id: string;
  title: string;
  titleManual: boolean; // true when user has explicitly named the session
  createdAt: number;    // Unix ms
  updatedAt: number;    // Unix ms
  messageCount: number;
}

export interface SessionStore {
  createSession(meta: SessionMeta): Promise<void>;
  appendMessages(sessionId: string, messages: any[]): Promise<void>;
  overwriteMessages(sessionId: string, messages: any[]): Promise<void>;
  saveMeta(sessionId: string, meta: Partial<SessionMeta>): Promise<void>;
  loadAllMetadata(): Promise<SessionMeta[]>;
  loadMessages(sessionId: string): Promise<any[]>;
  deleteByIds(ids: string[]): Promise<void>;
}

// ---------------------------------------------------------------------------
// Default IndexedDB-backed implementation
// ---------------------------------------------------------------------------

export class IdbSessionStore implements SessionStore {
  private readonly _store: UseStore | undefined;

  constructor(namespace?: string) {
    this._store = namespace
      ? createStore(`web-agent-${namespace}`, "sessions")
      : undefined;
  }

  async createSession(meta: SessionMeta): Promise<void> {
    const index: SessionMeta[] = (await get(INDEX_KEY, this._store)) ?? [];
    if (!index.find(m => m.id === meta.id)) {
      index.push(meta);
      await set(INDEX_KEY, index, this._store);
    }
  }

  async appendMessages(sessionId: string, messages: any[]): Promise<void> {
    if (!messages.length) return;
    const key = `session-msgs-${sessionId}`;
    const existing: any[] = (await get(key, this._store)) ?? [];
    await set(key, [...existing, ...messages], this._store);
  }

  async overwriteMessages(sessionId: string, messages: any[]): Promise<void> {
    const key = `session-msgs-${sessionId}`;
    await set(key, messages, this._store);
  }

  async saveMeta(sessionId: string, meta: Partial<SessionMeta>): Promise<void> {
    const index: SessionMeta[] = (await get(INDEX_KEY, this._store)) ?? [];
    const idx = index.findIndex(m => m.id === sessionId);
    if (idx !== -1) {
      index[idx] = { ...index[idx], ...meta };
      await set(INDEX_KEY, index, this._store);
    }
  }

  async loadAllMetadata(): Promise<SessionMeta[]> {
    const index: SessionMeta[] = (await get(INDEX_KEY, this._store)) ?? [];
    return [...index].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  async loadMessages(sessionId: string): Promise<any[]> {
    return (await get(`session-msgs-${sessionId}`, this._store)) ?? [];
  }

  async deleteByIds(ids: string[]): Promise<void> {
    const index: SessionMeta[] = (await get(INDEX_KEY, this._store)) ?? [];
    await set(INDEX_KEY, index.filter(m => !ids.includes(m.id)), this._store);
    await Promise.all(ids.map(id => del(`session-msgs-${id}`, this._store)));
  }
}
