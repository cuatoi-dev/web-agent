import type { ModelMessage } from "../types.js";
import { ContextConfig, DEFAULT_CONTEXT_CONFIG } from "../config.js";

const isDev = (() => {
  try {
    if (typeof process !== "undefined" && process.env && process.env.NODE_ENV) {
      return process.env.NODE_ENV !== "production";
    }
  } catch {}
  try {
    if (typeof import.meta !== "undefined" && (import.meta as any).env) {
      return !!(import.meta as any).env.DEV;
    }
  } catch {}
  return true;
})();

export type PartKind =
  | "user_prose"
  | "ui_action"
  | "assistant_prose"
  | "assistant_ui_block"
  | "tool_call"
  | "tool_result_snapshot"
  | "tool_result_query"
  | "tool_result_action"
  | "tool_result_wait"
  | "summary_stub";

export interface JournalEntry {
  msg: ModelMessage;            // verbatim
  meta: {
    turnId: string;            // one user turn = one id
    stepNo: number;            // step index within the turn
    kinds: PartKind[];         // per content part (P0)
    chars: number;             // serialized length (token proxy)
    toolName?: string;         // for tool parts
    generation?: number;       // for snapshot/query results
    createdAt: number;
    failed?: { message: string; retryable: boolean };
    /** 016-2: set only on the initiating user entry of a pointed send. */
    pointedItems?: { role: string; name: string }[];
    /** 016-2: user's typed prose before the pointed-elements block was
     *  appended for the LLM (may be ""). Only meaningful with pointedItems. */
    userDisplayText?: string;
  };
}

export interface AuditEntry {
  ts: number;
  name: string;
  input: unknown;
  outcomeSummary: string;
}

export interface Memo {
  version: number;
  coveredThroughTurnId: string;
  text: string;
}

/** Helper to extract raw text from tool result output. */
function getOutputText(output: unknown): string {
  if (typeof output === "string") return output;
  if (output && typeof output === "object") {
    if ("value" in output && typeof (output as any).value === "string") {
      return (output as any).value;
    }
    if ("content" in output && typeof (output as any).content === "string") {
      return (output as any).content;
    }
  }
  return "";
}

/** P0 Classify part helper. */
export function classifyParts(msg: ModelMessage): PartKind[] {
  const content = msg.content;
  const role = msg.role;

  if (typeof content === "string") {
    if (role === "user") {
      return [content.startsWith("[ui_action:") ? "ui_action" : "user_prose"];
    } else if (role === "assistant") {
      return [content.includes("```ui") ? "assistant_ui_block" : "assistant_prose"];
    }
    return ["user_prose"];
  }

  if (Array.isArray(content)) {
    return content.map((part) => {
      if (part.type === "text") {
        const text = part.text || "";
        if (role === "user") {
          return text.startsWith("[ui_action:") ? "ui_action" : "user_prose";
        } else if (role === "assistant") {
          return text.includes("```ui") ? "assistant_ui_block" : "assistant_prose";
        }
        return "user_prose";
      } else if (part.type === "tool-call") {
        return "tool_call";
      } else if (part.type === "thinking" || part.type === "redacted_thinking") {
        return "assistant_prose";
      } else if (part.type === "image") {
        return "user_prose";
      } else if (part.type === "tool-result") {
        const toolName = part.toolName;
        if (toolName === "snapshot_page") {
          return "tool_result_snapshot";
        } else if (toolName === "query_state") {
          return "tool_result_query";
        } else if (
          toolName === "click" ||
          toolName === "fill" ||
          toolName === "select_option"
        ) {
          return "tool_result_action";
        } else if (toolName === "wait_for") {
          return "tool_result_wait";
        }
        return "tool_result_action";
      }
      if (role === "user") return "user_prose";
      if (role === "assistant") return "assistant_prose";
      return "user_prose";
    });
  }

  return ["user_prose"];
}

function extractMeta(msg: ModelMessage, turnId: string, stepNo: number): JournalEntry["meta"] {
  const kinds = classifyParts(msg);
  const chars = JSON.stringify(msg).length;
  
  let toolName: string | undefined;
  let generation: number | undefined;

  if (msg.role === "tool") {
    if (Array.isArray(msg.content) && msg.content.length > 0) {
      const first = msg.content[0];
      if (first.type === "tool-result") {
        toolName = first.toolName;
        if (toolName === "snapshot_page") {
          const val = getOutputText(first.output);
          const match = val.match(/generation:\s*(\d+)/i);
          if (match) {
            generation = parseInt(match[1], 10);
          }
        }
      }
    }
  } else if (msg.role === "assistant") {
    if (Array.isArray(msg.content)) {
      const firstCall = msg.content.find((part) => part.type === "tool-call");
      if (firstCall && firstCall.type === "tool-call") {
        toolName = firstCall.toolName;
      }
    }
  }

  return {
    turnId,
    stepNo,
    kinds,
    chars,
    toolName,
    generation,
    createdAt: Date.now(),
  };
}

function cloneJournal(journal: JournalEntry[]): JournalEntry[] {
  return journal.map((entry) => {
    let clonedContent: any;
    if (typeof entry.msg.content === "string") {
      clonedContent = entry.msg.content;
    } else if (Array.isArray(entry.msg.content)) {
      clonedContent = entry.msg.content.map((part) => {
        const clonedPart = { ...part };
        if (clonedPart.type === "tool-result" && clonedPart.output && typeof clonedPart.output === "object") {
          clonedPart.output = { ...clonedPart.output };
        }
        return clonedPart;
      });
    }

    return {
      msg: {
        role: entry.msg.role,
        content: clonedContent,
        ...(entry.msg.providerOptions ? { providerOptions: { ...entry.msg.providerOptions } } : {}),
      } as ModelMessage,
      meta: { ...entry.meta, kinds: [...entry.meta.kinds] },
    };
  });
}

function trimUiBlocksText(text: string): string {
  return text.replace(/```ui\s*([\s\S]*?)\s*```/g, (match, body) => {
    let type = "custom";
    let title = "Untitled";
    try {
      const parsed = JSON.parse(body.trim());
      if (parsed && typeof parsed === "object") {
        if (parsed.type) type = String(parsed.type);
        if (parsed.title) title = String(parsed.title);
      }
    } catch (e) {
      const typeMatch = body.match(/"type"\s*:\s*"([^"]+)"/);
      if (typeMatch) type = typeMatch[1];
      const titleMatch = body.match(/"title"\s*:\s*"([^"]+)"/);
      if (titleMatch) title = titleMatch[1];
    }
    return `[ui block: ${type} "${title}" rendered to user]`;
  });
}

function formatAuditEntry(ae: AuditEntry): string {
  const input = (ae.input || {}) as any;
  const summary = ae.outcomeSummary || "";

  if (ae.name === "snapshot_page") {
    return "snapshot";
  }
  if (ae.name === "query_state") {
    return `queried "${input.path || ""}"`;
  }
  if (ae.name === "click") {
    const match = summary.match(/Clicked (?:\[\d+\] )?(.*)\.?/i);
    if (match) return `clicked ${match[1].replace(/\.$/, "").trim()}`;
    return `clicked [${input.ref}]`;
  }
  if (ae.name === "fill") {
    const match = summary.match(/Filled (?:\[\d+\] )?([^\u2192]+)\u2192/i);
    const label = match ? match[1].trim() : `[${input.ref}]`;
    return `filled ${label}="${input.value || ""}"`;
  }
  if (ae.name === "select_option") {
    const match = summary.match(/Selected "([^"]+)" in (?:\[\d+\] )?(.*)/i);
    if (match) return `selected ${match[2].replace(/\.$/, "").trim()}=${match[1]}`;
    return `selected [${input.ref}]=${input.option || ""}`;
  }
  if (ae.name === "wait_for") {
    const okSuffix = summary.includes("Timed out") ? " (timeout)" : " (ok)";
    const argStr = input.argument ? ` "${input.argument}"` : "";
    return `waited for ${input.condition}${argStr}${okSuffix}`;
  }
  return summary || ae.name;
}

function compressActions(actions: string[]): string {
  const result: string[] = [];
  let i = 0;
  while (i < actions.length) {
    let count = 1;
    while (i + 1 < actions.length && actions[i] === actions[i + 1]) {
      count++;
      i++;
    }
    if (count > 1) {
      result.push(`${actions[i]} ×${count}`);
    } else {
      result.push(actions[i]);
    }
    i++;
  }
  return result.join(", ");
}

export class ContextManager {
  #journal: JournalEntry[] = [];
  #audit: AuditEntry[] = [];
  #memo: Memo | null = null;
  #cfg: ContextConfig;
  #currentTurnId: string = "";
  #stepNo: number = 0;
  #completedTurns = new Set<string>();
  #turnAudits = new Map<string, AuditEntry[]>();
  #needsCompaction: boolean = false;
  #mode: "assert" | "warn";
  #lastKnownInputTokens: number | null = null;
  #lastKnownJournalLength: number = 0;

  constructor(cfg: ContextConfig = DEFAULT_CONTEXT_CONFIG) {
    this.#cfg = cfg;
    this.#mode = cfg.mode || (isDev ? "assert" : "warn");
  }

  recordUsage(usage: { inputTokens?: number; cacheReadTokens?: number; cacheCreationTokens?: number } | number): void {
    const total = typeof usage === "number"
      ? usage
      : (usage.inputTokens ?? 0) + (usage.cacheReadTokens ?? 0) + (usage.cacheCreationTokens ?? 0);
    this.#lastKnownInputTokens = total;
    this.#lastKnownJournalLength = this.#journal.length;
  }

  get config(): ContextConfig {
    return this.#cfg;
  }

  get mode(): "assert" | "warn" {
    return this.#mode;
  }

  set mode(val: "assert" | "warn") {
    this.#mode = val;
  }

  get journal(): JournalEntry[] {
    return this.#journal;
  }

  get audit(): AuditEntry[] {
    return this.#audit;
  }

  // 074: the id of the turn currently in flight (appended via appendUser,
  // not yet commitTurn'd). undefined when no turn is open.
  get activeTurnId(): string | undefined {
    if (this.#currentTurnId && !this.#completedTurns.has(this.#currentTurnId)) {
      return this.#currentTurnId;
    }
    return undefined;
  }

  get memo(): Memo | null {
    return this.#memo;
  }

  setMemo(m: Memo | null): void {
    this.#memo = m;
  }

  rehydrateState(journal: JournalEntry[], memo: Memo | null, audit: AuditEntry[]): void {
    this.#journal = journal;
    this.#memo = memo;
    this.#audit = audit;

    this.#completedTurns.clear();
    this.#turnAudits.clear();

    const turnIdsInJournal = new Set<string>();
    for (const entry of journal) {
      turnIdsInJournal.add(entry.meta.turnId);
    }

    for (const tid of turnIdsInJournal) {
      this.#completedTurns.add(tid);
    }

    if (journal.length > 0) {
      this.#currentTurnId = journal[journal.length - 1].meta.turnId;
      const steps = journal
        .filter((e) => e.meta.turnId === this.#currentTurnId)
        .map((e) => e.meta.stepNo);
      this.#stepNo = steps.length > 0 ? Math.max(...steps) : 0;
    }

    let auditIdx = 0;
    for (const entry of journal) {
      if (entry.msg.role === "tool" && Array.isArray(entry.msg.content)) {
        for (const part of entry.msg.content) {
          if (part.type === "tool-result") {
            const toolName = part.toolName;
            let foundAudit: AuditEntry | null = null;
            for (let k = auditIdx; k < audit.length; k++) {
              if (audit[k].name === toolName) {
                foundAudit = audit[k];
                auditIdx = k + 1;
                break;
              }
            }
            if (foundAudit) {
              const tid = entry.meta.turnId;
              if (!this.#turnAudits.has(tid)) {
                this.#turnAudits.set(tid, []);
              }
              this.#turnAudits.get(tid)!.push(foundAudit);
            }
          }
        }
      }
    }
  }

  clearNeedsCompaction(): void {
    this.#needsCompaction = false;
  }

  reset(): void {
    this.#journal = [];
    this.#audit = [];
    this.#memo = null;
    this.#currentTurnId = "";
    this.#stepNo = 0;
    this.#completedTurns.clear();
    this.#turnAudits.clear();
    this.#needsCompaction = false;
    this.#lastKnownInputTokens = null;
    this.#lastKnownJournalLength = 0;
  }

  /**
   * Discards the entire last turn (user message + any partial assistant/tool steps
   * and audits) so that the manager rehydrates identically to "that turn never happened".
   * Returns the removed journal entries to allow the caller to recover user input.
   * Shared primitive for 043 rollback and 044 retry.
   */
  truncateLastTurn(): JournalEntry[] {
    if (this.#journal.length === 0) {
      return [];
    }

    let targetTurnId = this.#currentTurnId;
    const hasTarget = targetTurnId !== "" && this.#journal.some(e => e.meta.turnId === targetTurnId);
    if (!hasTarget) {
      targetTurnId = this.#journal[this.#journal.length - 1].meta.turnId;
    }

    const targetIndex = this.#journal.findIndex(e => e.meta.turnId === targetTurnId);
    if (targetIndex === -1) {
      return [];
    }

    const removed = this.#journal.slice(targetIndex);
    this.#journal = this.#journal.slice(0, targetIndex);

    const auds = this.#turnAudits.get(targetTurnId);
    if (auds) {
      const audsSet = new Set(auds);
      this.#audit = this.#audit.filter(a => !audsSet.has(a));
      this.#turnAudits.delete(targetTurnId);
    }

    this.#completedTurns.delete(targetTurnId);

    if (this.#journal.length === 0) {
      this.#currentTurnId = "";
      this.#stepNo = 0;
    } else {
      this.#currentTurnId = this.#journal[this.#journal.length - 1].meta.turnId;
      const steps = this.#journal
        .filter((e) => e.meta.turnId === this.#currentTurnId)
        .map((e) => e.meta.stepNo);
      this.#stepNo = steps.length > 0 ? Math.max(...steps) : 0;
    }

    this.#lastKnownInputTokens = null;
    this.#lastKnownJournalLength = 0;

    // Note: 043 rollback will need to extend this if we ever roll back past the memo boundary.

    return removed;
  }

  getCompletedTurnsInOrder(): string[] {
    const list: string[] = [];
    for (const entry of this.#journal) {
      const tid = entry.meta.turnId;
      if (this.#completedTurns.has(tid) && !list.includes(tid)) {
        list.push(tid);
      }
    }
    return list;
  }

  completedTurnsSinceMemo(): number {
    const turns = this.getCompletedTurnsInOrder();
    if (!this.#memo) {
      return turns.length;
    }
    const idx = turns.indexOf(this.#memo.coveredThroughTurnId);
    if (idx === -1) return turns.length;
    return turns.length - (idx + 1);
  }

  #eligibleTurnsToCompact(): string[] {
    const allCompleted = this.getCompletedTurnsInOrder();
    const verbatim = allCompleted.slice(-this.#cfg.kTurnsVerbatim);

    let eligible = allCompleted.filter(tid => !verbatim.includes(tid));
    if (this.#memo) {
      const idx = eligible.indexOf(this.#memo.coveredThroughTurnId);
      if (idx !== -1) {
        eligible = eligible.slice(idx + 1);
      } else {
        const idxAll = allCompleted.indexOf(this.#memo.coveredThroughTurnId);
        if (idxAll !== -1) {
          eligible = eligible.filter(tid => allCompleted.indexOf(tid) > idxAll);
        }
      }
    }
    return eligible;
  }

  /** Cheap check (no serialization) for whether manual compaction would do anything. */
  hasCompactableTurns(): boolean {
    return this.#eligibleTurnsToCompact().length > 0;
  }

  turnsToCompact(): { turnIds: string[]; serialized: string } {
    const eligible = this.#eligibleTurnsToCompact();

    if (eligible.length === 0) {
      return { turnIds: [], serialized: "" };
    }

    let serialized = "";
    for (const turnId of eligible) {
      const turnEntries = this.#journal.filter(e => e.meta.turnId === turnId);
      const userMsg = turnEntries.find(e => e.msg.role === "user");
      const assistantMsg = [...turnEntries].reverse().find(e => e.msg.role === "assistant");
      
      const userText = userMsg
        ? (typeof userMsg.msg.content === "string"
          ? userMsg.msg.content
          : Array.isArray(userMsg.msg.content)
            ? userMsg.msg.content
                .map((p: any) =>
                  p.type === "text"
                    ? p.text
                    : p.type === "image"
                      ? "[image]"
                      : ""
                )
                .filter(Boolean)
                .join(" ")
            : "")
        : "";
      
      let assistantText = "";
      if (assistantMsg) {
        assistantText = typeof assistantMsg.msg.content === "string"
          ? assistantMsg.msg.content
          : Array.isArray(assistantMsg.msg.content)
            ? assistantMsg.msg.content.map((p: any) => p.type === "text" ? p.text : "").join("\n")
            : "";
      }
      
      const audits = this.#turnAudits.get(turnId) || [];
      const formattedActions = audits.map(formatAuditEntry);
      const actionsStr = formattedActions.length > 0 ? compressActions(formattedActions) : "";

      serialized += `[Turn ID: ${turnId}]\n`;
      if (userText) {
        serialized += `[User]: ${userText}\n`;
      }
      if (actionsStr) {
        serialized += `[Actions]: ${actionsStr}\n`;
      }
      if (assistantText) {
        serialized += `[Assistant]: ${trimUiBlocksText(assistantText)}\n`;
      }
      serialized += "\n";
    }

    return {
      turnIds: eligible,
      serialized: serialized.trim()
    };
  }

  get needsCompaction(): boolean {
    return this.#needsCompaction;
  }

  appendUser(
    msg: ModelMessage,
    pointedItems?: { role: string; name: string }[],
    userDisplayText?: string,
  ): void {
    this.#currentTurnId = `turn-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    this.#stepNo = 0;
    const meta = extractMeta(msg, this.#currentTurnId, this.#stepNo);
    if (pointedItems && pointedItems.length > 0) {
      meta.pointedItems = pointedItems;
      meta.userDisplayText = userDisplayText ?? "";
    }
    this.#journal.push({ msg, meta });
  }

  recordStep(messages: ModelMessage[], audit?: AuditEntry[]): void {
    this.#stepNo++;
    for (const msg of messages) {
      const meta = extractMeta(msg, this.#currentTurnId, this.#stepNo);
      this.#journal.push({ msg, meta });
    }

    if (audit) {
      for (const ae of audit) {
        this.#audit.push(ae);
        if (!this.#turnAudits.has(this.#currentTurnId)) {
          this.#turnAudits.set(this.#currentTurnId, []);
        }
        this.#turnAudits.get(this.#currentTurnId)!.push(ae);
      }
    }
  }

  commitTurn(messages?: ModelMessage[]): void {
    if (messages) {
      for (const msg of messages) {
        const alreadyExists = this.#journal.some(
          (j) => j.meta.turnId === this.#currentTurnId && JSON.stringify(j.msg) === JSON.stringify(msg)
        );
        if (!alreadyExists) {
          const meta = extractMeta(msg, this.#currentTurnId, this.#stepNo);
          this.#journal.push({ msg, meta });
        }
      }
    }
    this.#completedTurns.add(this.#currentTurnId);
  }

  estimateTokens(messages: ModelMessage[]): number {
    const chars = JSON.stringify(messages).length;
    return Math.ceil(chars / this.#cfg.charsPerToken) * this.#cfg.jsonOverhead;
  }

  get #softThreshold(): number {
    return Math.round(this.#cfg.contextLength * this.#cfg.autoCompactPercent);
  }

  get #hardThreshold(): number {
    return Math.round(this.#cfg.contextLength * this.#cfg.hardPercent);
  }

  get #panicThreshold(): number {
    return Math.round(this.#cfg.contextLength * this.#cfg.panicPercent);
  }

  #getCurrentTokenCount(lastGoodMsgs: ModelMessage[]): number {
    if (this.#lastKnownInputTokens !== null) {
      const deltaEntries = this.#journal.slice(this.#lastKnownJournalLength);
      if (deltaEntries.length === 0) {
        return this.#lastKnownInputTokens;
      }
      const deltaMsgs = deltaEntries.map((e) => e.msg);
      const deltaTokens = this.estimateTokens(deltaMsgs);
      return this.#lastKnownInputTokens + deltaTokens;
    }
    return this.estimateTokens(lastGoodMsgs);
  }

  getUsage(): { tokens: number; max: number; percent: number } {
    if (this.#journal.length === 0) {
      return { tokens: 0, max: this.#cfg.contextLength, percent: 0 };
    }
    const { lastGood } = this.#assemblePreP4();
    const tokens = this.#getCurrentTokenCount(lastGood);
    const max = this.#cfg.contextLength;
    const rawPercent = max > 0 ? tokens / max : 0;
    const percent = Math.min(Math.max(rawPercent, 0), 1);
    return { tokens, max, percent };
  }

  #convertToMessages(entries: JournalEntry[]): ModelMessage[] {
    const msgs = entries.map((e) => e.msg);
    
    const evictedCount = (entries as any).evictedCount;
    if (evictedCount && msgs.length > 0) {
      const firstUser = msgs.find((m) => m.role === "user");
      if (firstUser) {
        const stubText = this.#memo 
          ? "[earlier conversation compacted: see summary above]" 
          : `[${evictedCount} earlier turns omitted]`;
        const prefix = stubText + "\n\n";
        if (typeof firstUser.content === "string") {
          if (!firstUser.content.startsWith(stubText)) {
            firstUser.content = prefix + firstUser.content;
          }
        } else if (Array.isArray(firstUser.content)) {
          const firstText = firstUser.content.find((p) => p.type === "text") as any;
          if (firstText) {
            if (!firstText.text.startsWith(stubText)) {
              firstText.text = prefix + firstText.text;
            }
          } else {
            firstUser.content.unshift({ type: "text", text: stubText });
          }
        }
      }
    }

    if (this.#memo && msgs.length > 0) {
      const firstUser = msgs.find((m) => m.role === "user");
      if (firstUser) {
        const prefix = `[conversation summary]\n${this.#memo.text}\n\n`;
        if (typeof firstUser.content === "string") {
          if (!firstUser.content.startsWith("[conversation summary]")) {
            firstUser.content = prefix + firstUser.content;
          }
        } else if (Array.isArray(firstUser.content)) {
          const firstText = firstUser.content.find((p) => p.type === "text") as any;
          if (firstText) {
            if (!firstText.text.startsWith("[conversation summary]")) {
              firstText.text = prefix + firstText.text;
            }
          } else {
            firstUser.content.unshift({ type: "text", text: `[conversation summary]\n${this.#memo.text}` });
          }
        }
      }
    }
    return msgs;
  }

  #assemblePreP4(): { lastGood: ModelMessage[]; working: JournalEntry[] } {
    if (this.#journal.length === 0) return { lastGood: [], working: [] };

    let working = cloneJournal(this.#journal);

    // ------------------------------------------------------------
    // P1: Observation freshness
    // ------------------------------------------------------------
    if (this.#cfg.passes.p1) {
      try {
        let snapshotCount = 0;
        let queryCount = 0;

        for (let i = working.length - 1; i >= 0; i--) {
          const entry = working[i];
          if (entry.msg.role === "tool" && Array.isArray(entry.msg.content)) {
            for (let j = entry.msg.content.length - 1; j >= 0; j--) {
              const part = entry.msg.content[j];
              if (part.type === "tool-result") {
                if (part.toolName === "snapshot_page") {
                  snapshotCount++;
                  if (snapshotCount > this.#cfg.kObsWindow) {
                    const origVal = getOutputText(part.output);
                    const genMatch = origVal.match(/generation:\s*(\d+)/i);
                    const g = genMatch ? genMatch[1] : (entry.meta.generation !== undefined ? String(entry.meta.generation) : "unknown");
                    const tombstone = `[superseded snapshot — generation ${g}, ${origVal.length} chars omitted. Take a new snapshot if needed.]`;
                    part.output = { type: "text", value: tombstone };
                  }
                } else if (part.toolName === "query_state") {
                  queryCount++;
                  if (queryCount > this.#cfg.kObsWindow) {
                    let path = "unknown path";
                    let totalMatches = "unknown";

                    const callEntry = working.find((e) =>
                      e.msg.role === "assistant" &&
                      Array.isArray(e.msg.content) &&
                      e.msg.content.some((p) => p.type === "tool-call" && p.toolCallId === part.toolCallId)
                    );
                    if (callEntry && Array.isArray(callEntry.msg.content)) {
                      const callPart = callEntry.msg.content.find(
                        (p) => p.type === "tool-call" && p.toolCallId === part.toolCallId
                      ) as any;
                      if (callPart && callPart.input && typeof callPart.input === "object" && "path" in callPart.input) {
                        path = String(callPart.input.path);
                      }
                    }

                    const origVal = getOutputText(part.output);
                    let parsed: any;
                    try {
                      parsed = JSON.parse(origVal);
                    } catch (e) {
                      if (part.output && typeof part.output === "object") {
                        parsed = part.output;
                        if ("value" in parsed) parsed = parsed.value;
                      }
                    }
                    if (parsed && typeof parsed === "object" && "total_matches" in parsed) {
                      totalMatches = String(parsed.total_matches);
                    }

                    const tombstone = `[superseded query result — ${path}, ${totalMatches} matches omitted. Re-run query_state if needed.]`;
                    part.output = { type: "text", value: tombstone };
                  }
                }
              }
            }
            entry.meta.chars = JSON.stringify(entry.msg).length;
          }
        }

        const candidate = this.#convertToMessages(working);
        this.validateWorkingContext(candidate);
      } catch (e) {
        // Fallback
        working = cloneJournal(this.#journal);
      }
    }

    // ------------------------------------------------------------
    // P2: UI-block trimming
    // ------------------------------------------------------------
    if (this.#cfg.passes.p2) {
      try {
        let latestAssistantIndex = -1;
        for (let i = working.length - 1; i >= 0; i--) {
          if (working[i].msg.role === "assistant") {
            latestAssistantIndex = i;
            break;
          }
        }

        for (let i = 0; i < working.length; i++) {
          if (i === latestAssistantIndex) continue;
          const entry = working[i];
          if (entry.msg.role === "assistant") {
            if (typeof entry.msg.content === "string") {
              entry.msg.content = trimUiBlocksText(entry.msg.content);
            } else if (Array.isArray(entry.msg.content)) {
              for (const part of entry.msg.content) {
                if (part.type === "text") {
                  part.text = trimUiBlocksText(part.text);
                }
              }
            }
            entry.meta.chars = JSON.stringify(entry.msg).length;
          }
        }

        const candidate = this.#convertToMessages(working);
        this.validateWorkingContext(candidate);
      } catch (e) {
        // Fallback
      }
    }

    // ------------------------------------------------------------
    // P3: Turn folding
    // ------------------------------------------------------------
    if (this.#cfg.passes.p3) {
      try {
        const turnIds: string[] = [];
        for (const entry of working) {
          if (!turnIds.includes(entry.meta.turnId)) {
            turnIds.push(entry.meta.turnId);
          }
        }

        const activeTurnId = this.#currentTurnId;
        const verbatimWindow = turnIds.slice(-this.#cfg.kTurnsVerbatim);

        const foldedWorking: JournalEntry[] = [];

        for (const turnId of turnIds) {
          const turnEntries = working.filter((e) => e.meta.turnId === turnId);
          const isCompleted = this.#completedTurns.has(turnId);
          const shouldFold = isCompleted && turnId !== activeTurnId && !verbatimWindow.includes(turnId);

          if (shouldFold) {
            const userEntries = turnEntries.filter((e) => e.msg.role === "user");
            const finalAssistantMsg = [...turnEntries].reverse().find((e) => e.msg.role === "assistant");

            const audits = this.#turnAudits.get(turnId) || [];
            const formattedActions = audits.map(formatAuditEntry);
            
            foldedWorking.push(...userEntries);

            if (formattedActions.length > 0) {
              const syntheticLine = `[agent actions this turn: ${compressActions(formattedActions)}]`;
              if (finalAssistantMsg) {
                const finalMsgCopy = {
                  role: "assistant",
                  content: "",
                  ...(finalAssistantMsg.msg.providerOptions ? { providerOptions: { ...finalAssistantMsg.msg.providerOptions } } : {}),
                } as ModelMessage;

                const originalProse = typeof finalAssistantMsg.msg.content === "string"
                  ? finalAssistantMsg.msg.content
                  : Array.isArray(finalAssistantMsg.msg.content)
                    ? finalAssistantMsg.msg.content.map((p: any) => p.type === "text" ? p.text : "").join("\n")
                    : "";

                finalMsgCopy.content = originalProse 
                  ? `${syntheticLine}\n\n${originalProse}` 
                  : syntheticLine;

                foldedWorking.push({
                  msg: finalMsgCopy,
                  meta: {
                    ...finalAssistantMsg.meta,
                    kinds: ["assistant_prose"],
                    chars: JSON.stringify(finalMsgCopy).length,
                  },
                });
              } else {
                const syntheticMsg: ModelMessage = {
                  role: "assistant",
                  content: syntheticLine,
                };
                foldedWorking.push({
                  msg: syntheticMsg,
                  meta: {
                    turnId,
                    stepNo: 0,
                    kinds: ["assistant_prose"],
                    chars: JSON.stringify(syntheticMsg).length,
                    createdAt: Date.now(),
                  },
                });
              }
            } else if (finalAssistantMsg) {
              foldedWorking.push(finalAssistantMsg);
            }
          } else {
            foldedWorking.push(...turnEntries);
          }
        }

        working = foldedWorking;
        const candidate = this.#convertToMessages(working);
        this.validateWorkingContext(candidate);
      } catch (e) {
        // Fallback
      }
    }

    return {
      lastGood: this.#convertToMessages(working),
      working
    };
  }

  compose(opts?: { stepNumber?: number }): ModelMessage[] {
    this.#needsCompaction = false;
    if (this.#journal.length === 0) return [];

    let { lastGood, working } = this.#assemblePreP4();

    // ------------------------------------------------------------
    // P4: Budget enforcement
    // ------------------------------------------------------------
    if (this.#cfg.passes.p4) {
      try {
        let currentTokens = this.#getCurrentTokenCount(lastGood);
        if (currentTokens > this.#softThreshold) {
          this.#needsCompaction = true;
        }

        if (currentTokens > this.#hardThreshold) {
          const turnIds: string[] = [];
          for (const entry of working) {
            if (!turnIds.includes(entry.meta.turnId)) {
              turnIds.push(entry.meta.turnId);
            }
          }

          const activeTurnId = this.#currentTurnId;
          const verbatimWindow = turnIds.slice(-this.#cfg.kTurnsVerbatim);

          let evictedCount = 0;
          let tempWorking = [...working];
          let compacted = false;

          for (const turnId of turnIds) {
            const isCompleted = this.#completedTurns.has(turnId);
            const isFolded = isCompleted && turnId !== activeTurnId && !verbatimWindow.includes(turnId);

            if (isFolded) {
              tempWorking = tempWorking.filter((e) => e.meta.turnId !== turnId);
              evictedCount++;

              // To test budget, build message array and prepend stub
              const candidateMsgs = tempWorking.map((e) => ({
                role: e.msg.role,
                content: Array.isArray(e.msg.content)
                  ? e.msg.content.map((p) => ({ ...p }))
                  : e.msg.content,
                ...(e.msg.providerOptions ? { providerOptions: { ...e.msg.providerOptions } } : {}),
              } as ModelMessage));

              if (candidateMsgs.length > 0) {
                const firstUser = candidateMsgs.find((m) => m.role === "user");
                if (firstUser) {
                  const stubText = this.#memo 
                    ? "[earlier conversation compacted: see summary above]" 
                    : `[${evictedCount} earlier turns omitted]`;
                  const prefix = stubText + "\n\n";
                  if (typeof firstUser.content === "string") {
                    firstUser.content = prefix + firstUser.content;
                  } else if (Array.isArray(firstUser.content)) {
                    const firstText = firstUser.content.find((p) => p.type === "text") as any;
                    if (firstText) {
                      firstText.text = prefix + firstText.text;
                    } else {
                      firstUser.content.unshift({ type: "text", text: stubText });
                    }
                  }
                }
              }

              const checkTokens = this.estimateTokens(candidateMsgs);
              if (checkTokens <= this.#hardThreshold) {
                working = tempWorking;
                (working as any).evictedCount = evictedCount;
                compacted = true;
                break;
              }
            }
          }

          if (compacted) {
            this.#lastKnownInputTokens = null;
            this.#lastKnownJournalLength = 0;
          }

          const candidate = this.#convertToMessages(working);
          this.validateWorkingContext(candidate);
          lastGood = candidate;
          currentTokens = this.estimateTokens(lastGood);
        }

        // Panic budget: tombstone all observations except latest snapshot
        if (currentTokens > this.#panicThreshold) {
          this.#lastKnownInputTokens = null;
          this.#lastKnownJournalLength = 0;
          let snapshotCount = 0;
          for (let i = working.length - 1; i >= 0; i--) {
            const entry = working[i];
            if (entry.msg.role === "tool" && Array.isArray(entry.msg.content)) {
              for (let j = entry.msg.content.length - 1; j >= 0; j--) {
                const part = entry.msg.content[j];
                if (part.type === "tool-result") {
                  if (part.toolName === "snapshot_page") {
                    snapshotCount++;
                    if (snapshotCount > 1) {
                      const origVal = getOutputText(part.output);
                      const genMatch = origVal.match(/generation:\s*(\d+)/i);
                      const g = genMatch ? genMatch[1] : (entry.meta.generation !== undefined ? String(entry.meta.generation) : "unknown");
                      const tombstone = `[superseded snapshot — generation ${g}, ${origVal.length} chars omitted. Take a new snapshot if needed.]`;
                      part.output = { type: "text", value: tombstone };
                    }
                  } else if (part.toolName === "query_state") {
                    let path = "unknown path";
                    let totalMatches = "unknown";

                    const callEntry = working.find((e) =>
                      e.msg.role === "assistant" &&
                      Array.isArray(e.msg.content) &&
                      e.msg.content.some((p) => p.type === "tool-call" && p.toolCallId === part.toolCallId)
                    );
                    if (callEntry && Array.isArray(callEntry.msg.content)) {
                      const callPart = callEntry.msg.content.find(
                        (p) => p.type === "tool-call" && p.toolCallId === part.toolCallId
                      ) as any;
                      if (callPart && callPart.input && typeof callPart.input === "object" && "path" in callPart.input) {
                        path = String(callPart.input.path);
                      }
                    }

                    const origVal = getOutputText(part.output);
                    let parsed: any;
                    try {
                      parsed = JSON.parse(origVal);
                    } catch (e) {
                      if (part.output && typeof part.output === "object") {
                        parsed = part.output;
                        if ("value" in parsed) parsed = parsed.value;
                      }
                    }
                    if (parsed && typeof parsed === "object" && "total_matches" in parsed) {
                      totalMatches = String(parsed.total_matches);
                    }

                    const tombstone = `[superseded query result — ${path}, ${totalMatches} matches omitted. Re-run query_state if needed.]`;
                    part.output = { type: "text", value: tombstone };
                  }
                }
              }
              entry.meta.chars = JSON.stringify(entry.msg).length;
            }
          }

          const candidate = this.#convertToMessages(working);
          this.validateWorkingContext(candidate);
          lastGood = candidate;
        }
      } catch (e) {
        // Fallback
      }
    }

    return lastGood;
  }

  validateWorkingContext(msgs: ModelMessage[]): void {
    if (msgs.length === 0) return;

    const raise = (errStr: string) => {
      if (this.#mode === "assert") {
        throw new Error(errStr);
      } else {
        console.warn(errStr);
      }
    };

    // I2: First message role is user or system
    const firstRole = msgs[0].role;
    if (firstRole !== "user" && firstRole !== "system") {
      raise("I2 violation: First message must be user or system.");
      return;
    }

    // Alternating roles
    let prevRole: string | null = null;
    for (const msg of msgs) {
      const role = msg.role;
      if (prevRole !== null) {
        if (prevRole === "user" && role !== "assistant") {
          raise("I2 violation: User message must be followed by assistant.");
          return;
        }
        if (prevRole === "assistant" && role !== "user" && role !== "tool") {
          raise("I2 violation: Assistant message must be followed by user or tool.");
          return;
        }
        if (prevRole === "tool" && role !== "assistant") {
          raise("I2 violation: Tool message must be followed by assistant.");
          return;
        }
        if (prevRole === "system" && role !== "user") {
          raise("I2 violation: System message must be followed by user.");
          return;
        }
      }
      prevRole = role;
    }

    // I1: Every tool-call part has a matching tool-result part by toolCallId
    const calls = new Set<string>();
    const results = new Set<string>();

    for (const msg of msgs) {
      if (Array.isArray(msg.content)) {
        for (const part of msg.content) {
          if (part.type === "tool-call") {
            calls.add(part.toolCallId);
          } else if (part.type === "tool-result") {
            results.add(part.toolCallId);
          }
        }
      }
    }

    for (const id of calls) {
      if (!results.has(id)) {
        raise(`I1 violation: Tool call with ID "${id}" has no matching tool result.`);
        return;
      }
    }
    for (const id of results) {
      if (!calls.has(id)) {
        raise(`I1 violation: Tool result with ID "${id}" has no matching tool call.`);
        return;
      }
    }

    // I4: Latest snapshot result is verbatim
    let latestSnapshotOutput: any = null;
    for (let i = msgs.length - 1; i >= 0; i--) {
      const msg = msgs[i];
      if (msg.role === "tool" && Array.isArray(msg.content)) {
        const found = [...msg.content].reverse().find((p) => p.type === "tool-result" && p.toolName === "snapshot_page");
        if (found) {
          latestSnapshotOutput = getOutputText((found as any).output);
          break;
        }
      }
    }
    if (latestSnapshotOutput !== null && latestSnapshotOutput.includes("[superseded snapshot")) {
      raise("I4 violation: The latest snapshot page tool result was tombstoned.");
      return;
    }

    // I5: Memo placement
    if (this.#memo) {
      const firstUser = msgs.find((m) => m.role === "user");
      if (firstUser) {
        const text = typeof firstUser.content === "string"
          ? firstUser.content
          : Array.isArray(firstUser.content)
            ? (firstUser.content.find((p) => p.type === "text") as any)?.text || ""
            : "";
        if (!text.startsWith("[conversation summary]")) {
          raise("I5 violation: Memo is not at the start of the first user message.");
          return;
        }
      }
    }
  }
}
