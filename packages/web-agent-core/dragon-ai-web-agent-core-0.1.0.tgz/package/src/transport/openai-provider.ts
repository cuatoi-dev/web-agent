import OpenAI from "openai";
import type { AgentConfig } from "../config.js";
import { createOpenAIClient } from "./provider.js";
import type {
  LanguageModel, ProviderCallOptions, ProviderResult,
  FinishReason, NormalizedUsage, ToolChoice, ProviderWarning,
} from "./provider-types.js";
import { reassembleStream, StreamingToolCallTracker } from "./stream-parts.js";
import type { StreamPart } from "./stream-parts.js";
import type { ResponseBlock, TextPart, ToolCallPart } from "../types.js";

// Type aliases for OpenAI SDK v6 types
type ChatCompletionCreateParamsNonStreaming = OpenAI.Chat.ChatCompletionCreateParamsNonStreaming;
type ChatCompletionMessageParam = OpenAI.Chat.ChatCompletionMessageParam;
type ChatCompletionContentPart = OpenAI.Chat.ChatCompletionContentPart;
type ChatCompletionToolChoiceOption = OpenAI.Chat.ChatCompletionToolChoiceOption;
type ChatCompletionMessageToolCall = OpenAI.Chat.ChatCompletionMessageToolCall;
type ChatCompletionChoice = OpenAI.Chat.Completions.ChatCompletion.Choice;
type ChatCompletionReasoningEffort = OpenAI.Chat.ChatCompletionReasoningEffort;
type CompletionUsage = OpenAI.Completions.CompletionUsage;
type ChatCompletionChunk = OpenAI.Chat.Completions.ChatCompletionChunk;

export class OpenAILanguageModel implements LanguageModel {
  readonly provider = "openai";
  readonly supportedUrls = {
    'image/*': [/^https?:\/\/.*$/]
  };
  get modelId() { return this._cfg.model; }

  public _client: OpenAI;
  private _cfg: AgentConfig;

  constructor(cfg: AgentConfig, opts?: { fetch?: typeof fetch }) {
    this._cfg = cfg;
    this._client = createOpenAIClient(cfg, opts);
  }

  // ---------------------------------------------------------------------------
  // buildBaseParams — shared param builder for both generate() and doStream()
  // ---------------------------------------------------------------------------
  private buildBaseParams(
    opts: ProviderCallOptions,
    warnings: ProviderWarning[],
  ): ChatCompletionCreateParamsNonStreaming {
    if (opts.topK !== undefined) {
      warnings.push({ type: "unsupported", feature: "topK", details: "OpenAI models do not support topK" });
    }

    const openaiMsgs = toOpenAIMessages(opts.messages, warnings, {
      modelId: opts.model,
      imageInputEnabled: this._cfg.imageInput,
      modelSupportsVision: openaiSupportsVision(opts.model),
    });

    const systemPrompt = opts.systemPrompt || "";
    if (systemPrompt) {
      const isReasoning = opts.model.startsWith("o1") || opts.model.startsWith("o3");
      openaiMsgs.unshift({
        role: isReasoning ? "developer" : "system" as const,
        content: systemPrompt,
      });
    }

    const isReasoningModel = opts.model.startsWith("o1") || opts.model.startsWith("o3");
    const resolvedReasoningEffort = opts.providerOptions?.["openai"]?.["reasoning_effort"] as ChatCompletionReasoningEffort | undefined;

    return {
      model: opts.model,
      messages: openaiMsgs,
      ...(opts.tools?.length ? {
        tools: opts.tools.map(t => ({
          type: "function" as const,
          function: {
            name: t.name,
            description: t.description,
            parameters: t.input_schema,
          }
        }))
      } : {}),
      ...(opts.toolChoice ? { tool_choice: mapToolChoice(opts.toolChoice) } : {}),
      ...(isReasoningModel
        ? {
            max_completion_tokens: opts.maxOutputTokens,
            ...(resolvedReasoningEffort ? { reasoning_effort: resolvedReasoningEffort } : {}),
          }
        : {
            max_tokens: opts.maxOutputTokens,
            ...(opts.temperature !== undefined ? { temperature: opts.temperature } : {}),
            ...(opts.topP !== undefined ? { top_p: opts.topP } : {}),
          }),
      ...(opts.stopSequences ? { stop: opts.stopSequences } : {}),
      ...(opts.seed !== undefined ? { seed: opts.seed } : {}),
    };
  }

  // ---------------------------------------------------------------------------
  // generate — non-streaming path unchanged; streaming delegates to doStream()
  // ---------------------------------------------------------------------------
  async generate(opts: ProviderCallOptions): Promise<ProviderResult> {
    if (opts.streaming) {
      const { stream } = await this.doStream(opts);
      return reassembleStream(stream);
    }

    const warnings: ProviderWarning[] = [];
    const params = this.buildBaseParams(opts, warnings);

    const response = await this._client.chat.completions.create(params, {
      signal: opts.abortSignal,
    });

    const choice = response.choices[0];
    const result = fromOpenAIChoice(choice, response.usage);
    if (warnings.length > 0) {
      result.warnings = [...(result.warnings || []), ...warnings];
    }
    return result;
  }

  // ---------------------------------------------------------------------------
  // doStream — streaming via chat.completions.create({stream:true, include_usage})
  // ---------------------------------------------------------------------------
  async doStream(opts: ProviderCallOptions): Promise<{ stream: AsyncIterable<StreamPart> }> {
    const warnings: ProviderWarning[] = [];
    const baseParams = this.buildBaseParams(opts, warnings);

    const streamParams = {
      ...baseParams,
      stream: true as const,
      stream_options: { include_usage: true },
    };

    const chunks = (await (this._client.chat.completions.create as any)(
      streamParams,
      { signal: opts.abortSignal },
    )) as AsyncIterable<ChatCompletionChunk>;

    return { stream: this.streamToParts(chunks, warnings) };
  }

  // ---------------------------------------------------------------------------
  // streamToParts — async generator mapping OpenAI chunks → StreamPart sequence
  // ---------------------------------------------------------------------------
  private async *streamToParts(
    chunks: AsyncIterable<ChatCompletionChunk>,
    warnings: ProviderWarning[],
  ): AsyncGenerator<StreamPart> {
    yield { type: "stream-start", warnings };

    let textStarted = false;
    let reasoningStarted = false;
    let finishReason: string | null = null;
    let usage: CompletionUsage | undefined;
    const TEXT_ID = "text_0";
    const REASON_ID = "reasoning_0";

    const pending: StreamPart[] = [];
    const tracker = new StreamingToolCallTracker((part: StreamPart) => pending.push(part));

    for await (const chunk of chunks) {
      // Usage arrives in the final chunk (choices=[]) when include_usage is set
      if (chunk.usage) usage = chunk.usage;

      const choice = (chunk.choices as any[])?.[0];
      if (!choice) continue;

      if (choice.finish_reason != null) finishReason = choice.finish_reason;

      const delta = choice.delta;
      if (!delta) continue;

      if (delta.content) {
        if (!textStarted) {
          yield { type: "text-start", id: TEXT_ID };
          textStarted = true;
        }
        yield { type: "text-delta", id: TEXT_ID, delta: delta.content };
      }

      const reasoningContent = (delta as any).reasoning ?? (delta as any).reasoning_content;
      if (reasoningContent) {
        if (!reasoningStarted) {
          yield { type: "reasoning-start", id: REASON_ID };
          reasoningStarted = true;
        }
        yield { type: "reasoning-delta", id: REASON_ID, delta: reasoningContent };
      }

      if (delta.tool_calls) {
        for (const tc of delta.tool_calls) {
          tracker.processDelta(tc);
          while (pending.length > 0) yield pending.shift()!;
        }
      }
    }

    if (textStarted) yield { type: "text-end", id: TEXT_ID };
    if (reasoningStarted) yield { type: "reasoning-end", id: REASON_ID };

    tracker.flush();
    while (pending.length > 0) yield pending.shift()!;

    yield {
      type: "finish",
      finishReason: mapFinishReason(finishReason),
      usage: {
        inputTokens: usage?.prompt_tokens ?? 0,
        outputTokens: usage?.completion_tokens ?? 0,
        cachedInputTokens: usage?.prompt_tokens_details?.cached_tokens ?? undefined,
        reasoningTokens: usage?.completion_tokens_details?.reasoning_tokens ?? undefined,
      },
    };
  }
}

export function createOpenAILanguageModel(
  cfg: AgentConfig,
  opts?: { fetch?: typeof fetch },
): OpenAILanguageModel {
  return new OpenAILanguageModel(cfg, opts);
}

// ---------------------------------------------------------------------------
// mapToolChoice: our ToolChoice → OpenAI tool_choice param
// ---------------------------------------------------------------------------
function mapToolChoice(tc: ToolChoice): ChatCompletionToolChoiceOption {
  switch (tc.type) {
    case "auto":     return "auto";
    case "required": return "required";
    case "none":     return "none";
    case "tool":     return { type: "function", function: { name: tc.toolName } };
  }
}

// ---------------------------------------------------------------------------
// toOpenAIMessages: internal ModelMessage[] → OpenAI chat completion params
// ---------------------------------------------------------------------------
export function toOpenAIMessages(
  messages: any[],
  warnings: ProviderWarning[],
  options?: {
    modelId?: string;
    imageInputEnabled?: boolean;
    modelSupportsVision?: boolean;
  }
): ChatCompletionMessageParam[] {
  const result: ChatCompletionMessageParam[] = [];
  const isLegacy = options === undefined;
  const { imageInputEnabled, modelSupportsVision } = options || {};

  for (const msg of messages) {
    if (msg.role === "system") {
      // Handled separately as prepended prompt
      continue;
    }

    if (msg.role === "user") {
      if (typeof msg.content === "string") {
        result.push({ role: "user", content: msg.content });
      } else {
        const contentParts: ChatCompletionContentPart[] = [];
        for (const part of msg.content) {
          if (part.type === "text") {
            contentParts.push({ type: "text", text: part.text });
          } else if (part.type === "image" || part.type === "file") {
            if (isLegacy) {
              warnings.push({ type: "unsupported", feature: "image-input", details: "Images are not supported on this path" });
              contentParts.push({ type: "image_url", image_url: { url: part.type === "image" ? part.image : part.data } });
              continue;
            }

            const isImageDisabledOrUnsupported =
              imageInputEnabled === false ||
              (imageInputEnabled === undefined && modelSupportsVision === false);

            if (isImageDisabledOrUnsupported) {
              warnings.push({
                type: "unsupported",
                feature: "image-input",
                details: "Images are not supported by the model or are disabled by config.",
              });
              continue;
            }

            const mediaType = part.mediaType;
            const imageData = part.type === "image" ? part.image : part.data;

            let url = imageData;
            if (
              !imageData.startsWith("http://") &&
              !imageData.startsWith("https://") &&
              !imageData.startsWith("data:")
            ) {
              url = `data:${mediaType};base64,${imageData}`;
            }

            contentParts.push({ type: "image_url", image_url: { url } });
          }
        }
        result.push({ role: "user", content: contentParts });
      }
    } else if (msg.role === "assistant") {
      if (typeof msg.content === "string") {
        result.push({ role: "assistant", content: msg.content });
      } else {
        const textParts = msg.content.filter((p: any) => p.type === "text") as TextPart[];
        const textContent = textParts.map(p => p.text).join("\n") || null;
        const toolCallParts = msg.content.filter((p: any) => p.type === "tool-call") as ToolCallPart[];

        const toolCalls: ChatCompletionMessageToolCall[] | undefined = toolCallParts.length > 0
          ? toolCallParts.map(p => ({
              id: p.toolCallId,
              type: "function" as const,
              function: {
                name: p.toolName,
                arguments: JSON.stringify(p.input ?? {}),
              }
            }))
          : undefined;

        result.push({
          role: "assistant",
          content: textContent,
          tool_calls: toolCalls,
        });
      }
    } else if (msg.role === "tool") {
      for (const part of msg.content) {
        if (part.type === "tool-result") {
          result.push({
            role: "tool",
            tool_call_id: part.toolCallId,
            content: typeof part.output === "string" ? part.output : JSON.stringify(part.output ?? ""),
          });
        }
      }
    }
  }

  return result;
}

// ---------------------------------------------------------------------------
// fromOpenAIChoice: maps OpenAI ChatCompletionChoice → ProviderResult
// ---------------------------------------------------------------------------
export function fromOpenAIChoice(
  choice: ChatCompletionChoice,
  usage?: CompletionUsage,
): ProviderResult {
  const content: ResponseBlock[] = [];

  if (choice.message.content) {
    content.push({ type: "text", text: choice.message.content });
  }

  if (choice.message.tool_calls) {
    for (const tc of choice.message.tool_calls) {
      if (tc.type !== "function") continue;
      let input: Record<string, unknown> = {};
      try {
        input = JSON.parse(tc.function.arguments || "{}");
      } catch {
        input = {};
      }
      content.push({
        type: "tool_use",
        id: tc.id,
        name: tc.function.name,
        input,
      });
    }
  }

  return {
    content,
    finishReason: mapFinishReason(choice.finish_reason),
    usage: {
      inputTokens: usage?.prompt_tokens ?? 0,
      outputTokens: usage?.completion_tokens ?? 0,
      cachedInputTokens: usage?.prompt_tokens_details?.cached_tokens ?? undefined,
      reasoningTokens: usage?.completion_tokens_details?.reasoning_tokens ?? undefined,
    },
    warnings: [],
  };
}

// ---------------------------------------------------------------------------
// mapFinishReason: OpenAI finish_reason → normalized FinishReason
// ---------------------------------------------------------------------------
function mapFinishReason(raw: string | null | undefined): FinishReason {
  switch (raw) {
    case "stop":           return "stop";
    case "length":         return "length";
    case "tool_calls":     return "tool-calls";
    case "content_filter": return "content-filter";
    case "error":          return "error";
    default:               return raw ? "other" : "unknown";
  }
}

function openaiSupportsVision(model: string): boolean {
  const lower = model.toLowerCase();
  return (
    lower.includes("gpt-4o") ||
    lower.includes("gpt-4-turbo") ||
    lower.includes("vision") ||
    lower.includes("gemma-4") ||
    lower.includes("gemma4") ||
    lower.includes("claude-3")
  );
}
