import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";
import type { AgentConfig } from "../config.js";

export function getAbsoluteBaseURL(baseURL: string): string {
  if (baseURL.startsWith("/")) {
    if (typeof window !== "undefined") {
      return `${window.location.origin}${baseURL}`;
    }
    return `http://localhost:8080${baseURL}`;
  }
  return baseURL;
}

export function parseAnthropicSSE(text: string): any {
  const lines = text.split("\n");
  let message: any = null;
  const contentBlocks: any[] = [];

  for (const line of lines) {
    let dataStr = "";
    if (line.startsWith("data: ")) {
      dataStr = line.slice(6).trim();
    } else if (line.startsWith("data:")) {
      dataStr = line.slice(5).trim();
    } else {
      continue;
    }

    if (!dataStr || dataStr === "[DONE]") continue;
    try {
      const data = JSON.parse(dataStr);
      if (data.type === "message_start") {
        message = data.message;
      } else if (data.type === "content_block_start") {
        contentBlocks[data.index] = data.content_block;
      } else if (data.type === "content_block_delta") {
        const block = contentBlocks[data.index];
        if (block) {
          if (block.type === "text" && data.delta && data.delta.type === "text_delta") {
            block.text = (block.text || "") + (data.delta.text || "");
          } else if (block.type === "thinking" && data.delta && data.delta.type === "thinking_delta") {
            block.thinking = (block.thinking || "") + (data.delta.thinking || "");
          } else if (block.type === "tool_use" && data.delta && data.delta.type === "input_json_delta") {
            block.partial_json = (block.partial_json || "") + (data.delta.partial_json || "");
          }
        }
      } else if (data.type === "message_delta") {
        if (message) {
          if (data.delta) {
            if (data.delta.stop_reason) message.stop_reason = data.delta.stop_reason;
            if (data.delta.stop_sequence) message.stop_sequence = data.delta.stop_sequence;
          }
          if (data.usage) {
            message.usage.output_tokens = data.usage.output_tokens;
          }
        }
      }
    } catch (e) {
      // quiet fail
    }
  }

  if (message) {
    for (const block of contentBlocks) {
      if (block && block.type === "tool_use") {
        if (block.partial_json) {
          try {
            block.input = JSON.parse(block.partial_json);
          } catch {
            block.input = {};
          }
          delete block.partial_json;
        } else if (!block.input) {
          block.input = {};
        }
      }
    }
    message.content = contentBlocks.filter(Boolean);
  }

  return message;
}

export function createAnthropicClient(
  cfg: AgentConfig,
  opts?: { fetch?: typeof fetch },
): Anthropic {
  const originalFetch = opts?.fetch || (typeof window !== "undefined" ? window.fetch : undefined) || (globalThis as any).fetch;

  const customFetch = async (url: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    if (!originalFetch) {
      throw new Error("No fetch implementation available.");
    }

    // When the SDK calls messages.stream() it sets stream:true in the request body.
    // In that case we must NOT intercept the SSE response — pass it through so the
    // SDK's native stream reader can process the events via finalMessage().
    let isStreamingRequest = false;
    if (init?.body && typeof init.body === "string") {
      try {
        isStreamingRequest = JSON.parse(init.body).stream === true;
      } catch {
        // ignore malformed bodies
      }
    }

    const res = await originalFetch(url, init);
    if (!res.ok) return res;

    const contentType = res.headers.get("content-type") || "";
    if (contentType.includes("text/event-stream")) {
      if (isStreamingRequest) {
        // Streaming was explicitly requested; let the SDK's reader handle SSE.
        return res;
      }
      try {
        const text = await res.text();
        const message = parseAnthropicSSE(text);
        if (message) {
          return new Response(JSON.stringify(message), {
            status: 200,
            statusText: "OK",
            headers: new Headers({
              "Content-Type": "application/json",
            }),
          });
        }
      } catch (e) {
        // quiet fail
      }
    }
    return res;
  };


  return new Anthropic({
    baseURL: getAbsoluteBaseURL(cfg.baseURL),
    apiKey: "proxy",
    fetch: customFetch,
    dangerouslyAllowBrowser: true,
    maxRetries: 0,
  });
}

export function createOpenAIClient(
  cfg: AgentConfig,
  opts?: { fetch?: typeof fetch },
): OpenAI {
  const originalFetch = opts?.fetch || (typeof window !== "undefined" ? window.fetch : undefined) || (globalThis as any).fetch;
  return new OpenAI({
    baseURL: getAbsoluteBaseURL(cfg.baseURL),
    apiKey: "proxy",
    fetch: originalFetch,
    dangerouslyAllowBrowser: true,
    maxRetries: 0,
  });
}

