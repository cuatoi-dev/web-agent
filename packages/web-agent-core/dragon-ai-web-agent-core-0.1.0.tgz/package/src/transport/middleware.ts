import type { LanguageModel, ProviderCallOptions, ProviderResult } from "./provider-types.js";
import type { StreamPart } from "./stream-parts.js";
import type { AgentConfig } from "../config.js";
import type { ResponseBlock } from "../types.js";
import { AgentError, mapToAgentError } from "../loop/errors.js";

// ---------------------------------------------------------------------------
// LanguageModelMiddleware — minimal mirror of AI SDK LanguageModelV2Middleware
//
// wrapGenerate/wrapStream receive a `doGenerate`/`doStream` that accepts an
// optional override `params`. Middleware that needs to mutate call options
// (e.g. swap the abortSignal for a timed-out one — see withRetry) passes new
// params; middleware that doesn't simply calls it with no argument and the
// closure's captured params are used.
// ---------------------------------------------------------------------------

export interface LanguageModelMiddleware {
  transformParams?: (
    a: { type: "generate" | "stream"; params: ProviderCallOptions },
  ) => ProviderCallOptions | Promise<ProviderCallOptions>;

  wrapGenerate?: (a: {
    doGenerate: (params?: ProviderCallOptions) => Promise<ProviderResult>;
    params: ProviderCallOptions;
    model: LanguageModel;
  }) => Promise<ProviderResult>;

  wrapStream?: (a: {
    doStream: (params?: ProviderCallOptions) => Promise<{ stream: AsyncIterable<StreamPart> }>;
    params: ProviderCallOptions;
    model: LanguageModel;
  }) => Promise<{ stream: AsyncIterable<StreamPart> }>;

  overrideProvider?: (a: { model: LanguageModel }) => string;
  overrideModelId?: (a: { model: LanguageModel }) => string;
}

// ---------------------------------------------------------------------------
// wrapProvider — compose one or more middleware layers around a LanguageModel
// First middleware in the array is the outermost wrapper (AI SDK semantics).
// ---------------------------------------------------------------------------

export function wrapProvider(
  model: LanguageModel,
  middleware: LanguageModelMiddleware | LanguageModelMiddleware[],
): LanguageModel {
  const mws: LanguageModelMiddleware[] = Array.isArray(middleware) ? middleware : [middleware];

  // Compute provider/modelId overrides (last override wins per layer, applied outside-in)
  const resolvedProvider = mws.reduce<string>(
    (p, mw) => (mw.overrideProvider ? mw.overrideProvider({ model }) : p),
    model.provider,
  );
  const resolvedModelId = mws.reduce<string>(
    (id, mw) => (mw.overrideModelId ? mw.overrideModelId({ model }) : id),
    model.modelId,
  );

  async function applyTransformParams(
    type: "generate" | "stream",
    params: ProviderCallOptions,
  ): Promise<ProviderCallOptions> {
    let p = params;
    for (const mw of mws) {
      if (mw.transformParams) p = await mw.transformParams({ type, params: p });
    }
    return p;
  }

  const wrapped: LanguageModel = {
    provider: resolvedProvider,
    modelId: resolvedModelId,
    supportedUrls: model.supportedUrls,

    async generate(opts: ProviderCallOptions): Promise<ProviderResult> {
      const params = await applyTransformParams("generate", opts);

      // Build the innermost doGenerate; accepts an optional params override so
      // middleware can re-issue the call with mutated options (e.g. new signal).
      let doGenerate = (p: ProviderCallOptions = params) => model.generate(p);

      // Wrap from innermost out: apply mws in reverse so mws[0] is outermost
      for (let i = mws.length - 1; i >= 0; i--) {
        const mw = mws[i];
        if (mw.wrapGenerate) {
          const prev = doGenerate;
          const capture = mw.wrapGenerate;
          doGenerate = (p: ProviderCallOptions = params) =>
            capture({ doGenerate: prev, params: p, model });
        }
      }

      return doGenerate(params);
    },
  };

  if (model.doStream) {
    wrapped.doStream = async function (opts: ProviderCallOptions) {
      const params = await applyTransformParams("stream", opts);

      let doStream = (p: ProviderCallOptions = params) => model.doStream!(p);

      for (let i = mws.length - 1; i >= 0; i--) {
        const mw = mws[i];
        if (mw.wrapStream) {
          const prev = doStream;
          const capture = mw.wrapStream;
          doStream = (p: ProviderCallOptions = params) =>
            capture({ doStream: prev, params: p, model });
        }
      }

      return doStream(params);
    };
  }

  // Transparent seam: forward the `_client` property to the inner provider so
  // existing test/debug seams (e.g. `agent._client = mock`) keep working through
  // the wrapper instead of silently writing to a dead property.
  const inner = model as any;
  if (inner && "_client" in inner) {
    Object.defineProperty(wrapped, "_client", {
      configurable: true,
      enumerable: false,
      get() { return inner._client; },
      set(v) { inner._client = v; },
    });
  }

  return wrapped;
}

// ---------------------------------------------------------------------------
// withRetry — transport resilience middleware.
//
// Retries empty/dead streams (SSE returning only `[DONE]` or closing without
// any content) and transient network/parse failures up to `cfg.maxRetries`
// times with backoff delays from BACKOFF_SEQ. Each attempt is bounded by
// `cfg.requestTimeoutMs` via a combined AbortSignal so a hung stream aborts
// instead of blocking forever. Deterministic client errors (400/401/403) and
// user aborts are never retried.
// ---------------------------------------------------------------------------

const EXHAUSTED_MESSAGE =
  "Model returned no response or request timed out after multiple retries. Please try again.";

/** Backoff delays (ms) between retry attempts, indexed by attempt number. */
const BACKOFF_SEQ = [1000, 1000, 2000, 3000, 5000];

/** Content-bearing stream parts — seeing one means the attempt produced output. */
const CONTENT_PARTS = new Set<StreamPart["type"]>([
  "text-start",
  "text-delta",
  "reasoning-start",
  "reasoning-delta",
  "tool-input-start",
  "tool-input-delta",
  "tool-call",
]);

/** Abort-aware sleep that rejects immediately if the signal aborts. */
function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException("The user aborted a request.", "AbortError"));
      return;
    }
    const onAbort = () => {
      clearTimeout(t);
      reject(new DOMException("The user aborted a request.", "AbortError"));
    };
    const t = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

function isUserAbort(err: unknown): boolean {
  return (
    (err instanceof Error && err.name === "AbortError") ||
    (err as any)?.name === "AbortError" ||
    (err instanceof AgentError && err.kind === "aborted")
  );
}

/** Request exceeded requestTimeoutMs — retryable, not a user abort. */
class TimeoutError extends Error {
  constructor() {
    super("Request timed out");
    this.name = "TimeoutError";
  }
}

/** No content was produced (empty/dead stream or whitespace-only response). */
class EmptyResponseError extends Error {
  constructor() {
    super("Model returned an empty response");
    this.name = "EmptyResponseError";
  }
}

/**
 * False for user aborts, deterministic 400/401/403, and terminal `AgentError`
 * kinds (`fatal_auth`/`bad_request`/`aborted`/`max_iterations`); true for
 * `AgentError` kinds `rate_limit`/`network` and for raw errors otherwise.
 */
export function isRetryableError(err: unknown): boolean {
  if (isUserAbort(err)) return false;
  if (err instanceof AgentError) {
    return err.kind === "rate_limit" || err.kind === "network";
  }
  const status: number | undefined =
    (err as any)?.statusCode ?? (err as any)?.status ?? (err as any)?.lastError?.statusCode;
  if (status === 400 || status === 401 || status === 403) return false;
  return true;
}

function isEmptyResult(result: ProviderResult): boolean {
  const content: ResponseBlock[] = result.content ?? [];
  if (content.length === 0) return true;
  // Empty when every block is a whitespace-only text block (no tool_use / thinking / real text).
  return content.every(
    (b) => b.type === "text" && (!b.text || b.text.trim().length === 0),
  );
}

/**
 * On exhausted retries, surface a useful AgentError: preserve the classified
 * kind of a real provider failure (e.g. rate_limit on 429) so the rest of the
 * app can branch on it; fall back to the friendly message only when the failure
 * was an empty/dead response or a timeout (no actionable upstream error).
 */
function exhaustedError(lastErr: unknown): AgentError {
  if (lastErr === undefined || lastErr instanceof EmptyResponseError || lastErr instanceof TimeoutError) {
    return new AgentError(EXHAUSTED_MESSAGE, "network");
  }
  return mapToAgentError(lastErr);
}

/**
 * Per-attempt scope: a combined abort signal (user-abort + timeout), a `race`
 * helper that bounds a promise by the timeout, and timer/cleanup controls. The
 * timeout aborts the controller (best-effort cancellation of the underlying
 * request) AND rejects the race with a TimeoutError, so a hung request can
 * never block forever even if the provider ignores the signal.
 */
function makeAttemptScope(userSignal: AbortSignal | undefined, timeoutMs: number) {
  const controller = new AbortController();
  const onUserAbort = () => controller.abort();
  if (userSignal) {
    if (userSignal.aborted) controller.abort();
    else userSignal.addEventListener("abort", onUserAbort, { once: true });
  }
  let timer: ReturnType<typeof setTimeout> | undefined;
  let timedOut = false;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
      reject(new TimeoutError());
    }, timeoutMs);
  });
  return {
    signal: controller.signal,
    race: <T>(p: Promise<T>): Promise<T> => Promise.race([p, timeout]),
    /** True once the timeout fired — used to distinguish a timeout-driven abort from a user abort. */
    timedOut: () => timedOut,
    /** Stop the timeout (e.g. once a stream's first content has arrived) but keep user-abort linkage. */
    clearTimer: () => { if (timer) clearTimeout(timer); },
    cleanup: () => {
      if (timer) clearTimeout(timer);
      userSignal?.removeEventListener("abort", onUserAbort);
    },
  };
}

/**
 * Decide how to treat a caught attempt error. Returns a normalized error to use
 * as `lastErr`, and whether the loop should stop and surface it as a user abort.
 * Only an abort caused by OUR timeout (scope.timedOut()) is retryable; every
 * other abort (user signal, or an abort thrown mid-stream) is surfaced as
 * `aborted` and not retried.
 */
function classifyAttemptError(
  err: unknown,
  scope: { timedOut: () => boolean },
): { error: unknown; userAborted: boolean } {
  if (isUserAbort(err)) {
    if (scope.timedOut()) return { error: new TimeoutError(), userAborted: false };
    return { error: err, userAborted: true };
  }
  return { error: err, userAborted: false };
}

export function withRetry(cfg: AgentConfig): LanguageModelMiddleware {
  const maxRetries = cfg.maxRetries ?? 5;
  const timeoutMs = cfg.requestTimeoutMs ?? 30_000;

  return {
    async wrapGenerate({ doGenerate, params }) {
      let lastErr: unknown;
      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        const scope = makeAttemptScope(params.abortSignal, timeoutMs);
        try {
          const result = await scope.race(doGenerate({ ...params, abortSignal: scope.signal }));
          if (isEmptyResult(result)) throw new EmptyResponseError();
          return result;
        } catch (err) {
          const { error, userAborted } = classifyAttemptError(err, scope);
          if (userAborted) throw mapToAgentError(error);
          lastErr = error;
          if (attempt < maxRetries && isRetryableError(error)) {
            cfg.onRetryAttempt?.(attempt + 1, maxRetries, error);
            await sleep(BACKOFF_SEQ[Math.min(attempt, BACKOFF_SEQ.length - 1)], params.abortSignal);
            continue;
          }
          break;
        } finally {
          scope.cleanup();
        }
      }
      throw exhaustedError(lastErr);
    },

    async wrapStream({ doStream, params }) {
      let lastErr: unknown;
      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        const scope = makeAttemptScope(params.abortSignal, timeoutMs);
        try {
          // Acquire the stream AND consume up to the first content event, all
          // bounded by the timeout — so an opened-but-silent stream still aborts.
          const acquire = (async () => {
            const { stream } = await doStream({ ...params, abortSignal: scope.signal });
            const iterator = stream[Symbol.asyncIterator]();
            const buffered: StreamPart[] = [];
            let sawContent = false;
            while (!sawContent) {
              const { done, value } = await iterator.next();
              if (done) break;
              buffered.push(value);
              if (value.type === "error") throw value.error ?? new Error("Stream error");
              if (CONTENT_PARTS.has(value.type)) sawContent = true;
            }
            if (!sawContent) throw new EmptyResponseError();
            return { iterator, buffered };
          })();

          const { iterator, buffered } = await scope.race(acquire);
          // First content arrived — stop the timeout so a long but healthy
          // stream is never aborted mid-flight.
          scope.clearTimer();

          // Replay the buffered head, then continue streaming live.
          const merged = (async function* () {
            try {
              for (const p of buffered) yield p;
              for (;;) {
                const { done, value } = await iterator.next();
                if (done) break;
                yield value;
              }
            } finally {
              scope.cleanup();
            }
          })();

          return { stream: merged };
        } catch (err) {
          scope.cleanup();
          const { error, userAborted } = classifyAttemptError(err, scope);
          if (userAborted) throw mapToAgentError(error);
          lastErr = error;
          if (attempt < maxRetries && isRetryableError(error)) {
            cfg.onRetryAttempt?.(attempt + 1, maxRetries, error);
            await sleep(BACKOFF_SEQ[Math.min(attempt, BACKOFF_SEQ.length - 1)], params.abortSignal);
            continue;
          }
          break;
        }
      }
      throw exhaustedError(lastErr);
    },
  };
}
