import Anthropic from "@anthropic-ai/sdk";
import type { AgentConfig } from "../config.js";
import { createAnthropicClient } from "./provider.js";
import { toAnthropicMessages, fromAnthropicResponse } from "./message-converter.js";
import type {
  LanguageModel, ProviderCallOptions, ProviderResult,
  FinishReason, NormalizedUsage, ToolChoice, ProviderWarning,
} from "./provider-types.js";
import { reassembleStream } from "./stream-parts.js";
import type { StreamPart } from "./stream-parts.js";

export class AnthropicLanguageModel implements LanguageModel {
  readonly provider = "anthropic";
  readonly supportedUrls = {};
  get modelId() { return this._cfg.model; }

  public _client: Anthropic;
  private _cfg: AgentConfig;

  constructor(cfg: AgentConfig, opts?: { fetch?: typeof fetch }) {
    this._cfg = cfg;
    this._client = createAnthropicClient(cfg, opts);
  }

  // ---------------------------------------------------------------------------
  // buildParams — shared param builder for both generate() and doStream()
  // ---------------------------------------------------------------------------
  private buildParams(opts: ProviderCallOptions, warnings: ProviderWarning[]): any {
    const { system: extractedSystem, messages: anthropicMsgs } =
      toAnthropicMessages(opts.messages, warnings, {
        modelId: opts.model,
        imageInputEnabled: this._cfg.imageInput,
        modelSupportsVision: anthropicSupportsVision(opts.model),
      });
    // Rolling history cache: one breakpoint on the last block of the last
    // message so a turn's tool-loop steps re-read prior history from cache.
    // (Budget: A+B on system [task 001] + this 1 = 3 of Anthropic's 4.)
    applyRollingCacheBreakpoint(anthropicMsgs);
    const systemPrompt = opts.systemPrompt || extractedSystem || "";
    const anthropicPO = opts.providerOptions?.["anthropic"] as Record<string, unknown> | undefined;
    const systemStatic = anthropicPO?.["systemStatic"] as string | undefined;
    const systemDynamic = anthropicPO?.["systemDynamic"] as string | undefined;

    // Breakpoint A on STATIC (caches tools + static system), B on DYNAMIC.
    let system: string | Anthropic.TextBlockParam[] | undefined;
    if (systemStatic) {
      system = [
        { type: "text", text: systemStatic, cache_control: { type: "ephemeral" } },
        ...(systemDynamic
          ? [{ type: "text", text: systemDynamic, cache_control: { type: "ephemeral" } } as Anthropic.TextBlockParam]
          : []),
      ];
    } else if (systemPrompt) {
      system = systemPrompt;
    }

    const thinkingOpt = opts.providerOptions?.["anthropic"]?.["thinking"] as
      | { type: string; budget_tokens?: number } | undefined;
    const thinkingEnabled = !!thinkingOpt;

    return {
      model: opts.model,
      max_tokens: opts.maxOutputTokens ?? 4096,
      ...(system ? { system } : {}),
      messages: anthropicMsgs,
      ...(opts.tools?.length ? { tools: opts.tools as Anthropic.Tool[] } : {}),
      ...(opts.toolChoice ? { tool_choice: mapToolChoice(opts.toolChoice) } : {}),
      ...(thinkingEnabled
        ? { thinking: { type: "enabled", budget_tokens: thinkingOpt!.budget_tokens ?? 1024 } }
        : {
            ...(opts.temperature !== undefined ? { temperature: opts.temperature } : {}),
            ...(opts.topP !== undefined ? { top_p: opts.topP } : {}),
            ...(opts.topK !== undefined ? { top_k: opts.topK } : {}),
          }),
      ...(opts.stopSequences ? { stop_sequences: opts.stopSequences } : {}),
    };
  }

  // ---------------------------------------------------------------------------
  // generate — non-streaming path unchanged; streaming delegates to doStream()
  // ---------------------------------------------------------------------------
  async generate(opts: ProviderCallOptions): Promise<ProviderResult> {
    if (opts.streaming) {
      const { stream } = await this.doStream(opts);
      return reassembleStream(stream);
    }

    const warnings: ProviderWarning[] = [];
    const params = this.buildParams(opts, warnings);
    const anthropicResp = await this._client.messages.create(params, {
      signal: opts.abortSignal,
    });
    const result = fromAnthropicMessage(anthropicResp);
    if (warnings.length > 0) {
      result.warnings = [...(result.warnings || []), ...warnings];
    }
    return result;
  }

  // ---------------------------------------------------------------------------
  // doStream — iterates Anthropic SDK stream events and emits parts as they arrive
  // ---------------------------------------------------------------------------
  async doStream(opts: ProviderCallOptions): Promise<{ stream: AsyncIterable<StreamPart> }> {
    const warnings: ProviderWarning[] = [];
    const params = this.buildParams(opts, warnings);
    // Use the LOW-LEVEL raw event Stream (messages.create with stream:true), NOT
    // messages.stream(). The latter runs the SDK's strict MessageStream
    // accumulator (maybeParseMessage/partialParse) which throws
    // ("Unexpected non-whitespace character after JSON …") on the non-spec SSE
    // some OpenAI->Anthropic translating gateways emit — e.g. a duplicate
    // message_delta/message_stop after the first message_stop, or trailing
    // OpenAI-style `data: [DONE]` sentinels. The raw Stream just yields each
    // parsed event and tolerates those, and msgToParts only reacts to the event
    // types it knows.
    const rawStream = await this._client.messages.create(
      { ...params, stream: true },
      { signal: opts.abortSignal },
    );
    return { stream: this.msgToParts(rawStream as any, warnings) };
  }

  // ---------------------------------------------------------------------------
  // msgToParts — async generator: iterates MessageStreamEvents incrementally.
  // Never calls finalMessage() — emits each text/thinking/tool delta as it arrives.
  // ---------------------------------------------------------------------------
  private async *msgToParts(messageStream: any, warnings: ProviderWarning[]): AsyncGenerator<StreamPart> {
    yield { type: "stream-start", warnings };

    // Per-index block state
    interface BlockState {
      kind: "text" | "thinking" | "tool_use";
      id: string;
      toolName?: string;
      accInput: string;  // accumulated partial_json for tool_use
      signature: string; // captured from signature_delta for thinking
    }
    const blocks = new Map<number, BlockState>();

    let stopReason: Anthropic.Message["stop_reason"] = null;
    let inputTokens = 0;
    let outputTokens = 0;
    let cachedInputTokens: number | undefined;
    let cacheCreationTokens: number | undefined;

    for await (const event of messageStream) {
      switch (event.type) {
        case "message_start": {
          const u = event.message.usage;
          inputTokens = u.input_tokens;
          cachedInputTokens = (u as any).cache_read_input_tokens ?? undefined;
          cacheCreationTokens = (u as any).cache_creation_input_tokens ?? undefined;
          break;
        }
        case "content_block_start": {
          const { index, content_block: cb } = event;
          if (cb.type === "text") {
            const id = `block_${index}`;
            blocks.set(index, { kind: "text", id, accInput: "", signature: "" });
            yield { type: "text-start", id };
          } else if (cb.type === "thinking") {
            const id = `block_${index}`;
            blocks.set(index, { kind: "thinking", id, accInput: "", signature: "" });
            yield { type: "reasoning-start", id };
          } else if (cb.type === "tool_use") {
            blocks.set(index, { kind: "tool_use", id: cb.id, toolName: cb.name, accInput: "", signature: "" });
            yield { type: "tool-input-start", id: cb.id, toolName: cb.name };
          }
          // redacted_thinking: no normalized representation — silently skip
          break;
        }
        case "content_block_delta": {
          const { index, delta } = event;
          const block = blocks.get(index);
          if (!block) break;
          if (delta.type === "text_delta") {
            yield { type: "text-delta", id: block.id, delta: delta.text };
          } else if (delta.type === "thinking_delta") {
            yield { type: "reasoning-delta", id: block.id, delta: delta.thinking };
          } else if (delta.type === "signature_delta") {
            block.signature += (delta as any).signature;
          } else if (delta.type === "input_json_delta") {
            block.accInput += delta.partial_json;
            yield { type: "tool-input-delta", id: block.id, delta: delta.partial_json };
          }
          break;
        }
        case "content_block_stop": {
          const block = blocks.get(event.index);
          if (!block) break;
          if (block.kind === "text") {
            yield { type: "text-end", id: block.id };
          } else if (block.kind === "thinking") {
            yield { type: "reasoning-end", id: block.id, ...(block.signature ? { signature: block.signature } : {}) };
          } else if (block.kind === "tool_use") {
            yield { type: "tool-input-end", id: block.id };
            yield { type: "tool-call", toolCallId: block.id, toolName: block.toolName!, input: block.accInput };
          }
          break;
        }
        case "message_delta": {
          stopReason = event.delta.stop_reason;
          outputTokens = event.usage.output_tokens;
          break;
        }
        // message_stop: no action needed — loop ends naturally
      }
    }

    yield {
      type: "finish",
      finishReason: mapFinishReason(stopReason),
      usage: { inputTokens, outputTokens, cachedInputTokens, cacheCreationTokens },
    };
  }
}

export function createAnthropicLanguageModel(
  cfg: AgentConfig,
  opts?: { fetch?: typeof fetch },
): AnthropicLanguageModel {
  return new AnthropicLanguageModel(cfg, opts);
}

// ---------------------------------------------------------------------------
// applyRollingCacheBreakpoint: tag the LAST content block of the LAST message
// with cache_control ephemeral, so within a turn the tool-loop steps re-read
// the (append-only) prior history from Anthropic's prompt cache. Exactly one
// message-level breakpoint is ever added. Mutates `messages` in place.
// ---------------------------------------------------------------------------
function applyRollingCacheBreakpoint(messages: Anthropic.MessageParam[]): void {
  if (messages.length === 0) return;
  const last = messages[messages.length - 1];
  const cc = { type: "ephemeral" } as const;

  if (typeof last.content === "string") {
    if (last.content.length === 0) return; // nothing worth caching
    // A bare string can't carry cache_control — normalize to one text block.
    last.content = [{ type: "text", text: last.content, cache_control: cc }];
    return;
  }

  const blocks = last.content;
  if (!Array.isArray(blocks) || blocks.length === 0) return;
  const lastBlock = blocks[blocks.length - 1];
  // All Anthropic block-param types accept optional cache_control; cast to set
  // it uniformly (text / tool_result / image / tool_use).
  (lastBlock as { cache_control?: Anthropic.CacheControlEphemeral }).cache_control = cc;
}

// ---------------------------------------------------------------------------
// mapToolChoice: our ToolChoice → Anthropic tool_choice param
// ---------------------------------------------------------------------------
function mapToolChoice(tc: ToolChoice): Anthropic.MessageCreateParams['tool_choice'] {
  switch (tc.type) {
    case "auto":     return { type: "auto" };
    case "required": return { type: "any" };
    case "none":     return { type: "auto" }; // Anthropic has no "none", skip silently
    case "tool":     return { type: "tool", name: tc.toolName };
  }
}

// ---------------------------------------------------------------------------
// fromAnthropicMessage: maps Anthropic.Message → ProviderResult
// ---------------------------------------------------------------------------
function fromAnthropicMessage(response: Anthropic.Message): ProviderResult {
  const legacy = fromAnthropicResponse(response);

  return {
    content: legacy.content,
    finishReason: mapFinishReason(response.stop_reason),
    usage: {
      inputTokens: response.usage.input_tokens,
      outputTokens: response.usage.output_tokens,
      cachedInputTokens: (response.usage as any).cache_read_input_tokens ?? undefined,
      cacheCreationTokens: (response.usage as any).cache_creation_input_tokens ?? undefined,
    },
    warnings: [],
  };
}

// Normalized finishReason mapping
function mapFinishReason(raw: Anthropic.Message["stop_reason"]): FinishReason {
  switch (raw) {
    case "end_turn":      return "stop";
    case "tool_use":      return "tool-calls";
    case "max_tokens":    return "length";
    case "stop_sequence": return "stop";
    case "refusal":       return "content-filter";
    case "pause_turn":    return "other";
    default:              return "unknown";
  }
}

function anthropicSupportsVision(model: string): boolean {
  const lower = model.toLowerCase();
  return (
    lower.includes("claude-3") ||
    lower.includes("gemma-4") ||
    lower.includes("gemma4") ||
    lower.includes("gpt-4o") ||
    lower.includes("gpt-4-turbo") ||
    lower.includes("vision")
  );
}
