import type { FinishReason, NormalizedUsage, ProviderWarning, ProviderMetadata, ProviderResult } from "./provider-types.js";
import type { ResponseBlock } from "../types.js";

// ---------------------------------------------------------------------------
// StreamPart — normalized stream-event union (mirrors AI SDK LanguageModelV2StreamPart)
// reasoning-start carries an optional signature for providers that supply one
// (e.g. Anthropic thinking blocks).
// ---------------------------------------------------------------------------
export type StreamPart =
  | { type: "stream-start"; warnings: ProviderWarning[] }
  | { type: "text-start"; id: string }
  | { type: "text-delta"; id: string; delta: string }
  | { type: "text-end"; id: string }
  | { type: "reasoning-start"; id: string; signature?: string }
  | { type: "reasoning-delta"; id: string; delta: string }
  | { type: "reasoning-end"; id: string; signature?: string }
  | { type: "tool-input-start"; id: string; toolName: string }
  | { type: "tool-input-delta"; id: string; delta: string }
  | { type: "tool-input-end"; id: string }
  | { type: "tool-call"; toolCallId: string; toolName: string; input: string }
  | { type: "finish"; finishReason: FinishReason; usage: NormalizedUsage; providerMetadata?: ProviderMetadata }
  | { type: "error"; error: unknown };

// ---------------------------------------------------------------------------
// safeJsonParse
// ---------------------------------------------------------------------------
export function safeJsonParse(s: string): Record<string, unknown> {
  try {
    return JSON.parse(s);
  } catch {
    return {};
  }
}

// ---------------------------------------------------------------------------
// isParsableJson — internal helper for StreamingToolCallTracker
// ---------------------------------------------------------------------------
function isParsableJson(s: string): boolean {
  if (!s) return false;
  try {
    JSON.parse(s);
    return true;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// StreamingToolCallTracker
// Minimal port of AI SDK streaming-tool-call-tracker. Accumulates OpenAI-style
// tool_call deltas (by index) and emits normalized tool-input-* + tool-call
// parts via an emit callback instead of a TransformStream controller.
// ---------------------------------------------------------------------------
interface TrackedToolCall {
  id: string;
  name: string;
  args: string;
  hasFinished: boolean;
}

export class StreamingToolCallTracker {
  private toolCalls: TrackedToolCall[] = [];
  private readonly emit: (part: StreamPart) => void;

  constructor(emit: (part: StreamPart) => void) {
    this.emit = emit;
  }

  processDelta(delta: {
    index?: number | null;
    id?: string | null;
    type?: string | null;
    function?: { name?: string | null; arguments?: string | null } | null;
  }): void {
    const index = delta.index ?? this.toolCalls.length;

    if (this.toolCalls[index] == null) {
      // typeValidation: if-present — silently skip unknown types
      if (delta.type != null && delta.type !== "function") return;
      if (!delta.id || !delta.function?.name) return;

      const args = delta.function.arguments ?? "";
      this.emit({ type: "tool-input-start", id: delta.id, toolName: delta.function.name });

      this.toolCalls[index] = { id: delta.id, name: delta.function.name, args, hasFinished: false };

      if (args.length > 0) {
        this.emit({ type: "tool-input-delta", id: delta.id, delta: args });
      }
      if (isParsableJson(args)) {
        this.finishToolCall(this.toolCalls[index]);
      }
    } else {
      const tc = this.toolCalls[index];
      if (tc.hasFinished) return;

      const argsDelta = delta.function?.arguments;
      if (argsDelta != null) {
        tc.args += argsDelta;
        this.emit({ type: "tool-input-delta", id: tc.id, delta: argsDelta });
      }
      if (isParsableJson(tc.args)) {
        this.finishToolCall(tc);
      }
    }
  }

  flush(): void {
    for (const tc of this.toolCalls) {
      if (!tc.hasFinished) {
        this.finishToolCall(tc);
      }
    }
  }

  private finishToolCall(tc: TrackedToolCall): void {
    this.emit({ type: "tool-input-end", id: tc.id });
    this.emit({ type: "tool-call", toolCallId: tc.id, toolName: tc.name, input: tc.args });
    tc.hasFinished = true;
  }
}

// ---------------------------------------------------------------------------
// reassembleStream — the ONE shared reassembler.
// Consumes an AsyncIterable<StreamPart> and produces a ProviderResult.
// Preserves emission order of blocks so stream → reassembled == non-stream.
// ---------------------------------------------------------------------------
interface TextAcc     { kind: "text";      id: string; text: string }
interface ReasoningAcc { kind: "reasoning"; id: string; text: string; signature: string }
interface ToolAcc     { kind: "tool";      id: string; name: string; input: string }
type BlockAcc = TextAcc | ReasoningAcc | ToolAcc;

export async function reassembleStream(
  stream: AsyncIterable<StreamPart>,
): Promise<ProviderResult> {
  let warnings: ProviderWarning[] = [];
  let finishReason: FinishReason = "unknown";
  let usage: NormalizedUsage = { inputTokens: 0, outputTokens: 0 };
  let providerMetadata: ProviderMetadata | undefined;

  const blockMap = new Map<string, BlockAcc>();
  const seenIds = new Set<string>();
  const blockOrder: BlockAcc[] = [];

  function ensureText(id: string): TextAcc {
    if (!seenIds.has(id)) {
      const b: TextAcc = { kind: "text", id, text: "" };
      blockMap.set(id, b);
      seenIds.add(id);
      blockOrder.push(b);
    }
    return blockMap.get(id) as TextAcc;
  }

  function ensureReasoning(id: string, signature = ""): ReasoningAcc {
    if (!seenIds.has(id)) {
      const b: ReasoningAcc = { kind: "reasoning", id, text: "", signature };
      blockMap.set(id, b);
      seenIds.add(id);
      blockOrder.push(b);
    }
    return blockMap.get(id) as ReasoningAcc;
  }

  function ensureTool(id: string, name = ""): ToolAcc {
    if (!seenIds.has(id)) {
      const b: ToolAcc = { kind: "tool", id, name, input: "" };
      blockMap.set(id, b);
      seenIds.add(id);
      blockOrder.push(b);
    }
    return blockMap.get(id) as ToolAcc;
  }

  for await (const part of stream) {
    switch (part.type) {
      case "stream-start":
        warnings = part.warnings;
        break;
      case "text-start":
        ensureText(part.id);
        break;
      case "text-delta":
        ensureText(part.id).text += part.delta;
        break;
      case "text-end":
        break;
      case "reasoning-start":
        ensureReasoning(part.id, part.signature ?? "");
        break;
      case "reasoning-delta":
        ensureReasoning(part.id).text += part.delta;
        break;
      case "reasoning-end":
        if (part.signature) ensureReasoning(part.id).signature = part.signature;
        break;
      case "tool-input-start":
        ensureTool(part.id, part.toolName);
        break;
      case "tool-input-delta":
        break;
      case "tool-input-end":
        break;
      case "tool-call": {
        const b = ensureTool(part.toolCallId, part.toolName);
        b.name = part.toolName;
        b.input = part.input;
        break;
      }
      case "finish":
        finishReason = part.finishReason;
        usage = part.usage;
        providerMetadata = part.providerMetadata;
        break;
      case "error":
        throw part.error;
    }
  }

  const content: ResponseBlock[] = blockOrder.map(b => {
    if (b.kind === "text") return { type: "text" as const, text: b.text };
    if (b.kind === "reasoning") return { type: "thinking" as const, thinking: b.text, signature: b.signature };
    return { type: "tool_use" as const, id: b.id, name: b.name, input: safeJsonParse(b.input) };
  });

  const result: ProviderResult = { content, finishReason, usage, warnings };
  if (providerMetadata !== undefined) result.providerMetadata = providerMetadata;
  return result;
}
