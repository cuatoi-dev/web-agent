import { ContextManager, AuditEntry, JournalEntry } from "./loop/context-manager.js";
import { createPageAgent, createLlmSummarizer, runBareTurn } from "./loop/agent.js";
import { runTurn } from "./loop/run-turn.js";
import { IdbSessionStore, SessionStore, SessionMeta } from "./loop/session-store.js";
import { buildFlushRecord, reconstructState } from "./loop/session-lifecycle.js";
import { buttonToMessage, formSubmitToMessage } from "./ui-blocks/bridge.js";
import { RenderableBlock } from "./ui-blocks/schema.js";
import { AgentConfig, DEFAULT_CONFIG, defaultBaseURLFor } from "./config.js";
import { ToolContext } from "./tools/build-tools.js";
import type { CustomToolDef } from "./tools/build-tools.js";
import { defaultTools } from "./tools/builders.js";
import { connectMcpServers, type McpClientSession } from "./mcp/index.js";
import { DomAdapter, ActionCueFn } from "./adapters/dom-adapter.js";
import type { ConfirmInteractionFn } from "./adapters/permission-resolver.js";
import { StateAdapter } from "./adapters/state-adapter.js";
import { createDataSourceProvider } from "./datasource/provider.js";
import { runCompaction } from "./loop/compaction.js";
import { isRetryableError } from "./transport/middleware.js";
import { UserMessageInput, ImageAttachment } from "./utils/types.js";
import { buildPointedElementsBlock } from "./utils/pointed-elements.js";

export type MessagePart =
  | { type: "text"; text: string }
  | { type: "image"; dataUrl: string; mediaType: string }
  | { type: "tool"; name: string; data: unknown }
  | { type: "pointed"; items: { role: string; name: string; el: Element }[] };

export interface SessionMessagePart {
  kind: "text" | "block" | "tool";
  text?: string;
  block?: RenderableBlock;
  /** Present for kind: "tool" — the compact record of the tool call this step ran. */
  audit?: AuditEntry;
}

export interface SessionMessage {
  role: "user" | "assistant" | "system";
  text?: string;
  images?: { dataUrl: string; mediaType: string }[];
  parts?: SessionMessagePart[];
  blocks?: RenderableBlock[];
  trace?: AuditEntry[];
  disabled?: boolean;
  failed?: { message: string; retryable: boolean };
  /** 016-2: role/name of pinned elements sent with this user message. */
  pointedItems?: { role: string; name: string }[];
  /** 074: true while this assistant message's turn is still running (awaiting
   * more steps). Used by the UI to show the mid-turn "working" placeholder. */
  pending?: boolean;
}

export interface QueuedMessage {
  id: string;
  text: string;
  images?: ImageAttachment[];
}

export interface SessionState {
  messages: SessionMessage[];
  sessions: SessionMeta[];
  activeSessionId: string;
  running: boolean;
  error?: string;
  usage: { input: number; output: number };
  contextWindow: { used: number; total: number; percent: number };
  queuedMessages: QueuedMessage[];
  /** The active model id (067 runtime switcher). Mirrors the agent's live model. */
  model: string;
  /** 074: id of the turn currently in flight (undefined when idle). Lets the
   * UI attach a mid-turn "working" indicator to the right turn. */
  inProgressTurnId?: string;
}

export interface SessionConfig extends Partial<AgentConfig> {
  appContext?: {
    appName?: string;
    appDescription?: string;
    userName?: string;
    userInfo?: string;
  };
  store?: any;
  sources?: any[];
  fetch?: typeof fetch;
  actionCue?: ActionCueFn;
  typingPaceMs?: () => number;
}

export type SessionEvent =
  | { type: "retry:start" }
  | { type: "retry:success" }
  | { type: "retry:failure"; error: { message: string; retryable: boolean } }
  | { type: "auto-retry:attempt"; attempt: number; maxRetries: number; error: { message: string } };

export interface AgentSession {
  getState(): SessionState;
  subscribe(listener: (s: SessionState) => void): () => void;
  subscribeEvents(listener: (e: SessionEvent) => void): () => void;
  send(parts: MessagePart[]): Promise<void>;
  retryLast(): Promise<void>;
  abort(): void;
  compact(): Promise<void>;
  reset(): Promise<void>;
  createSession(): Promise<void>;
  switchSession(id: string): Promise<void>;
  deleteSession(id: string): Promise<void>;
  clearAllSessions(): Promise<void>;
  setTitle(id: string, t: string): Promise<void>;
  refreshSessions(): Promise<void>;
  updateConfig(patch: Partial<SessionConfig>): void;
  /**
   * Swap the active model at runtime for the NEXT turn, without resetting the
   * conversation (does NOT re-init the ContextManager/agent). Per-session only.
   */
  setModel(id: string): void;
  dispose(): void;
  initPromise: Promise<void>;
  autoTitle(): Promise<void>;
  cancelQueued(id: string): void;
  popLastQueued(): { text: string; images?: ImageAttachment[] } | undefined;
  clearQueue(): void;
}

function partsToInput(parts: MessagePart[]): { text: string; images: ImageAttachment[] } {
  const userTextParts: string[] = [];
  const images: ImageAttachment[] = [];
  for (const part of parts) {
    if (part.type === "text") userTextParts.push(part.text);
    else if (part.type === "image") images.push({ dataUrl: part.dataUrl, mediaType: part.mediaType });
    else if (part.type === "tool") {
      if (part.name === "button") userTextParts.push(buttonToMessage(part.data as string));
      else if (part.name === "form_submit") {
        const d = part.data as { id: string; values: Record<string, unknown> };
        userTextParts.push(formSubmitToMessage(d.id, d.values));
      } else userTextParts.push(`[ui_action:${part.name}] ${JSON.stringify(part.data)}`);
    }
  }
  return { text: userTextParts.join("\n"), images };
}

export function createAgentSession(config: SessionConfig): AgentSession {
  let currentConfig = { ...config };
  let agentConfig: AgentConfig & { fetch?: typeof fetch };
  let sessionStore: SessionStore | undefined;
  let cm: ContextManager;
  let ctx: ToolContext;
  let agent: any;
  /** Tools discovered from configured MCP servers; empty until initPromise's connect step resolves. */
  let mcpTools: CustomToolDef[] = [];
  /** Open MCP sessions, closed on dispose(). */
  let mcpSessions: McpClientSession[] = [];

  let activeSessionId = "";
  let running = false;
  let queuedMessages: QueuedMessage[] = [];
  let error: string | undefined = undefined;
  const usage = { input: 0, output: 0 };
  let sessions: SessionMeta[] = [];
  const toolBlocks = new Map<string, RenderableBlock>();
  let controller: AbortController | undefined = undefined;
  let flushedJournalLength = 0;
  const listeners = new Set<(s: SessionState) => void>();
  const eventListeners = new Set<(e: SessionEvent) => void>();

  function emitEvent(e: SessionEvent) {
    for (const l of eventListeners) {
      try {
        l(e);
      } catch (err) {
        console.error("Event listener error:", err);
      }
    }
  }

  function buildConfig() {
    const endpointType = currentConfig.endpointType || DEFAULT_CONFIG.endpointType;
    const baseURL = currentConfig.baseURL ||
      (endpointType === "mock" ? "" : defaultBaseURLFor(endpointType as "anthropic" | "openai"));
    agentConfig = {
      ...DEFAULT_CONFIG,
      ...currentConfig,
      baseURL,
      endpointType,
      thinking: currentConfig.thinking ?? DEFAULT_CONFIG.thinking,
      generation: {
        ...DEFAULT_CONFIG.generation,
        ...currentConfig.generation,
        ...(currentConfig.maxRetries !== undefined && currentConfig.generation?.maxRetries === undefined
          ? { maxRetries: currentConfig.maxRetries }
          : {}),
      },
      cues: currentConfig.cues ?? DEFAULT_CONFIG.cues,
      images: currentConfig.images ?? DEFAULT_CONFIG.images,
      imageInput: currentConfig.imageInput ?? DEFAULT_CONFIG.imageInput,
      persist: currentConfig.persist ?? DEFAULT_CONFIG.persist,
      streaming: currentConfig.streaming ?? DEFAULT_CONFIG.streaming,
      fetch: currentConfig.fetch,
      onRetryAttempt: (attempt: number, maxRetries: number, error: unknown) => {
        const errorMsg = error instanceof Error ? error.message : String(error);
        emitEvent({
          type: "auto-retry:attempt",
          attempt,
          maxRetries,
          error: { message: errorMsg },
        });
      },
    } as any;

    if (agentConfig.persist) {
      sessionStore = currentConfig.sessionStore ?? agentConfig.sessionStore ?? new IdbSessionStore(currentConfig.sessionNamespace);
    } else {
      sessionStore = undefined;
    }
  }

  function initAgent() {
    cm = new ContextManager(agentConfig.context);

    const domAdapter = new DomAdapter({
      root: typeof document !== "undefined" ? document : undefined,
      snapshotMaxChars: agentConfig.snapshotMaxChars,
      snapshotMaxDepth: agentConfig.snapshotMaxDepth,
      snapshotSubtreeMaxNodes: agentConfig.snapshotSubtreeMaxNodes,
      snapshotMaxNodes: agentConfig.snapshotMaxNodes,
      confirmInteraction: agentConfig.confirmInteraction,
      imageLimits: agentConfig.images,
      agentUiSelector: "[data-agent-ui]",
      actionCue: (agentConfig as any).actionCue,
      typingPaceMs: (agentConfig as any).typingPaceMs,
    });

    const stateAdapter = new StateAdapter(() => currentConfig.store?.getState?.() ?? {});

    const dataSource = createDataSourceProvider({
      getState: () => currentConfig.store?.getState?.() ?? {},
      sources: currentConfig.sources || [],
    });

    ctx = {
      domAdapter,
      stateAdapter,
      dataSource,
      app: {
        appName: currentConfig.appContext?.appName || "Web Application",
        appDescription: currentConfig.appContext?.appDescription || "An interactive web application.",
        route: currentConfig.store?.getState?.()?.ui?.route || "/",
        stateShapeSummary: stateAdapter.describeShape(),
        userName: currentConfig.appContext?.userName,
        userInfo: currentConfig.appContext?.userInfo,
      },
      signal: new AbortController().signal,
      _onToolBlock: (toolCallId, block) => {
        toolBlocks.set(toolCallId, block);
        notifyListeners();
      },
    };

    // MCP tools are appended to whatever the host's factory returns. A shallow
    // copy (not a mutation of agentConfig.tools) keeps this idempotent — initAgent()
    // runs again after the connect step and on every updateConfig().
    const baseToolsFactory = agentConfig.tools ?? defaultTools;
    const cfgForAgent =
      mcpTools.length > 0
        ? {
            ...agentConfig,
            tools: (c: ToolContext) => [...baseToolsFactory(c), ...mcpTools],
          }
        : agentConfig;
    agent = createPageAgent(cfgForAgent, ctx, cm);
  }

  buildConfig();
  initAgent();

  async function refreshSessions() {
    if (sessionStore) {
      sessions = await sessionStore.loadAllMetadata();
    } else {
      sessions = [
        {
          id: activeSessionId || "default-session",
          title: "Default Session",
          titleManual: false,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          messageCount: cm.journal.length,
        },
      ];
    }
  }

  async function openOrCreateActiveSession() {
    if (!sessionStore) {
      activeSessionId = "default-session";
      flushedJournalLength = 0;
      await refreshSessions();
      notifyListeners();
      return;
    }

    try {
      const allSessions = await sessionStore.loadAllMetadata();
      let sessId = "";
      let loadedJournalLength = 0;
      if (allSessions.length === 0) {
        sessId = crypto.randomUUID();
        const now = Date.now();
        await sessionStore.createSession({
          id: sessId,
          title: "",
          titleManual: false,
          createdAt: now,
          updatedAt: now,
          messageCount: 0,
        });
      } else {
        sessId = allSessions[0].id;
        const records = await sessionStore.loadMessages(sessId);
        const { journal, memo, audit } = reconstructState(records);
        cm.rehydrateState(journal, memo, audit);
        loadedJournalLength = journal.length;
      }

      activeSessionId = sessId;
      flushedJournalLength = loadedJournalLength;
      await refreshSessions();
    } catch (err) {
      console.error("[session] init failed:", err);
    }
    notifyListeners();
  }

  async function connectConfiguredMcpServers(): Promise<void> {
    const result = await connectMcpServers(agentConfig.mcpServers);
    mcpTools = result.tools;
    mcpSessions = result.sessions;
    if (mcpTools.length > 0) {
      // Rebuild the agent so turn 1 already has the MCP tools and their prompt
      // snippets. Must happen BEFORE openOrCreateActiveSession(), which rehydrates
      // the journal into `cm` — initAgent() replaces `cm`.
      initAgent();
    }
  }

  const initPromise = (async () => {
    try {
      await connectConfiguredMcpServers();
    } catch (err) {
      // required: true failed — a hard startup error, surfaced loudly.
      const message = err instanceof Error ? err.message : String(err);
      console.error("[mcp] startup failed:", err);
      error = message;
      notifyListeners();
      throw err;
    }
    await openOrCreateActiveSession();
  })();
  // Mark the rejection handled so a host that never awaits initPromise does not
  // trip an unhandled-rejection warning. Awaiters still receive the rejection.
  initPromise.catch(() => {});

  function flushTurn() {
    if (!sessionStore || !activeSessionId) return;
    const newEntries = cm.journal.slice(flushedJournalLength);
    flushedJournalLength = cm.journal.length;
    const record = buildFlushRecord(newEntries, cm.memo, cm.audit);
    sessionStore
      .appendMessages(activeSessionId, [record])
      .catch((err) => console.error("[session] appendMessages failed:", err));
    sessionStore
      .saveMeta(activeSessionId, {
        updatedAt: Date.now(),
        messageCount: cm.journal.length,
      })
      .catch((err) => console.error("[session] saveMeta failed:", err));
  }

  function reflushAll() {
    if (!sessionStore || !activeSessionId) return;
    flushedJournalLength = cm.journal.length;
    const records = cm.journal.length
      ? [buildFlushRecord(cm.journal.slice(), cm.memo, cm.audit)]
      : [];
    sessionStore.overwriteMessages(activeSessionId, records)
      .catch((err) => console.error("[session] overwriteMessages failed:", err));
    sessionStore.saveMeta(activeSessionId, { updatedAt: Date.now(), messageCount: cm.journal.length })
      .catch((err) => console.error("[session] saveMeta failed:", err));
  }

  function getMessageText(msg: any): string {
    if (typeof msg.content === "string") {
      return msg.content;
    }
    if (Array.isArray(msg.content)) {
      return msg.content
        .filter((part: any) => part.type === "text" && typeof part.text === "string")
        .map((part: any) => part.text)
        .join("\n");
    }
    return "";
  }

  function getAssistantParts(
    tid: string,
    journal: JournalEntry[],
    turnAudit: AuditEntry[],
  ): SessionMessagePart[] {
    const parts: SessionMessagePart[] = [];
    let textAcc = "";
    let auditIdx = 0;

    const flushText = () => {
      if (textAcc) {
        parts.push({ kind: "text", text: textAcc });
        textAcc = "";
      }
    };

    for (const entry of journal) {
      if (entry.meta.turnId !== tid) continue;
      if (entry.msg.role !== "assistant") continue;

      const stepText = getMessageText(entry.msg);
      if (stepText) {
        textAcc += (textAcc ? "\n" : "") + stepText;
      }

      const content = Array.isArray(entry.msg.content) ? entry.msg.content : [];
      for (const part of content as any[]) {
        if (part.type === "tool-call") {
          // Match this call to its audit entry by name, in order.
          let audit: AuditEntry | undefined;
          for (let k = auditIdx; k < turnAudit.length; k++) {
            if (turnAudit[k].name === part.toolName) {
              audit = turnAudit[k];
              auditIdx = k + 1;
              break;
            }
          }
          const block = toolBlocks.get(part.toolCallId);
          flushText();
          if (block) {
            parts.push({ kind: "block", block });
          } else {
            parts.push({
              kind: "tool",
              audit: audit ?? {
                ts: Date.now(),
                name: part.toolName,
                input: part.input,
                outcomeSummary: "",
              },
            });
          }
        }
      }
    }

    flushText();
    return parts;
  }

  function getState(): SessionState {
    const journal = cm.journal;
    const audit = cm.audit;
    const inProgressTurnId = running ? cm.activeTurnId : undefined;

    const turns: {
      [turnId: string]: {
        userText: string;
        assistantText: string;
        userImages: { dataUrl: string; mediaType: string }[];
        userPointedItems?: { role: string; name: string }[];
        failed?: { message: string; retryable: boolean };
      };
    } = {};
    const turnIdsOrder: string[] = [];
    const turnAudits: { [turnId: string]: AuditEntry[] } = {};

    let auditIdx = 0;
    for (const entry of journal) {
      const tid = entry.meta.turnId;
      if (!turns[tid]) {
        turns[tid] = { userText: "", assistantText: "", userImages: [] };
        turnIdsOrder.push(tid);
      }

      if (entry.meta.failed) {
        turns[tid].failed = entry.meta.failed;
      }

      if (entry.msg.role === "tool" && Array.isArray(entry.msg.content)) {
        for (const part of entry.msg.content) {
          if (part.type === "tool-result") {
            const toolName = part.toolName;
            let foundAudit: AuditEntry | null = null;
            for (let k = auditIdx; k < audit.length; k++) {
              if (audit[k].name === toolName) {
                foundAudit = audit[k];
                auditIdx = k + 1;
                break;
              }
            }
            if (foundAudit) {
              if (!turnAudits[tid]) {
                turnAudits[tid] = [];
              }
              turnAudits[tid].push(foundAudit);
            }
          }
        }
      }
    }

    for (const entry of journal) {
      const tid = entry.meta.turnId;
      const text = getMessageText(entry.msg);
      if (entry.msg.role === "user") {
        if (entry.meta.pointedItems && entry.meta.pointedItems.length > 0) {
          const displayText = entry.meta.userDisplayText ?? "";
          if (displayText) {
            turns[tid].userText += (turns[tid].userText ? "\n" : "") + displayText;
          }
          turns[tid].userPointedItems = entry.meta.pointedItems;
        } else {
          turns[tid].userText += (turns[tid].userText ? "\n" : "") + text;
        }
        if (Array.isArray(entry.msg.content)) {
          for (const part of entry.msg.content as any[]) {
            if (part.type === "image" && typeof part.image === "string") {
              turns[tid].userImages.push({
                dataUrl: part.image,
                mediaType: (part.mediaType as string) || "image/jpeg",
              });
            }
          }
        }
      } else if (entry.msg.role === "assistant") {
        turns[tid].assistantText += (turns[tid].assistantText ? "\n" : "") + text;
      }
    }

    const messages: SessionMessage[] = [];
    for (const tid of turnIdsOrder) {
      const turn = turns[tid];
      const hasUserContent = !!turn.userText || turn.userImages.length > 0 ||
        !!(turn.userPointedItems && turn.userPointedItems.length > 0);
      let userMessage: SessionMessage | undefined;
      if (hasUserContent) {
        userMessage = {
          role: "user",
          text: turn.userText || undefined,
          images: turn.userImages.length > 0 ? turn.userImages : undefined,
          pointedItems: turn.userPointedItems,
        };
        messages.push(userMessage);
      }
      let assistantMessage: SessionMessage | undefined;
      if (turn.assistantText || (turnAudits[tid] && turnAudits[tid].length > 0)) {
        const parts = getAssistantParts(tid, journal, turnAudits[tid] || []);
        const textParts = parts.filter((p): p is { kind: "text"; text: string } => p.kind === "text");
        const blockParts = parts.filter((p): p is { kind: "block"; block: RenderableBlock } => p.kind === "block");

        assistantMessage = {
          role: "assistant",
          text: textParts.map((p) => p.text).join(""),
          parts,
          blocks: blockParts.map((p) => p.block),
          trace: turnAudits[tid] || [],
        };
        if (inProgressTurnId && tid === inProgressTurnId) {
          assistantMessage.pending = true;
        }
        messages.push(assistantMessage);
      }
      if (turn.failed) {
        if (assistantMessage) {
          assistantMessage.failed = turn.failed;
        } else if (userMessage) {
          userMessage.failed = turn.failed;
        }
      }
    }

    let lastAssistantIdx = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === "assistant") {
        lastAssistantIdx = i;
        break;
      }
    }

    for (let i = 0; i < messages.length; i++) {
      if (messages[i].role === "assistant") {
        messages[i].disabled = running ? true : i !== lastAssistantIdx;
      }
    }

    const cmUsage = cm.getUsage();
    const contextWindow = {
      used: cmUsage.tokens,
      total: cmUsage.max,
      percent: cmUsage.percent,
    };

    return {
      messages,
      sessions,
      activeSessionId,
      running,
      error,
      usage,
      contextWindow,
      queuedMessages: queuedMessages.map((q) => ({
        ...q,
        images: q.images ? [...q.images] : undefined,
      })),
      model: agentConfig.model,
      inProgressTurnId,
    };
  }

  function notifyListeners() {
    const s = getState();
    for (const listener of listeners) {
      try {
        listener(s);
      } catch (err) {
        console.error("Listener error:", err);
      }
    }
  }

  function abort() {
    if (controller) {
      controller.abort();
    }
    running = false;
    notifyListeners();
  }

  function doUpdateConfig(patch: Partial<SessionConfig>) {
    currentConfig = { ...currentConfig, ...patch };
    buildConfig();
    initAgent();
    notifyListeners();
  }

  function doSetModel(id: string) {
    if (!id || id === agentConfig.model) return;
    // Non-destructive: mutate the live agent + configs in place so the NEXT
    // turn, compaction (createLlmSummarizer), and autoTitle all use `id`,
    // WITHOUT calling buildConfig()/initAgent() (which would reset the journal).
    agent.setModel(id);
    agentConfig.model = id;
    currentConfig.model = id;
    notifyListeners();
  }

  async function createSession(): Promise<void> {
    if (running) abort();

    const sessionId = crypto.randomUUID();
    if (sessionStore) {
      const now = Date.now();
      await sessionStore.createSession({
        id: sessionId,
        title: "",
        titleManual: false,
        createdAt: now,
        updatedAt: now,
        messageCount: 0,
      });
    }

    toolBlocks.clear();
    queuedMessages = [];
    activeSessionId = sessionId;
    flushedJournalLength = 0;
    cm.reset();
    await refreshSessions();
    notifyListeners();
  }

  async function switchSession(id: string): Promise<void> {
    if (activeSessionId === id) return;
    if (running) abort();

    if (sessionStore) {
      const records = await sessionStore.loadMessages(id);
      const { journal, memo, audit } = reconstructState(records);
      toolBlocks.clear();
      queuedMessages = [];
      activeSessionId = id;
      flushedJournalLength = journal.length;
      cm.rehydrateState(journal, memo, audit);
    } else {
      queuedMessages = [];
      activeSessionId = id;
    }
    await refreshSessions();
    notifyListeners();
  }

  async function deleteSession(id: string): Promise<void> {
    if (sessionStore) {
      await sessionStore.deleteByIds([id]);
    }
    if (activeSessionId === id) {
      await createSession();
    } else {
      await refreshSessions();
      notifyListeners();
    }
  }

  async function clearAllSessions(): Promise<void> {
    if (running) abort();
    if (sessionStore) {
      const all = await sessionStore.loadAllMetadata();
      if (all.length) await sessionStore.deleteByIds(all.map((m) => m.id));
    }
    await createSession();
  }

  async function setTitle(id: string, t: string): Promise<void> {
    if (sessionStore) {
      await sessionStore.saveMeta(id, { title: t, titleManual: true });
    }
    await refreshSessions();
    notifyListeners();
  }

  async function compact(): Promise<void> {
    if (running) return;
    if (!cm.hasCompactableTurns()) return;

    running = true;
    notifyListeners();
    try {
      const summarize = createLlmSummarizer(agentConfig);
      await runCompaction(cm, { summarize });
      flushTurn();
    } catch (e: any) {
      console.error("Compaction failed:", e);
    } finally {
      running = false;
      notifyListeners();
    }
  }

  async function reset(): Promise<void> {
    await createSession();
  }

  async function runUserTurn(
    userInput: string | UserMessageInput,
    opts?: { fullReflush?: boolean }
  ): Promise<void> {
    running = true;
    error = undefined;
    notifyListeners();

    controller = new AbortController();

    try {
      if (ctx.app) {
        ctx.app.route = currentConfig.store?.getState?.()?.ui?.route || "/";
      }

      const turnPromise = runTurn(
        agent,
        cm,
        ctx,
        userInput,
        controller.signal,
        agentConfig,
        () => notifyListeners()
      );

      notifyListeners();

      const result = await turnPromise;

      if (result.usage) {
        usage.input += result.usage.input;
        usage.output += result.usage.output;
      }

      if (result.stopReason === "max_iterations") {
        console.warn(`[web-agent] Turn ended: max_iterations exceeded (${currentConfig.maxIterations} steps)`);
      }

      if (result.stopReason === "aborted" || result.stopReason === "error") {
        error = result.error?.message || (result.stopReason === "error" ? "An error occurred during execution." : "Turn aborted.");
        const lastEntry = cm.journal[cm.journal.length - 1];
        if (lastEntry) {
          lastEntry.meta.failed = { message: error, retryable: isRetryableError(result.error) };
        }
      }
    } catch (err: any) {
      const message: string = err.message || String(err);
      error = message;
      const lastEntry = cm.journal[cm.journal.length - 1];
      if (lastEntry) {
        lastEntry.meta.failed = { message, retryable: isRetryableError(err) };
      }
    } finally {
      running = false;
      controller = undefined;
      if (opts?.fullReflush) reflushAll(); else flushTurn();
      notifyListeners();
      await maybeDrainQueue();
    }
  }

  async function send(parts: MessagePart[]): Promise<void> {
    const pointedPart = parts.find(
      (p): p is Extract<MessagePart, { type: "pointed" }> => p.type === "pointed"
    );
    const { text, images } = partsToInput(parts);
    const displayText = text;
    let finalText = text;
    let pointedItems: { role: string; name: string }[] | undefined;
    if (pointedPart && pointedPart.items.length > 0) {
      const snapshots = await ctx.domAdapter.snapshotFocused(
        pointedPart.items.map((it) => it.el)
      );
      const block = buildPointedElementsBlock(snapshots);
      finalText = finalText ? `${finalText}\n\n${block}` : block;
      pointedItems = pointedPart.items.map((it) => ({ role: it.role, name: it.name }));
    }
    if (running) {
      enqueueInput(finalText, images);
      return;
    }
    const userInput: string | UserMessageInput = pointedItems
      ? { text: finalText, images, pointedItems, userDisplayText: displayText }
      : (images.length > 0 ? { text: finalText, images } : finalText);
    await runUserTurn(userInput);
  }

  function reconstructUserInput(msg: any): string | UserMessageInput {
    const content = msg?.content;
    if (typeof content === "string") return content;
    if (Array.isArray(content)) {
      let text = "";
      const images: { dataUrl: string; mediaType: string }[] = [];
      for (const part of content) {
        if (part.type === "text") text += (text ? "\n" : "") + (part.text || "");
        else if (part.type === "image" && typeof part.image === "string")
          images.push({ dataUrl: part.image, mediaType: part.mediaType || "image/jpeg" });
      }
      return images.length > 0 ? { text, images } : text;
    }
    return "";
  }

  async function retryLast(): Promise<void> {
    if (running) return;
    const journal = cm.journal;
    if (journal.length === 0) return;
    const lastTurnId = journal[journal.length - 1].meta.turnId;
    const isFailed = journal.some(e => e.meta.turnId === lastTurnId && e.meta.failed);
    if (!isFailed) return;

    const removed = cm.truncateLastTurn();
    const userEntry = removed.find(e => e.msg.role === "user");
    if (!userEntry) return;
    const userInput = reconstructUserInput(userEntry.msg);

    emitEvent({ type: "retry:start" });
    await runUserTurn(userInput, { fullReflush: true });

    const failedNow = cm.journal.length > 0 &&
      cm.journal[cm.journal.length - 1].meta.failed;
    if (failedNow) emitEvent({ type: "retry:failure", error: failedNow });
    else emitEvent({ type: "retry:success" });
  }

  async function autoTitle(): Promise<void> {
    if (!sessionStore || !activeSessionId) return;
    const transcript = buildTitleTranscript(cm.journal);
    const prompt =
      "Summarize the following conversation as a short UI title of 3-6 words. " +
      "Reply with ONLY the title text, no quotes, no punctuation at the end.\n\n" +
      transcript;

    try {
      const raw = await runBareTurn(prompt, agentConfig, { fetch: agentConfig.fetch });
      const title = (raw || "").trim().replace(/^["']|["']$/g, "").slice(0, 80);
      if (!title) return;
      await sessionStore.saveMeta(activeSessionId, { title, titleManual: false });
      await refreshSessions();
      notifyListeners();
    } catch (err) {
      console.error("[autotitle] generation failed:", err);
    }
  }

  function enqueueInput(text: string, images: ImageAttachment[]): void {
    queuedMessages.push({
      id: crypto.randomUUID(),
      text,
      images: images.length > 0 ? images : undefined,
    });
    notifyListeners();
  }

  async function maybeDrainQueue(): Promise<void> {
    if (error !== undefined) return;
    if (queuedMessages.length === 0) return;

    const items = queuedMessages;
    queuedMessages = [];
    notifyListeners();

    const text = items.map((i) => i.text).filter((t) => t.length > 0).join("\n");
    const images = items.flatMap((i) => i.images ?? []);
    const userInput = images.length > 0 ? { text, images } : text;

    await runUserTurn(userInput);
  }

  function cancelQueued(id: string): void {
    const before = queuedMessages.length;
    queuedMessages = queuedMessages.filter((q) => q.id !== id);
    if (queuedMessages.length !== before) notifyListeners();
  }

  function popLastQueued(): { text: string; images?: ImageAttachment[] } | undefined {
    const item = queuedMessages.pop();
    if (!item) return undefined;
    notifyListeners();
    return { text: item.text, images: item.images };
  }

  function clearQueue(): void {
    if (queuedMessages.length === 0) return;
    queuedMessages = [];
    notifyListeners();
  }

  return {
    getState,
    subscribe(listener) {
      listeners.add(listener);
      listener(getState());
      return () => {
        listeners.delete(listener);
      };
    },
    subscribeEvents(listener) {
      eventListeners.add(listener);
      return () => {
        eventListeners.delete(listener);
      };
    },
    send,
    retryLast,
    abort,
    compact,
    reset,
    createSession,
    switchSession,
    deleteSession,
    clearAllSessions,
    setTitle,
    refreshSessions,
    updateConfig: doUpdateConfig,
    setModel: doSetModel,
    dispose() {
      abort();
      listeners.clear();
      eventListeners.clear();
      const toClose = mcpSessions;
      mcpSessions = [];
      void Promise.allSettled(toClose.map((s) => s.close()));
    },
    initPromise,
    autoTitle,
    cancelQueued,
    popLastQueued,
    clearQueue,
  };
}

export function buildTitleTranscript(journal: JournalEntry[]): string {
  const lines: string[] = [];
  for (const entry of journal) {
    const role = entry.msg?.role;
    if (role !== "user" && role !== "assistant") continue;
    const text = typeof entry.msg.content === "string"
      ? entry.msg.content
      : Array.isArray(entry.msg.content)
        ? entry.msg.content.map((p: any) => p?.text ?? "").join(" ")
        : "";
    if (text.trim()) lines.push(`${role}: ${text.trim()}`);
  }
  return lines.join("\n").slice(0, 1500);
}
