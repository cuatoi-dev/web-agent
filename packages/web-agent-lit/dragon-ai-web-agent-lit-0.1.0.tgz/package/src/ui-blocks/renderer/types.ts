import { html, render } from "../../ui/template.js";
import { RenderableBlock, DataSourceProvider } from "@dragon-ai/web-agent-core";

export interface RenderCtx {
  disabled?: boolean;
  dataSource?: DataSourceProvider;
}

export interface BlockRenderer {
  types: string[];
  render(block: RenderableBlock, ctx: RenderCtx): Node;
  promptSnippet?: string;
}

export class BlockRendererRegistry {
  private renderers = new Map<string, BlockRenderer>();

  constructor(renderers: BlockRenderer[] = []) {
    for (const r of renderers) {
      this.register(r);
    }
  }

  register(renderer: BlockRenderer) {
    for (const type of renderer.types) {
      this.renderers.set(type, renderer);
    }
  }

  render(block: RenderableBlock, ctx: RenderCtx): Node {
    const renderer = this.renderers.get(block.type);
    if (renderer) {
      return renderer.render(block, ctx);
    }

    const container = document.createElement("div");

    if (block.type === "error_card") {
      render(html`
        <style>
          .error-card-renderer {
            background-color: var(--dragon-action-color-error-10opc, #fde8e8);
            border: 1px solid var(--dragon-action-color-error-40opc, #f98080);
            border-radius: 12px;
            padding: 16px;
            color: var(--dragon-text-color, #9b1c1c);
            margin: 12px 0;
            font-family: var(--dragon-font-family, "Public Sans", system-ui, -apple-system, sans-serif);
          }
          .error-card-renderer details {
            margin-top: 8px;
            font-size: 0.85em;
            cursor: pointer;
          }
          .error-card-renderer summary {
            color: var(--dragon-label-color, #771d1d);
            font-weight: 500;
          }
          .error-card-renderer pre {
            background: var(--dragon-background-color-300, #fdf2f2);
            padding: 8px;
            border-radius: 6px;
            overflow-x: auto;
            margin-top: 4px;
            font-family: monospace;
            font-size: 0.9em;
          }
        </style>
        <div class="error-card-renderer">
          <div style="font-weight: bold; margin-bottom: 8px;">⚠️ Error Block</div>
          <div>${block.error}</div>
          <details>
            <summary>View Raw JSON</summary>
            <pre>${block.raw}</pre>
          </details>
        </div>
      `, container);
      return container;
    }

    // Default unknown fallback
    render(html`
      <style>
        .error-card-renderer {
          background-color: var(--dragon-action-color-error-10opc, #fde8e8);
          border: 1px solid var(--dragon-action-color-error-40opc, #f98080);
          border-radius: 12px;
          padding: 16px;
          color: var(--dragon-text-color, #9b1c1c);
          margin: 12px 0;
          font-family: var(--dragon-font-family, "Public Sans", system-ui, -apple-system, sans-serif);
        }
        .error-card-renderer details {
          margin-top: 8px;
          font-size: 0.85em;
          cursor: pointer;
        }
        .error-card-renderer summary {
          color: var(--dragon-label-color, #771d1d);
          font-weight: 500;
        }
        .error-card-renderer pre {
          background: var(--dragon-background-color-300, #fdf2f2);
          padding: 8px;
          border-radius: 6px;
          overflow-x: auto;
          margin-top: 4px;
          font-family: monospace;
          font-size: 0.9em;
        }
      </style>
      <div class="error-card-renderer">
        <div style="font-weight: bold; margin-bottom: 8px;">⚠️ Unknown Block Type</div>
        <div>Unsupported block type: ${(block as any).type}</div>
        <details>
          <summary>View Raw JSON</summary>
          <pre>${JSON.stringify(block, null, 2)}</pre>
        </details>
      </div>
    `, container);
    return container;
  }

  collectPromptSnippets(): string {
    const snippets = new Set<string>();
    const uniqueRenderers = Array.from(new Set(this.renderers.values()));
    for (const r of uniqueRenderers) {
      if (r.promptSnippet) {
        snippets.add(r.promptSnippet);
      }
    }
    return Array.from(snippets).join("\n\n");
  }
}
