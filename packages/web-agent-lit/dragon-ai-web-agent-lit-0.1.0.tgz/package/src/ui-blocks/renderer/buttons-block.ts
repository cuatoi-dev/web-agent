import { Component, injectStyle } from "../../ui/component.js";
import { html } from "../../ui/template.js";
import { registry as uiRegistry } from "../../ui/registry.js";
import { ButtonsBlock } from "@dragon-ai/web-agent-core";

export class AgentButtonsBlock extends Component {
  private _block!: ButtonsBlock;
  private _disabled = false;

  get block() {
    return this._block;
  }
  set block(v) {
    this._block = v;
    this.requestUpdate();
  }

  get disabled() {
    return this._disabled;
  }
  set disabled(v) {
    this._disabled = !!v;
    this.requestUpdate();
  }

  connectedCallback() {
    super.connectedCallback();
    injectStyle("agent-buttons-block-styles", `
      agent-buttons-block {
        display: block;
        margin: 12px 0;
        font-family: var(--dragon-font-family, "Public Sans", system-ui, -apple-system, sans-serif);
      }
      agent-buttons-block .buttons-container {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        padding: 12px;
        border: 1px dashed var(--dragon-border-color, #c4c7c5);
        border-radius: 12px;
        background: var(--dragon-background-color-300, #fafafa);
        transition: all 0.3s ease;
      }
      agent-buttons-block .buttons-container.disabled {
        opacity: 0.5;
        pointer-events: none;
        filter: grayscale(1);
      }
    `);
  }

  private _handleClick(prompt: string) {
    if (this.disabled) return;
    this.dispatchEvent(
      new CustomEvent("block-button", {
        detail: { prompt },
        bubbles: true,
        composed: true,
      })
    );
  }

  template() {
    if (!this.block || !this.block.options) return html``;

    // Limit to max 6 options
    const options = this.block.options.slice(0, 6);

    const containerClass = this.disabled ? "buttons-container disabled" : "buttons-container";

    return html`
      <div class=${containerClass}>
        ${options.map(
          (opt: any) => uiRegistry.button({
            label: opt.label,
            variant: "secondary",
            disabled: this.disabled,
            onPress: () => this._handleClick(opt.prompt)
          })
        )}
      </div>
    `;
  }
}


if (!customElements.get("agent-buttons-block")) {
  customElements.define("agent-buttons-block", AgentButtonsBlock);
}

declare global {
  interface HTMLElementTagNameMap {
    "agent-buttons-block": AgentButtonsBlock;
  }
}
