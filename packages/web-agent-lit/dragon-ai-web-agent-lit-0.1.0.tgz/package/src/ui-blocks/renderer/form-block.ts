import { Component, injectStyle } from "../../ui/component.js";
import { html } from "../../ui/template.js";
import { registry as uiRegistry } from "../../ui/registry.js";
import { FormBlock } from "@dragon-ai/web-agent-core";

export class AgentFormBlock extends Component {
  private _block!: FormBlock;
  private _disabled = false;
  private _values: Record<string, any> = {};

  get block() {
    return this._block;
  }
  set block(v) {
    this._block = v;
    this._resetValues();
    this.requestUpdate();
  }

  get disabled() {
    return this._disabled;
  }
  set disabled(v) {
    this._disabled = !!v;
    this.requestUpdate();
  }

  connectedCallback() {
    super.connectedCallback();
    injectStyle("agent-form-block-styles", `
      agent-form-block {
        display: block;
        margin: 12px 0;
        font-family: var(--dragon-font-family, "Public Sans", system-ui, -apple-system, sans-serif);
      }
      agent-form-block .form-container {
        background: var(--dragon-background-color-300, #ffffff);
        border: 1px solid var(--dragon-border-color, #e0e0e0);
        border-radius: 12px;
        padding: 20px;
        box-shadow: var(--dragon-elevation-s, 0 4px 12px rgba(0, 0, 0, 0.05));
        transition: all 0.3s ease;
      }
      agent-form-block .form-container.disabled {
        opacity: 0.6;
        background: var(--dragon-background-color-500, #fafafa);
        box-shadow: none;
      }
      agent-form-block h3 {
        margin-top: 0;
        margin-bottom: 16px;
        font-size: 1.15em;
        color: var(--dragon-action-color-info, #1a73e8);
        font-weight: 600;
      }
      agent-form-block .field-group {
        margin-bottom: 16px;
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      agent-form-block .field-label {
        font-size: 0.85em;
        font-weight: 500;
        color: var(--dragon-text-color-disabled, var(--dragon-label-color, #5f6368));
      }
      agent-form-block .select-wrapper {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      agent-form-block select {
        padding: 10px 12px;
        border-radius: 8px;
        border: 1px solid var(--dragon-input-border-color, #c4c7c5);
        background-color: var(--dragon-input-background-color, white);
        color: var(--dragon-input-text-color, #202124);
        font-family: inherit;
        font-size: 1em;
        outline: none;
        transition: border-color 0.2s;
      }
      agent-form-block select:focus {
        border-color: var(--dragon-action-color-info, #1a73e8);
      }
      agent-form-block select:disabled {
        background-color: var(--dragon-background-color-500, #f1f3f4);
        color: var(--dragon-text-color-disabled, #9aa0a6);
      }
      agent-form-block .checkbox-wrapper {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 4px 0;
      }
      agent-form-block .submit-row {
        margin-top: 20px;
        display: flex;
        justify-content: flex-end;
      }
    `);
  }

  private _resetValues() {
    this._values = {};
    if (!this.block || !this.block.fields) return;
    for (const field of this.block.fields) {
      if (field.kind === "checkbox") {
        this._values[field.name] = field.default !== undefined ? !!field.default : false;
      } else if (field.kind === "select") {
        this._values[field.name] = field.default !== undefined ? field.default : (field.options?.[0] || "");
      } else {
        this._values[field.name] = "";
      }
    }
  }

  private _handleSubmit(e: Event) {
    e.preventDefault();
    if (this.disabled) return;

    const form = this.querySelector("form");
    if (form && !form.checkValidity()) {
      form.reportValidity();
      return;
    }

    this.dispatchEvent(
      new CustomEvent("block-submit", {
        detail: {
          id: this.block.id,
          values: { ...this._values },
        },
        bubbles: true,
        composed: true,
      })
    );
  }

  template() {
    if (!this.block || !this.block.fields) return html``;

    const containerClass = this.disabled ? "form-container disabled" : "form-container";

    return html`
      <div class=${containerClass}>
        ${this.block.title ? html`<h3>${this.block.title}</h3>` : ""}
        <form @submit=${(e: Event) => this._handleSubmit(e)}>
          ${this.block.fields.map((field: any) => {
            if (field.kind === "text" || field.kind === "number" || field.kind === "date") {
              const wrapper = uiRegistry.textInput({
                value: String(this._values[field.name] ?? ""),
                placeholder: field.placeholder || "",
                disabled: this.disabled,
                onInput: (val) => {
                  if (field.kind === "number") {
                    this._values[field.name] = val !== "" ? Number(val) : null;
                  } else {
                    this._values[field.name] = val;
                  }
                }
              });
              
              const input = wrapper.querySelector("input") || wrapper;
              if (input) {
                input.setAttribute("data-name", field.name);
                if (field.kind === "number") {
                  (input as any).type = "number";
                  if (field.min !== undefined) (input as any).min = String(field.min);
                  if (field.max !== undefined) (input as any).max = String(field.max);
                } else if (field.kind === "date") {
                  (input as any).type = "date";
                }
                if (field.required) {
                  (input as any).required = true;
                }
              }
              return html`
                <div class="field-group">
                  <span class="field-label">${field.label}</span>
                  ${wrapper}
                </div>
              `;
            } else if (field.kind === "select") {
              return html`
                <div class="field-group select-wrapper">
                  <span class="field-label">${field.label}</span>
                  <select
                    data-name=${field.name}
                    ?disabled=${this.disabled}
                    @change=${(e: Event) => {
                      this._values[field.name] = (e.target as HTMLSelectElement).value;
                    }}
                  >
                    ${field.options.map(
                      (opt: any) => html`
                        <option value=${opt} ?selected=${opt === this._values[field.name]}>
                          ${opt}
                        </option>
                      `
                    )}
                  </select>
                </div>
              `;
            } else if (field.kind === "checkbox") {
              const wrapper = uiRegistry.checkbox({
                checked: !!this._values[field.name],
                label: field.label,
                onChange: (checked) => {
                  this._values[field.name] = checked;
                }
              });
              const input = wrapper.querySelector("input, md-checkbox") || wrapper;
              if (input) {
                input.setAttribute("data-name", field.name);
                if (this.disabled) {
                  (input as any).disabled = true;
                }
              }
              return html`
                <div class="field-group checkbox-wrapper">
                  ${wrapper}
                </div>
              `;
            }
            return html``;
          })}
          <div class="submit-row">
            ${(() => {
              const btn = uiRegistry.button({
                label: this.block.submit_label || "Submit",
                variant: "primary",
                disabled: this.disabled,
                onPress: () => {}
              });
              btn.setAttribute("type", "submit");
              return btn;
            })()}
          </div>
        </form>
      </div>
    `;
  }
}

if (!customElements.get("agent-form-block")) {
  customElements.define("agent-form-block", AgentFormBlock);
}

declare global {
  interface HTMLElementTagNameMap {
    "agent-form-block": AgentFormBlock;
  }
}
