import { RenderableBlock } from "@dragon-ai/web-agent-core";
import { BlockRenderer, RenderCtx } from "./types.js";
import "./form-block.js";
import "./buttons-block.js";

export const generativeUiRenderer: BlockRenderer = {
  types: ["form", "buttons"],
  render(block: RenderableBlock, ctx: RenderCtx): Node {
    const disabled = !!ctx.disabled;
    if (block.type === "form") {
      const el = document.createElement("agent-form-block");
      (el as any).block = block;
      (el as any).disabled = disabled;
      return el;
    } else {
      const el = document.createElement("agent-buttons-block");
      (el as any).block = block;
      (el as any).disabled = disabled;
      return el;
    }
  },
  promptSnippet: `
- Form: { "type": "form", "id": string, "title": string (optional), "submit_label": string (optional), "fields": Field[] }
  where Field is one of:
    - { "kind": "text", "name": string, "label": string, "placeholder": string (optional), "required": boolean (optional) }
    - { "kind": "number", "name": string, "label": string, "min": number (optional), "max": number (optional), "required": boolean (optional) }
    - { "kind": "select", "name": string, "label": string, "options": string[], "default": string (optional) }
    - { "kind": "checkbox", "name": string, "label": string, "default": boolean (optional) }
    - { "kind": "date", "name": string, "label": string, "required": boolean (optional) }
- Buttons: { "type": "buttons", "options": { "label": string, "prompt": string }[] (max 6 options, prompt max 500 chars) }
- Use buttons to offer at most 4 likely next steps. Use forms when you need several values from the user at once.
`.trim(),
};
