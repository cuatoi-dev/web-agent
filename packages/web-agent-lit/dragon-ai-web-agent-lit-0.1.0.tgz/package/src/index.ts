export * from "@dragon-ai/web-agent-core";

import "./chat-ui/chat-panel.js";
import "./chat-ui/message-view.js";
import "./chat-ui/context-gauge.js";
import "./ui-blocks/renderer/form-block.js";
import "./ui-blocks/renderer/buttons-block.js";
import "./embed/web-agent-embed.js";

export { AgentChatPanel } from "./chat-ui/chat-panel.js";
export { createConfirmScrim } from "./chat-ui/confirm-scrim.js";
export { AgentMessageView } from "./chat-ui/message-view.js";
export { AgentContextGauge } from "./chat-ui/context-gauge.js";
export type { MessagePart } from "./chat-ui/types.js";
export { renderBlocks, renderBlocksToElement } from "./ui-blocks/renderer/block-renderer.js";
export * from "./ui-blocks/renderer/types.js";
export { generativeUiRenderer } from "./ui-blocks/renderer/generative-ui-renderer.js";

import { generativeUiRenderer } from "./ui-blocks/renderer/generative-ui-renderer.js";
import type { BlockRenderer } from "./ui-blocks/renderer/types.js";
/** Genui (form/buttons) renderers — spread into a host panel's `renderers`,
 *  parallel to charting's `chartingRenderers`. */
export const genuiRenderers: BlockRenderer[] = [generativeUiRenderer];
/** Back-compat alias; existing hosts spread `defaultRenderers`. Task 007 may
 *  migrate hosts to `[...genuiRenderers, ...chartingRenderers]`. */
export const defaultRenderers = genuiRenderers;


// Base UI primitives so downstream packages (e.g. web-agent-charting/lit)
// can author custom block elements without reaching into lit's src.
export { Component, injectStyle } from "./ui/component.js";
export { html, svg, render, nothing } from "./ui/template.js";

export type { UiRegistry } from "./ui/registry-types.js";
export { registry } from "./ui/registry.js";
export { styles } from "./ui/styles.js";

export { agentCursor, getAgentCursor } from "./chat-ui/agent-cursor.js";
export type { AgentCursor } from "./chat-ui/agent-cursor.js";
export { PointerController } from "./chat-ui/pointer-mode.js";
export type { PickedItem } from "./chat-ui/pointer-mode.js";
export { WebAgentBubble } from "./embed/web-agent-embed.js";
