import { Component } from "../ui/component.js";
import { html, nothing, unsafeHTML } from "../ui/template.js";
import { AuditEntry, RenderableBlock, DataSourceProvider, ToolRenderer } from "@dragon-ai/web-agent-core";
import { renderBlocksToElement } from "../ui-blocks/renderer/block-renderer.js";
import { BlockRendererRegistry } from "../ui-blocks/renderer/types.js";
import type { MessagePart } from "./types.js";
import { marked } from "marked";
import DOMPurify from "dompurify";
import { toolStepPhrase } from "./tool-phrases.js";

function sanitize(text: string): string {
  if (!text) return "";
  try {
    const rawHtml = marked.parse(text) as string;
    return DOMPurify.sanitize(rawHtml);
  } catch (err) {
    console.error("Markdown parse/sanitize error", err);
    return text;
  }
}

/** Sanitize a custom tool renderer's SIMPLE-HTML output. Reuses the existing
 *  DOMPurify seam (no new dep) but with a restrictive inline-only allow-list, so
 *  block-level markup (<div>/<p>/<h*>), scripts, and all attributes/handlers are
 *  stripped — text content is preserved. Does NOT run marked (input is HTML). */
export function sanitizeToolHtml(input: string): string {
  if (!input) return "";
  try {
    return DOMPurify.sanitize(input, {
      ALLOWED_TAGS: ["i", "b", "em", "strong"],
      ALLOWED_ATTR: [],
    });
  } catch (err) {
    console.error("Tool renderer sanitize error", err);
    return "";
  }
}

export class AgentMessageView extends Component {
  private _role: "user" | "assistant" | "system" = "user";
  private _html = "";
  private _images: { dataUrl: string; mediaType: string }[] = [];
  private _trace?: AuditEntry[];
  private _blocks: RenderableBlock[] = [];
  private _parts: MessagePart[] = [];
  private _pointedItems: { role: string; name: string }[] = [];
  private _disabled = false;
  private _dataSource?: DataSourceProvider;
  private _registry?: BlockRendererRegistry;
  private _lightboxSrc = "";
  private _lightboxOpen = false;

  get images() { return this._images; }
  set images(val: { dataUrl: string; mediaType: string }[]) {
    this._images = val ?? [];
    this.requestUpdate();
  }

  get role() { return this._role; }
  set role(val: "user" | "assistant" | "system") {
    if (this._role !== val) {
      this._role = val;
      this.requestUpdate();
    }
  }

  private _userAvatar?: string;
  private _agentAvatar?: string;
  private _userName?: string;
  private _agentShortName?: string;

  get userAvatar() { return this._userAvatar; }
  set userAvatar(val: string | undefined) { this._userAvatar = val; this.requestUpdate(); }
  get agentAvatar() { return this._agentAvatar; }
  set agentAvatar(val: string | undefined) { this._agentAvatar = val; this.requestUpdate(); }
  get userName() { return this._userName; }
  set userName(val: string | undefined) { this._userName = val; this.requestUpdate(); }

  get agentShortName() { return this._agentShortName; }
  set agentShortName(val: string | undefined) { this._agentShortName = val; this.requestUpdate(); }

  private _toolRenderers?: Map<string, ToolRenderer>;
  get toolRenderers() { return this._toolRenderers; }
  set toolRenderers(val: Map<string, ToolRenderer> | undefined) {
    this._toolRenderers = val;
    this.requestUpdate();
  }

  private _text = "";

  get text() { return this._text; }
  set text(val: string) {
    if (this._text !== val) {
      this._text = val;
      this._html = sanitize(val);
      const keep = this._parts.filter((p) => p.kind !== "text");
      this._parts = val ? [{ kind: "text", text: val, html: this._html }, ...keep] : [...keep];
      this.requestUpdate();
    }
  }

  get html() { return this._html; }
  set html(val: string) {
    if (this._html !== val) {
      this._html = val;
      const keep = this._parts.filter((p) => p.kind !== "text");
      this._parts = val ? [{ kind: "text", text: "", html: val }, ...keep] : [...keep];
      this.requestUpdate();
    }
  }

  get trace() { return this._trace; }
  set trace(val: AuditEntry[] | undefined) {
    this._trace = val;
    this.requestUpdate();
  }

  get blocks() { return this._blocks; }
  set blocks(val: RenderableBlock[]) {
    this._blocks = val ?? [];
    // Rebuild parts: keep existing text parts, replace the trailing block parts.
    const textParts = this._parts.filter((p) => p.kind === "text");
    this._parts = [
      ...textParts,
      ...(this._blocks).map((b) => ({ kind: "block" as const, block: b })),
    ];
    this.requestUpdate();
  }

  get parts() { return this._parts; }
  set parts(val: MessagePart[] | undefined) {
    // Treat undefined as "leave derived _parts alone" so that the html setter
    // (called earlier in the same property-set batch for a plain-text-only
    // user message) is not clobbered.
    if (val === undefined) return;
    const p = val ?? [];
    this._parts = p;
    // Derive _html and _blocks for backward-compat getters.
    this._html = p
      .filter((x): x is { kind: "text"; text: string; html?: string } => x.kind === "text")
      .map((x) => x.html ?? sanitize(x.text))
      .join("");
    this._text = p
      .filter((x): x is { kind: "text"; text: string; html?: string } => x.kind === "text")
      .map((x) => x.text)
      .join("");
    this._blocks = p
      .filter((x): x is { kind: "block"; block: RenderableBlock } => x.kind === "block")
      .map((x) => x.block);
    this.requestUpdate();
  }

  get pointedItems() { return this._pointedItems; }
  set pointedItems(val: { role: string; name: string }[] | undefined) {
    this._pointedItems = val ?? [];
    this.requestUpdate();
  }

  get disabled() { return this._disabled; }
  set disabled(val: boolean) {
    if (this._disabled !== val) {
      this._disabled = val;
      this.requestUpdate();
    }
  }

  get dataSource() { return this._dataSource; }
  set dataSource(val: DataSourceProvider | undefined) {
    this._dataSource = val;
    this.requestUpdate();
  }

  get registry() { return this._registry; }
  set registry(val: BlockRendererRegistry | undefined) {
    this._registry = val;
    this.requestUpdate();
  }

  static get observedAttributes() {
    return ["role", "html", "disabled"];
  }

  attributeChangedCallback(name: string, oldVal: string | null, newVal: string | null) {
    if (name === "role") {
      this.role = (newVal as any) || "user";
    } else if (name === "html") {
      this.html = newVal || "";
    } else if (name === "disabled") {
      this.disabled = newVal !== null;
    }
  }

  updated() {
    // Render each part into its indexed container.
    for (let i = 0; i < this._parts.length; i++) {
      const part = this._parts[i];
      const el = this.querySelector(`[data-part-idx="${i}"]`) as HTMLElement | null;
      if (!el) continue;
      if (part.kind === "text") {
        const targetHtml = part.html ?? sanitize(part.text);
        if (el.innerHTML !== targetHtml) {
          el.innerHTML = targetHtml || "";
        }
      } else if (part.kind === "block") {
        renderBlocksToElement(el, [part.block], {
          registry: this.registry,
          disabled: this.disabled,
          dataSource: this.dataSource,
        });
      }
    }
  }

  private _openLightbox(src: string) {
    this._lightboxSrc = src;
    this._lightboxOpen = true;
    this.requestUpdate();
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") { this._closeLightbox(); window.removeEventListener("keydown", handler); }
    };
    window.addEventListener("keydown", handler, { once: true });
  }

  private _closeLightbox() {
    this._lightboxOpen = false;
    this.requestUpdate();
  }

  template() {
    const isUser = this.role === "user";
    const isAssistant = this.role === "assistant";
    const isSystem = this.role === "system";

    let containerClass = "message-container";
    if (isUser) containerClass += " user";
    if (isAssistant) containerClass += " assistant";
    if (isSystem) containerClass += " system";

    let rowClass = "message-row";
    if (isUser) rowClass += " user";
    if (isAssistant) rowClass += " assistant";
    if (isSystem) rowClass += " system";

    return html`
      <style>
        agent-message-view {
          display: block;
        }
        agent-message-view .message-row { display: flex; margin: var(--dragon-padding-m, 0.5rem) 0; }
        agent-message-view .message-row.user { justify-content: flex-end; }
        agent-message-view .message-row.assistant { justify-content: stretch; }
        agent-message-view .message-row.system { justify-content: center; }
        agent-message-view .message-container {
          display: flex;
          flex-direction: column;
          max-width: 85%;
          padding: var(--dragon-padding-m, 0.5rem) var(--dragon-padding-l, 0.75rem);  /* 8px 12px */
          border-radius: 0.75rem;   /* 12px */
          font-size: var(--dragon-font-size-m, 0.9375rem);   /* 15px */
          line-height: var(--dragon-line-height-m, 21px);
          font-family: var(--dragon-font-family, "Public Sans", system-ui, -apple-system, sans-serif);
          overflow: hidden;
        }
        agent-message-view .user {
          align-self: auto;
          width: fit-content;
          max-width: 90%;
          margin-left: auto;
          text-align: left;
          background-color: var(--dragon-action-color-info, #e0dbff);
          color: var(--dragon-action-text-color-info, #23005c);
          border-bottom-right-radius: 2px;
        }
        agent-message-view .pointed-chips {
          display: flex; flex-wrap: wrap; gap: 4px;
          margin-bottom: 6px;
        }
        agent-message-view .pointed-chip {
          display: inline-flex; align-items: center;
          background: var(--dragon-white-color-20opc, rgba(255,255,255,0.6)); border: 1px solid var(--dragon-white-color-30opc, rgba(0,0,0,0.12));
          border-radius: 10px; padding: 1px 8px; font-size: 0.72rem;
          color: var(--dragon-action-text-color-info, #23005c);
        }
        agent-message-view .assistant {
          align-self: stretch;
          flex: 1 1 auto;          /* fill the row — max-width:100% alone won't */
          max-width: 100%;
          color: var(--dragon-text-color, #202124);
          background-color: transparent;             /* blend into the themed list bg — no card */
          border: none;                              /* no hairline; assistant is not a bubble */
          border-radius: 0;                          /* no rounded card corners */
          padding: var(--dragon-padding-m, 0.5rem) 0;    /* vertical only; text spans panel width */
        }
        agent-message-view .system {
          align-self: center;
          background-color: var(--dragon-action-color-warn-10opc, #fef7e0);
          color: var(--dragon-text-color, #b06000);
          text-align: center;
          max-width: 90%;
        }
        agent-message-view .content {
          word-break: break-word;
        }
        agent-message-view .content p {
          margin: var(--dragon-padding-s, 0.25rem) 0;   /* 4px */
        }
        agent-message-view .content pre {
          background: var(--dragon-background-color-300, #f0f1f3);   /* one step off the list bg so code reads */
          border: 1px solid var(--dragon-border-color, #e4e6e9);     /* hairline so the block reads even if bg ~ list */
          padding: 6px;
          border-radius: 4px;
          overflow-x: auto;
        }
        /* 005: faint table borders so tabular data reads on the card surface */
        agent-message-view .content table {
          border-collapse: collapse;
          display: block;                 /* let wide tables scroll inside the card */
          overflow-x: auto;
          max-width: 100%;
          margin: var(--dragon-padding-s, 0.25rem) 0;
          font-size: var(--dragon-font-size-m, 0.9375rem);
        }
        agent-message-view .content th,
        agent-message-view .content td {
          border: 1px solid var(--dragon-border-color, #e0e0e0);
          padding: var(--dragon-padding-s, 0.25rem) var(--dragon-padding-m, 0.5rem);  /* 4px 8px */
          text-align: left;
          vertical-align: top;
        }
        agent-message-view .content th {
          background: var(--dragon-background-color-700, #f1f3f4);
          font-weight: 600;
        }
        agent-message-view .content tbody tr:nth-child(even) td {
          background: var(--dragon-background-color-300, #f0f1f3);   /* zebra distinct from the themed list bg */
        }
        agent-message-view .image-strip {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
          margin-top: 6px;
        }
        agent-message-view .msg-thumbnail {
          max-width: 160px;
          max-height: 120px;
          border-radius: 6px;
          object-fit: cover;
          border: 1px solid var(--dragon-border-color, rgba(0,0,0,0.12));
          cursor: zoom-in;
        }
        agent-message-view .img-lightbox {
          display: none;
          position: fixed;
          inset: 0;
          background: var(--dragon-black-color-80opc, rgba(0,0,0,0.8));
          z-index: 99999;
          align-items: center;
          justify-content: center;
          cursor: zoom-out;
        }
        agent-message-view .img-lightbox.open {
          display: flex;
        }
        agent-message-view .img-lightbox img {
          max-width: 92vw;
          max-height: 92vh;
          border-radius: 6px;
          box-shadow: 0 8px 40px var(--dragon-black-color-60opc, rgba(0,0,0,0.6));
          object-fit: contain;
          cursor: default;
        }
        agent-message-view .blocks-container {
          margin-top: 8px;
          width: 100%;
          max-width: 100%;
        }
        agent-message-view .tool-step {
          display: flex;
          align-items: center;
          gap: var(--dragon-padding-s, 0.25rem);              /* 4px, was 6px */
          margin: var(--dragon-padding-s, 0.25rem) 0;         /* 4px */
          padding: var(--dragon-padding-xs, 0.1875rem) var(--dragon-padding-m, 0.5rem);  /* 3px 8px */
          font-size: var(--dragon-font-size-s, 0.75rem);       /* 12px, was 0.78em */
          line-height: var(--dragon-line-height-s, 18px);
          color: var(--dragon-label-color, #80868b);                       /* muted, clearly secondary */
          background: var(--dragon-background-color-300, rgba(0, 0, 0, 0.04));  /* faint recess */
          border-left: 2px solid var(--dragon-border-color, #dadce0);      /* neutral rule, not brand purple */
          border-radius: 4px;
          width: fit-content;
          max-width: 100%;
        }
        agent-message-view .tool-step-icon {
          font-size: 0.9em;
          opacity: 0.8;
        }
        agent-message-view .tool-step-phrase {
          opacity: 0.85;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      </style>
      <div class=${rowClass}>
        <div class=${containerClass}>
        ${isUser && this._pointedItems.length > 0
          ? html`<div class="pointed-chips" role="list" aria-label="Pointed elements">
              ${this._pointedItems.map(
                (it) => html`<span class="pointed-chip" role="listitem">${it.role}: ${it.name || "(no name)"}</span>`
              )}
            </div>`
          : ""}
        ${this._images && this._images.length > 0
          ? html`<div class="image-strip">
              ${this._images.map(
                (img) =>
                  html`<img
                    class="msg-thumbnail"
                    src="${img.dataUrl}"
                    alt="Attached image"
                    loading="lazy"
                    @click=${() => this._openLightbox(img.dataUrl)}
                  />`
              )}
            </div>`
          : ""}
        ${this._lightboxOpen
          ? html`<div
              class="img-lightbox open"
              @click=${() => this._closeLightbox()}
            >
              <img
                src="${this._lightboxSrc}"
                alt="Full-size image"
                @click=${(e: Event) => e.stopPropagation()}
              />
            </div>`
          : ""}
        ${this._parts.length > 0
          ? this._parts.map((part, i) => {
              if (part.kind === "text")
                return html`<div class="content" data-part-idx=${i}></div>`;
              if (part.kind === "block")
                return html`<div class="blocks-container" data-part-idx=${i}></div>`;
              // kind === "tool" — compact inline step row (self-contained, no data-part-idx)
              const a = part.audit;
              // Precedence: custom renderer HTML (defined, call completed, non-empty
              // after sanitize) > 062a friendly phrase > default. In-progress steps
              // (empty outcomeSummary) skip the renderer and use the phrase.
              let customHtml = "";
              if (a && a.outcomeSummary) {
                const renderer = this._toolRenderers?.get(a.name);
                if (renderer) {
                  const rawInput =
                    a.input && typeof a.input === "object"
                      ? (a.input as Record<string, unknown>)
                      : {};
                  try {
                    customHtml = sanitizeToolHtml(renderer(rawInput, a.outcomeSummary));
                  } catch (err) {
                    console.error("Tool renderer error", err);
                    customHtml = "";
                  }
                }
              }
              const phrase = a ? toolStepPhrase(a, this._agentShortName) : "";
              return html`<div class="tool-step" title="${a?.name ?? ""}">
                <span class="tool-step-icon" aria-hidden="true">⚙</span>
                <span class="tool-step-phrase"
                  >${customHtml ? unsafeHTML(customHtml) : phrase}</span
                >
              </div>`;
            })
          : nothing}
        </div>
      </div>
    `;
  }
}

if (!customElements.get("agent-message-view")) {
  customElements.define("agent-message-view", AgentMessageView);
}

declare global {
  interface HTMLElementTagNameMap {
    "agent-message-view": AgentMessageView;
  }
}
