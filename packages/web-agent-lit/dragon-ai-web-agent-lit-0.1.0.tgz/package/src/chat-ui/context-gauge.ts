import { Component } from "../ui/component.js";
import { html } from "../ui/template.js";

export class AgentContextGauge extends Component {
  private _percent = 0;
  private _tokens = 0;
  private _max = 0;
  private _warnAt = 0.75; // autoCompactPercent
  private _disabled = true; // compact unavailable until >= 2 assistant msgs

  get percent() {
    return this._percent;
  }
  set percent(val: number) {
    if (this._percent !== val) {
      this._percent = val;
      this.requestUpdate();
    }
  }

  get tokens() {
    return this._tokens;
  }
  set tokens(val: number) {
    if (this._tokens !== val) {
      this._tokens = val;
      this.requestUpdate();
    }
  }

  get max() {
    return this._max;
  }
  set max(val: number) {
    if (this._max !== val) {
      this._max = val;
      this.requestUpdate();
    }
  }

  get warnAt() {
    return this._warnAt;
  }
  set warnAt(val: number) {
    if (this._warnAt !== val) {
      this._warnAt = val;
      this.requestUpdate();
    }
  }

  get disabled() {
    return this._disabled;
  }
  set disabled(val: boolean) {
    if (this._disabled !== val) {
      this._disabled = val;
      this.requestUpdate();
    }
  }

  static get observedAttributes() {
    return ["percent", "tokens", "max", "warn-at", "warnat"];
  }

  attributeChangedCallback(name: string, oldVal: string | null, newVal: string | null) {
    if (newVal === null) return;
    const num = parseFloat(newVal);
    if (isNaN(num)) return;
    if (name === "percent") {
      this.percent = num;
    } else if (name === "tokens") {
      this.tokens = num;
    } else if (name === "max") {
      this.max = num;
    } else if (name === "warn-at" || name === "warnat") {
      this.warnAt = num;
    }
  }

  template() {
    const r = 7;
    const circumference = 2 * Math.PI * r;
    const strokeDashoffset = circumference - (Math.min(Math.max(this.percent, 0), 1) * circumference);

    // Color logic as we approach warnAt
    let colorClass = "color-green";
    if (this.percent >= this.warnAt) {
      colorClass = "color-red";
    } else if (this.percent >= this.warnAt - 0.15) {
      colorClass = "color-amber";
    }

    const pctText = `${Math.round(this.percent * 100)}%`;
    const tokensText = Math.round(this.tokens).toLocaleString();
    const maxText = this.max.toLocaleString();
    const tooltip = this._disabled
      ? `${pctText} · ${tokensText} / ${maxText} tokens`
      : `Compact conversation — ${pctText} · ${tokensText} / ${maxText} tokens`;
    const emit = () => {
      if (this._disabled) return;
      this.dispatchEvent(new CustomEvent("compact-request", { bubbles: true, composed: true }));
    };

    return html`
      <style>
        agent-context-gauge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 20px;
          height: 20px;
          position: relative;
        }
        agent-context-gauge .gauge-wrapper {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 20px;
          height: 20px;
          cursor: default;
        }
        agent-context-gauge .gauge-wrapper.clickable {
          cursor: pointer;
        }
        agent-context-gauge .gauge-svg {
          transform: rotate(-90deg);
          width: 18px;
          height: 18px;
        }
        agent-context-gauge .bg-circle {
          fill: none;
          stroke: var(--dragon-text-color-disabled, rgba(255, 255, 255, 0.25));
          stroke-width: 3;
        }
        agent-context-gauge .fg-circle {
          fill: none;
          stroke-width: 3;
          stroke-linecap: round;
          transition: stroke-dashoffset 0.3s ease, stroke 0.3s ease;
        }
        agent-context-gauge .color-green {
          stroke: var(--dragon-gauge-green-color, #10b981); /* emerald-500 */
        }
        agent-context-gauge .color-amber {
          stroke: var(--dragon-gauge-orange-color, #f59e0b); /* amber-500 */
        }
        agent-context-gauge .color-red {
          stroke: var(--dragon-gauge-red-color, #ef4444); /* red-500 */
        }
      </style>
      <div
        class=${`gauge-wrapper${this._disabled ? "" : " clickable"}`}
        title=${tooltip}
        role="button"
        aria-disabled=${this._disabled ? "true" : "false"}
        tabindex=${this._disabled ? -1 : 0}
        @click=${emit}
        @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); emit(); } }}
      >
        <svg class="gauge-svg" viewBox="0 0 20 20">
          <circle class="bg-circle" cx="10" cy="10" r=${r}></circle>
          <circle
            class=${`fg-circle ${colorClass}`}
            cx="10"
            cy="10"
            r=${r}
            stroke-dasharray=${circumference}
            stroke-dashoffset=${strokeDashoffset}
          ></circle>
        </svg>
      </div>
    `;
  }
}

if (!customElements.get("agent-context-gauge")) {
  customElements.define("agent-context-gauge", AgentContextGauge);
}

declare global {
  interface HTMLElementTagNameMap {
    "agent-context-gauge": AgentContextGauge;
  }
}
