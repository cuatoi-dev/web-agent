import { Component } from "../ui/component.js";
import { html } from "../ui/template.js";
import { registry as uiRegistry } from "../ui/registry.js";
import {
  createAgentSession,
  type AgentSession,
  type SessionState,
  type SessionMessage,
  type SessionConfig,
  type SessionMeta,
  type AuditEntry,
  type RenderableBlock,
  type ImageAttachment,
  downscaleImage,
  resolveModelLabel,
  SPEED_PRESETS,
  createDataSourceProvider,
  type MessagePart as CoreMessagePart,
  buttonToMessage,
  formSubmitToMessage,
  type ActionCueFn,
  type SessionEvent,
  defaultTools,
  type ToolContext,
  type CustomToolDef,
  type ToolRenderer,
} from "@dragon-ai/web-agent-core";
import "./message-view.js";
import "./context-gauge.js";
import { BlockRenderer, BlockRendererRegistry } from "../ui-blocks/renderer/types.js";
import { generativeUiRenderer } from "../ui-blocks/renderer/generative-ui-renderer.js";
import type { MessagePart } from "./types.js";
import { getAgentCursor } from "./agent-cursor.js";
import { PointerController, type PickedItem } from "./pointer-mode.js";
import { createActionCue } from "./cue-actions.js";
import { createConfirmScrim } from "./confirm-scrim.js";


export class AgentChatPanel extends Component {
  // --- Public properties with getters/setters to trigger updates ---
  private _store: any;
  get store() { return this._store; }
  set store(val: any) {
    this._store = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _appContext: { appName?: string; appDescription?: string; userName?: string; userInfo?: string } = {};
  get appContext() { return this._appContext; }
  set appContext(val: any) {
    this._appContext = val || {};
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _agentName?: string;
  get agentName() { return this._agentName; }
  set agentName(val: string | undefined) { this._agentName = val; this.requestUpdate(); }

  private _agentShortName?: string;
  get agentShortName() { return this._agentShortName; }
  set agentShortName(val: string | undefined) { this._agentShortName = val; this.requestUpdate(); }

  private _userAvatar?: string;
  get userAvatar() { return this._userAvatar; }
  set userAvatar(val: string | undefined) { this._userAvatar = val; this.requestUpdate(); }

  private _agentAvatar?: string;
  get agentAvatar() { return this._agentAvatar; }
  set agentAvatar(val: string | undefined) { this._agentAvatar = val; this.requestUpdate(); }

  private _debug?: boolean;
  get debug() { return this._debug; }
  set debug(val: boolean | undefined) { this._debug = val; this.requestUpdate(); }

  private _confirmInteraction?: (detail: { tool: string; ref: string; name?: string; action: string; reason?: string }) => Promise<boolean>;
  get confirmInteraction() { return this._confirmInteraction; }
  set confirmInteraction(val: any) {
    this._confirmInteraction = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _defaultConfirmInteraction = createConfirmScrim(this);

  private _cues?: any;
  get cues() { return this._cues; }
  set cues(val: any) {
    this._cues = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _onCuesChange?: (cues: { speed: "slow" | "fast"; enabled: boolean }) => void;
  get onCuesChange() { return this._onCuesChange; }
  set onCuesChange(val: ((cues: { speed: "slow" | "fast"; enabled: boolean }) => void) | undefined) {
    this._onCuesChange = val;
  }

  private _path?: string;
  get path() { return this._path; }
  set path(val: string | undefined) {
    this._path = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _model?: string;
  get model() { return this._model; }
  set model(val: string | undefined) {
    this._model = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _type?: "openai" | "anthropic";
  get type() { return this._type; }
  set type(val: "openai" | "anthropic" | undefined) {
    this._type = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _thinking?: boolean;
  get thinking() { return this._thinking; }
  set thinking(val: boolean | undefined) {
    this._thinking = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _images?: { maxDimension?: number; maxBytes?: number; quality?: number };
  get images() { return this._images; }
  set images(val: { maxDimension?: number; maxBytes?: number; quality?: number } | undefined) {
    this._images = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _imageInput?: boolean;
  get imageInput() { return this._imageInput; }
  set imageInput(val: boolean | undefined) {
    this._imageInput = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _models?: import("@dragon-ai/web-agent-core").ModelOption[];
  get models() { return this._models; }
  set models(val: import("@dragon-ai/web-agent-core").ModelOption[] | undefined) {
    this._models = val;
    // No updateConfig(): model list is UI metadata, not a transport rebuild.
    this.requestUpdate();
  }

  private _streaming?: boolean;
  get streaming() { return this._streaming; }
  set streaming(val: boolean | undefined) {
    this._streaming = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _config?: any;
  get config() { return this._config; }
  set config(val: any) {
    this._config = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _renderers: BlockRenderer[] = [generativeUiRenderer];
  get renderers() { return this._renderers; }
  set renderers(val: BlockRenderer[]) {
    this._renderers = val;
    this._cachedRenderers = null;
    this._cachedRegistry = null;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _sources?: any[];
  get sources() { return this._sources; }
  set sources(val: any[] | undefined) {
    this._sources = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _tools?: any[];
  private _toolRenderers?: Map<string, ToolRenderer>;
  get tools() { return this._tools; }
  set tools(val: any[] | undefined) {
    this._tools = val;
    const map = new Map<string, ToolRenderer>();
    for (const t of (val ?? []) as CustomToolDef[]) {
      if (t && typeof t.name === "string" && typeof t.renderer === "function") {
        map.set(t.name, t.renderer);
      }
    }
    this._toolRenderers = map.size > 0 ? map : undefined;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _skills?: any[];
  get skills() { return this._skills; }
  set skills(val: any[] | undefined) {
    this._skills = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _mcpServers?: import("@dragon-ai/web-agent-core").McpServerConfig[];
  get mcpServers() { return this._mcpServers; }
  set mcpServers(val: import("@dragon-ai/web-agent-core").McpServerConfig[] | undefined) {
    this._mcpServers = val;
    this._session?.updateConfig(this.buildSessionConfig());
    this.requestUpdate();
  }

  private _notify?: (msg: string, type: "error" | "info") => void;
  get notify() { return this._notify; }
  set notify(val: any) {
    this._notify = val;
    this.requestUpdate();
  }

  private _cachedRenderers: BlockRenderer[] | null = null;
  private _cachedRegistry: BlockRendererRegistry | null = null;

  get registry(): BlockRendererRegistry {
    const renderers = this.renderers || [];
    if (this._cachedRenderers !== renderers || !this._cachedRegistry) {
      this._cachedRenderers = renderers;
      this._cachedRegistry = new BlockRendererRegistry(renderers);
    }
    return this._cachedRegistry;
  }

  // --- Session integration fields ---
  private _session?: AgentSession;
  private _unsub?: () => void;
  private _eventsUnsub?: () => void;
  private _retryAttempt?: { attempt: number; maxRetries: number };
  private _state?: SessionState;
  private _manualTitle = false;
  private _autoTitledAt = 0;
  private _readOnlyDataSource?: any;
  private _messagesOverride?: any[];

  get retryAttempt() { return this._retryAttempt; }
  set retryAttempt(val: { attempt: number; maxRetries: number } | undefined) {
    this._retryAttempt = val;
    this.requestUpdate();
  }

  /** Demo/gallery-only: pre-fills the composer to show the Send/Stop icon
   *  swap without a live session. Not used by the product UI itself. */
  get composerText() { return ((this._inputEl as any)?.value ?? "") as string; }
  set composerText(val: string) {
    this._ensureElements();
    (this._inputEl as any).value = val;
    this._updateSendButtonState();
  }

  /** Demo/gallery-only: opens the config screen without a user click. */
  get configOpen() { return this._configOpen; }
  set configOpen(val: boolean) {
    this._configOpen = !!val;
    if (this._configOpen) this._debugOpen = false; // mutual exclusion
    this.requestUpdate();
  }

  /** Demo/gallery-only: opens the debug screen without a user click. */
  get debugOpen() { return this._debugOpen; }
  set debugOpen(val: boolean) {
    this._debugOpen = !!val;
    if (this._debugOpen) this._configOpen = false; // mutual exclusion
    this.requestUpdate();
  }

  /** Demo/gallery-only: opens the header kebab menu without a user click. */
  get menuOpen() { return this._menuOpen; }
  set menuOpen(val: boolean) {
    this._menuOpen = !!val;
    this.requestUpdate();
  }

  /** Demo/gallery-only: seeds the chip strip + active toggle without a controller. */
  set pickedChips(v: { role: string; name: string; detached?: boolean }[]) {
    this._pickedItems = (v ?? []).map((c, i) => ({
      id: i, role: c.role, name: c.name, detached: !!c.detached,
    }));
    this._pickMode = true;
    this.requestUpdate();
  }
  get pickMode() { return this._pickMode; }
  set pickMode(v: boolean) { this._pickMode = !!v; this.requestUpdate(); }

  private _subscribeSession(s: AgentSession) {
    if (this._unsub) this._unsub();
    if (this._eventsUnsub) this._eventsUnsub();
    this._unsub = s.subscribe((state) => this._handleStateUpdate(state));
    this._eventsUnsub = s.subscribeEvents?.((e) => this._handleEvent(e));
  }

  get session() { return this._session; }
  set session(s: AgentSession | undefined) {
    if (this._unsub) this._unsub();
    if (this._eventsUnsub) this._eventsUnsub();
    this._session = s;
    if (s) {
      this._subscribeSession(s);
    }
  }

  get messages() {
    return this._messagesOverride ?? this._state?.messages ?? [];
  }
  set messages(val: any[]) {
    this._messagesOverride = val;
    this.requestUpdate();
  }

  get running() {
    return this._state?.running ?? false;
  }
  set running(val: boolean) {}

  get error() {
    return this._state?.error ?? null;
  }
  set error(val: string | null) {
    if (val !== null) {
      if (this._state) {
        this._state.error = val;
      }
    }
    this.requestUpdate();
  }

  get usage() {
    return {
      tokens: this._state?.contextWindow?.used ?? 0,
      max: this._state?.contextWindow?.total ?? 128_000,
      percent: this._state?.contextWindow?.percent ?? 0,
    };
  }
  set usage(val: any) {}

  // --- Cached UI controls from registry to prevent recreation/focus loss ---
  private _elementsCreated = false;
  private _inputEl!: HTMLElement;
  private _sendBtnEl!: HTMLElement;
  private _stopBtnEl!: HTMLElement;
  private _progressEl!: HTMLElement;
  private _workingDotsEl!: HTMLElement | null;
  /** Pending image attachments waiting to be sent. */
  private _pendingImages: ImageAttachment[] = [];
  /** Hidden <input type="file"> used by the attach button. */
  private _fileInputEl!: HTMLInputElement;
  /** Attach button from the registry. */
  private _attachBtnEl!: HTMLElement;
  /** Thumbnail strip container — a plain <div>. */
  private _thumbStripEl!: HTMLDivElement;
  private _pickController?: PointerController;
  private _pickMode = false;
  private _pickedItems: PickedItem[] = [];
  private _pickToggleBtnEl!: HTMLElement;
  /** 016-2: when true, Send does not clear the pinned set afterward. */
  private _keepPinned = false;

  // --- History panel ---
  private _historyPanelOpen = false;
  private _historyBtnEl!: HTMLElement;
  private _newSessionBtnEl!: HTMLElement;
  private _historySessionsList: import("@dragon-ai/web-agent-core").SessionMeta[] | null = null;
  private _historyOutsideHandler?: (e: MouseEvent) => void;
  private _historyKeyHandler?: (e: KeyboardEvent) => void;

  // --- Config screen ---
  private _configOpen = false;

  // --- Debug screen ---
  private _debugOpen = false;
  /** Which debug Copy button is showing "Copied!" feedback, or null. */
  private _debugCopied: "log" | "tools" | null = null;

  // --- Header kebab (config + debug) menu ---
  private _menuOpen = false;
  private _menuBtnEl!: HTMLElement;

  // --- Inline title edit ---
  private _titleEditActive = false;
  private _titleEditBtnEl!: HTMLElement;
  private _titleEditInputEl!: HTMLElement;
  private _titleEditConfirmBtnEl!: HTMLElement;
  private _titleEditCancelBtnEl!: HTMLElement;
  private _retryBtnEl!: HTMLElement;

  // --- Scroll behavior ---
  private _forceScrollToBottom = false;

  private _ensureElements() {
    if (this._elementsCreated) return;
    this._elementsCreated = true;

    this._inputEl = uiRegistry.textInput({
      value: "",
      placeholder: "Ask the assistant...",
      disabled: false,
      onInput: () => {
        this._updateSendButtonState();
        this.requestUpdate();
      },
    });
    this._inputEl.id = "input";

    const nativeInput = this._inputEl.querySelector("input") || this._inputEl;
    nativeInput.addEventListener("keydown", (e) => this._handleKeyDown(e));

    this._sendBtnEl = uiRegistry.iconButton({
      icon: "arrow_upward",
      label: "Send",
      disabled: true,
      onPress: () => this._handleSend(),
    });

    this._stopBtnEl = uiRegistry.iconButton({
      icon: "stop",
      label: "Stop",
      disabled: false,
      onPress: () => this.stop(),
    });


    this._progressEl = uiRegistry.progress({
      indeterminate: true,
    });
    this._workingDotsEl = uiRegistry.workingDots?.() || null;

    // --- attach button (registry seam) ---
    this._attachBtnEl = uiRegistry.iconButton({
      icon: "attach_file",
      label: "Attach image",
      disabled: false,
      onPress: () => this._fileInputEl.click(),
    });

    // --- point-at-element pick toggle (registry seam) ---
    this._pickToggleBtnEl = uiRegistry.iconButton({
      icon: "ads_click",
      label: "Point at elements",
      disabled: false,
      onPress: () => this._togglePickMode(),
    });
    this._pickToggleBtnEl.id = "wa-pick-toggle";

    // --- hidden file picker ---
    this._fileInputEl = document.createElement("input");
    this._fileInputEl.type = "file";
    this._fileInputEl.accept = "image/*";
    this._fileInputEl.multiple = true;
    this._fileInputEl.style.display = "none";
    this._fileInputEl.addEventListener("change", () => this._handleFileInput());

    // --- thumbnail strip ---
    this._thumbStripEl = document.createElement("div");
    this._thumbStripEl.className = "wa-thumb-strip";
    this._thumbStripEl.style.display = "none";

    // --- History icon button (cached for focus preservation) ---
    this._historyBtnEl = uiRegistry.iconButton({
      icon: "history",
      label: "Session history",
      disabled: false,
      onPress: () => this._toggleHistoryPanel(),
    });
    this._historyBtnEl.id = "history-anchor";
    this._historyBtnEl.style.color = "var(--dragon-text-color, white)";

    // --- Kebab (3-dot) menu button: config + (optionally) debug entry point ---
    this._menuBtnEl = uiRegistry.iconButton({
      icon: "more_vert",
      label: "Menu options",
      disabled: false,
      onPress: () => this._toggleMenu(),
    });
    this._menuBtnEl.id = "menu-anchor";
    this._menuBtnEl.style.color = "var(--dragon-text-color, white)";

    // --- New Session icon button ---
    this._newSessionBtnEl = uiRegistry.iconButton({
      icon: "add_comment",
      label: "New session",
      disabled: false,
      onPress: () => this.createSession(),
    });
    this._newSessionBtnEl.style.color = "var(--dragon-text-color, white)";

    // --- Title edit: pencil opener ---
    this._titleEditBtnEl = uiRegistry.iconButton({
      icon: "edit",
      label: "Edit session title",
      disabled: false,
      onPress: () => this._handleTitleEditOpen(),
    });
    this._titleEditBtnEl.style.color = "var(--dragon-text-color, white)";
    (this._titleEditBtnEl as HTMLButtonElement).style.opacity = "0.8";

    // --- Title edit: inline input (cached for focus retention) ---
    this._titleEditInputEl = uiRegistry.textInput({
      value: "",
      placeholder: "Session title…",
      disabled: false,
      onInput: () => {},
    });
    // Keyboard shortcuts for inline title field
    const titleInputNative =
      (this._titleEditInputEl as HTMLElement).querySelector("input") || this._titleEditInputEl;
    (titleInputNative as HTMLElement).addEventListener("keydown", (e) => {
      const ke = e as KeyboardEvent;
      if (ke.key === "Enter") { ke.preventDefault(); this._handleTitleEditConfirm(); }
      if (ke.key === "Escape") { ke.preventDefault(); this._handleTitleEditCancel(); }
    });

    // --- Title edit: Save / Cancel buttons ---
    this._titleEditConfirmBtnEl = uiRegistry.button({
      label: "Save",
      variant: "primary",
      disabled: false,
      onPress: () => this._handleTitleEditConfirm(),
    });
    this._titleEditCancelBtnEl = uiRegistry.button({
      label: "Cancel",
      variant: "secondary",
      disabled: false,
      onPress: () => this._handleTitleEditCancel(),
    });

    this._retryBtnEl = uiRegistry.button({
      label: "Retry",
      variant: "primary",
      disabled: false,
      onPress: () => this._handleRetry(),
    });
  }

  private _hasPinnedItems(): boolean {
    return this._pickedItems.some((it) => !it.detached);
  }

  private _updateSendButtonState() {
    this._ensureElements();
    const val = (this._inputEl as any).value || "";
    const hasContent = val.trim().length > 0 || this._pendingImages.length > 0 || this._hasPinnedItems();
    (this._sendBtnEl as any).disabled = !hasContent;
  }

  /** running + empty composer → Stop; every other case → Send
   *  (not running is always Send, disabled when empty; running + typed
   *  content is Send, enabled — sends/queues via the existing path). */
  private _showStopButton(): boolean {
    const val = (this._inputEl as any).value || "";
    const hasContent = val.trim().length > 0 || this._pendingImages.length > 0 || this._hasPinnedItems();
    return this.running && !hasContent;
  }

  private _ensurePickController(): PointerController {
    if (!this._pickController) {
      this._pickController = new PointerController({
        onChange: () => {
          this._pickedItems = this._pickController!.getPickedItems();
          this._updateSendButtonState();
          this.requestUpdate();
        },
      });
    }
    return this._pickController;
  }

  private _togglePickMode(): void {
    const ctrl = this._ensurePickController();
    this._pickMode = !this._pickMode;
    if (this._pickMode) {
      ctrl.enable();
      document.addEventListener("keydown", this._pickKeyHandler, true);
    } else {
      ctrl.disable();
      document.removeEventListener("keydown", this._pickKeyHandler, true);
    }
    this.requestUpdate();
  }

  private _pickKeyHandler = (e: KeyboardEvent) => {
    if (e.key === "Escape" && this._pickMode) {
      e.preventDefault();
      this._togglePickMode(); // Esc exits pick mode
    }
  };

  static get observedAttributes() {
    return ["path", "model", "type", "thinking"];
  }

  attributeChangedCallback(name: string, oldVal: string | null, newVal: string | null) {
    if (name === "path") {
      this.path = newVal || undefined;
    } else if (name === "model") {
      this.model = newVal || undefined;
    } else if (name === "type") {
      this.type = (newVal as any) || undefined;
    } else if (name === "thinking") {
      this.thinking = newVal !== null;
    }
  }

  connectedCallback() {
    super.connectedCallback();
    this.setAttribute("data-agent-ui", "true");
    this._ensureElements();
    this._ensureSession();
    this._ensureReadOnlyDataSource();

    // Paste handler on the native input element
    const nativeInput = this._inputEl.querySelector("input") || this._inputEl;
    nativeInput.addEventListener("paste", (e) => this._handlePaste(e as ClipboardEvent));

    // Drag-and-drop on the panel itself
    this.addEventListener("dragover", (e) => this._handleDragOver(e as DragEvent));
    this.addEventListener("drop", (e) => this._handleDrop(e as DragEvent));
  }

  disconnectedCallback() {
    this._unsub?.();
    this._unsub = undefined;
    this._eventsUnsub?.();
    this._eventsUnsub = undefined;
    try {
      getAgentCursor().clear();
    } catch {}
    document.removeEventListener("keydown", this._pickKeyHandler, true);
    this._pickController?.dispose();
    this._pickController = undefined;
    this._pickMode = false;
  }

  dispose() {
    this._unsub?.();
    this._unsub = undefined;
    this._eventsUnsub?.();
    this._eventsUnsub = undefined;
    this._session?.dispose();
    this._session = undefined;
    document.removeEventListener("keydown", this._pickKeyHandler, true);
    this._pickController?.dispose();
    this._pickController = undefined;
    this._pickMode = false;
  }

  updated() {
    this._ensureElements();
    this._updateSendButtonState();
    if (this._historyBtnEl)
      (this._historyBtnEl as any).disabled = this.running;
    if (this._newSessionBtnEl)
      (this._newSessionBtnEl as any).disabled = this.running;
    if (this._titleEditBtnEl)
      (this._titleEditBtnEl as any).disabled = this.running;
    if (this._retryBtnEl)
      (this._retryBtnEl as any).disabled = this.running;
    if (this._menuBtnEl)
      (this._menuBtnEl as any).disabled = this.running;
    if (this._pickToggleBtnEl) {
      this._pickToggleBtnEl.setAttribute("aria-pressed", String(this._pickMode));
      this._pickToggleBtnEl.classList.toggle("wa-pick-active", this._pickMode);
    }

    const list = this.querySelector(".messages-list");
    const wasAtBottom = list ? (list.scrollHeight - list.scrollTop - list.clientHeight < 30) : true;

    if (this._forceScrollToBottom || wasAtBottom) {
      this._scrollToBottomQueue();
    }
  }

  buildSessionConfig(): SessionConfig {
    const cuesEnabled = this._cues?.enabled ?? false;
    let actionCue: ActionCueFn | undefined;
    let typingPaceMs: (() => number) | undefined;
    if (cuesEnabled) {
      const speed: "slow" | "fast" = this._cues?.speed === "fast" ? "fast" : "slow";
      actionCue = createActionCue({ getCursor: () => getAgentCursor(), speed: () => speed });
      typingPaceMs = () => SPEED_PRESETS[speed].msPerWord;
    }
    return {
      store: this._store,
      appContext: this._appContext,
      confirmInteraction: this._confirmInteraction ?? this._defaultConfirmInteraction,
      cues: this._cues,
      baseURL: this._path ? this._path : undefined,
      model: this._model,
      endpointType: this._type,
      thinking: this._thinking,
      images: this._images,
      imageInput: this._imageInput,
      streaming: this._streaming,
      models: this._models,
      sources: this._sources,
      tools: (ctx: ToolContext) => [
        ...defaultTools(ctx),
        ...((this._tools ?? []) as CustomToolDef[]),
      ],
      skills: this._skills,
      mcpServers: this._mcpServers,
      actionCue,
      typingPaceMs,
      ...(this._config || {}),
      blockGuidelines: this.registry.collectPromptSnippets(),
    };
  }

  private _handleStateUpdate(s: SessionState) {
    const oldState = this._state;
    this._state = s;

    if (oldState?.running && !s.running) {
      this._retryAttempt = undefined;
      const cuesEnabled = this._cues?.enabled ?? false;
      if (cuesEnabled) {
        try {
          getAgentCursor().clear();
        } catch {}
      }
    }
    
    if (!oldState || oldState.activeSessionId !== s.activeSessionId) {
      this._forceScrollToBottom = true;
      const newMeta = s.sessions.find(x => x.id === s.activeSessionId);
      this._manualTitle = newMeta?.titleManual ?? false;
      const turnCount = s.messages ? s.messages.filter(m => m.role === "assistant").length : 0;
      this._autoTitledAt = turnCount >= 3 ? 3 : turnCount >= 1 ? 1 : 0;
    }

    if (s.messages && !s.running && !this._manualTitle) {
      const turnCount = s.messages.filter(m => m.role === "assistant").length;
      if (turnCount === 1 && this._autoTitledAt < 1) {
        this._autoTitledAt = 1;
        this._session?.autoTitle().catch(() => {});
      } else if (turnCount === 3 && this._autoTitledAt < 3) {
        this._autoTitledAt = 3;
        this._session?.autoTitle().catch(() => {});
      }
    }

    this.requestUpdate();
  }

  private _ensureSession() {
    if (!this._session) {
      this._session = createAgentSession(this.buildSessionConfig());
    }
    if (!this._unsub) {
      this._subscribeSession(this._session);
    }
  }

  private _ensureReadOnlyDataSource() {
    if (this._readOnlyDataSource) return;
    const store = this.store || (typeof window !== "undefined" ? (window as any).__APP_STORE__ : undefined);
    this._readOnlyDataSource = createDataSourceProvider({
      getState: () => store?.getState?.() ?? {},
      sources: this.sources || [],
    });
  }

  async createSession(): Promise<string> {
    this._ensureSession();
    if (!this._session) return "";
    await this._session.createSession();
    return this._state?.activeSessionId || "";
  }

  async switchSession(id: string): Promise<void> {
    this._ensureSession();
    if (!this._session) return;
    await this._session.switchSession(id);
  }

  async deleteSession(id: string): Promise<void> {
    this._ensureSession();
    if (!this._session) return;
    await this._session.deleteSession(id);
  }

  async clearAllSessions(): Promise<void> {
    this._ensureSession();
    if (!this._session) return;
    await this._session.clearAllSessions();
  }

  private _showToast(msg: string, type: "error" | "info") {
    if (this.notify) {
      this.notify(msg, type);
    } else {
      this.dispatchEvent(
        new CustomEvent("agent-toast", {
          detail: { message: msg, type },
          bubbles: true,
          composed: true,
        })
      );
    }
  }

  async send(input: string | {
    text: string;
    images?: { dataUrl: string; mediaType: string }[];
    pointed?: { role: string; name: string; el: Element }[];
  }) {
    this._forceScrollToBottom = true;
    this._ensureSession();
    if (!this._session) return;
    const text = typeof input === "string" ? input : input.text;
    const images = typeof input !== "string" ? input.images : undefined;
    const pointed = typeof input !== "string" ? input.pointed : undefined;

    const parts: CoreMessagePart[] = [];
    if (text) {
      parts.push({ type: "text", text });
    }
    if (images) {
      for (const img of images) {
        parts.push({ type: "image", dataUrl: img.dataUrl, mediaType: img.mediaType });
      }
    }
    if (pointed && pointed.length > 0) {
      parts.push({ type: "pointed", items: pointed });
    }

    this.error = null;
    await this._session.send(parts);
  }

  stop() {
    this._session?.abort();
  }

  async compactSession() {
    this._ensureSession();
    await this._session?.compact();
  }

  // --- History panel lifecycle ---

  private _toggleHistoryPanel(): void {
    if (this._historyPanelOpen) {
      this._closeHistoryPanel();
      return;
    }
    this._historyPanelOpen = true;
    this._refreshHistorySessions();
    this.requestUpdate();
  }

  private _closeHistoryPanel(): void {
    if (this._historyOutsideHandler) {
      document.removeEventListener("click", this._historyOutsideHandler);
      this._historyOutsideHandler = undefined;
    }
    if (this._historyKeyHandler) {
      document.removeEventListener("keydown", this._historyKeyHandler);
      this._historyKeyHandler = undefined;
    }
    this._historyPanelOpen = false;
    this.requestUpdate();
  }

  private _attachHistoryListeners(container: HTMLElement): void {
    // Remove any prior pair first (idempotent — never double-attach)
    if (this._historyOutsideHandler) {
      document.removeEventListener("click", this._historyOutsideHandler);
      this._historyOutsideHandler = undefined;
    }
    if (this._historyKeyHandler) {
      document.removeEventListener("keydown", this._historyKeyHandler);
      this._historyKeyHandler = undefined;
    }
    this._historyOutsideHandler = (e: MouseEvent) => {
      const anchor = document.getElementById("history-anchor");
      const clickedInsideMenu = container.contains(e.target as Node);
      const clickedInsideAnchor = anchor && anchor.contains(e.target as Node);
      if (!clickedInsideMenu && !clickedInsideAnchor) {
        this._closeHistoryPanel();
      }
    };
    this._historyKeyHandler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        this._closeHistoryPanel();
      }
    };
    document.addEventListener("click", this._historyOutsideHandler);
    document.addEventListener("keydown", this._historyKeyHandler);
  }

  private async _refreshHistorySessions(): Promise<void> {
    this._ensureSession();
    if (!this._session) return;
    try {
      await this._session.refreshSessions();
    } catch (e) {
      console.error("[history] refreshSessions failed:", e);
    }
  }

  private _renderHistoryPanelEl(): HTMLElement | null {
    if (!this._historyPanelOpen) return null;

    const container = document.createElement("div");
    container.setAttribute("role", "dialog");
    container.style.cssText = [
      "position:fixed",
      "z-index:10000",
      "background:var(--dragon-dropdown-background-color,#ffffff)",
      "color:var(--dragon-dropdown-item-text-color,#000000)",
      "border:1px solid var(--dragon-dropdown-border-color,#ccc)",
      "border-radius:8px",
      "box-shadow:var(--dragon-dropdown-elevation,0 4px 12px rgba(0,0,0,0.15))",
      "min-width:260px",
      "max-width:320px",
      "padding:8px 0",
    ].join(";");

    // Session list
    const list = document.createElement("div");
    list.style.cssText = "max-height:360px;overflow-y:auto;";

    const sessions = this._state?.sessions || [];
    for (const s of sessions) {
      const row = document.createElement("div");
      row.className = "wa-history-row";
      const isActive = s.id === (this._state?.activeSessionId || "");

      if (isActive) {
        row.setAttribute("aria-current", "true");
        row.style.cssText = [
          "display:flex",
          "align-items:center",
          "padding:8px 12px",
          "cursor:pointer",
          "background:var(--dragon-action-color-info-10opc,#f0e6ff)",
          "font-weight:bold",
        ].join(";");
        row.addEventListener("click", (e) => {
          if ((e.target as HTMLElement).closest("button")) return;
          this._closeHistoryPanel();
        });
      } else {
        row.style.cssText = [
          "display:flex",
          "align-items:center",
          "padding:8px 12px",
          "cursor:pointer",
        ].join(";");
        row.addEventListener("click", (e) => {
          if ((e.target as HTMLElement).closest("button")) return;
          this._handleHistorySwitch(s.id);
        });
      }

      const info = document.createElement("div");
      info.style.cssText = "flex:1;min-width:0;";

      const nameSpan = document.createElement("div");
      nameSpan.textContent = formatSessionLabel(s);
      nameSpan.style.cssText = "font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;";

      const timeSpan = document.createElement("div");
      timeSpan.textContent = formatTimestamp(s.updatedAt);
      timeSpan.style.cssText = "font-size:11px;color:var(--dragon-label-color,#888);margin-top:2px;";

      info.appendChild(nameSpan);
      info.appendChild(timeSpan);
      row.appendChild(info);

      // Delete button
      const delBtn = uiRegistry.iconButton({
        icon: "delete",
        label: `Delete session "${s.title || "untitled"}"`,
        disabled: this.running,
        onPress: () => this._handleHistoryDelete(s.id),
      });
      delBtn.style.color = "var(--dragon-action-color-error, #d93025)";
      row.appendChild(delBtn);

      list.appendChild(row);
    }

    container.appendChild(list);

    // New Session button
    const newBtnWrapper = document.createElement("div");
    newBtnWrapper.style.cssText = "padding:8px 12px;border-top:1px solid var(--dragon-border-color,#eee);";
    const newBtn = uiRegistry.button({
      label: "+ New Session",
      variant: "primary",
      disabled: this.running,
      onPress: () => this._handleHistoryNewSession(),
    });
    newBtn.style.width = "100%";
    newBtnWrapper.appendChild(newBtn);
    container.appendChild(newBtnWrapper);

    // Clear all history (destructive)
    const clearWrapper = document.createElement("div");
    clearWrapper.style.cssText = "padding:0 12px 8px;";
    const clearBtn = uiRegistry.button({
      label: "Clear all history",
      variant: "danger",
      disabled: this.running || (this._state?.sessions?.length ?? 0) === 0,
      onPress: () => this._handleClearAllHistory(),
    });
    clearBtn.style.width = "100%";
    clearWrapper.appendChild(clearBtn);
    container.appendChild(clearWrapper);

    // Attach outside-click + Escape listeners (idempotent) and position in next tick
    setTimeout(() => {
      this._attachHistoryListeners(container);

      // Position near the anchor button
      const anchor = document.getElementById("history-anchor");
      if (anchor) {
        const rect = anchor.getBoundingClientRect();
        const vw = window.innerWidth || document.documentElement.clientWidth;
        const vh = window.innerHeight || document.documentElement.clientHeight;
        let top = rect.bottom;
        let left = rect.left;
        const estW = 280;
        const estH = Math.min(sessions.length * 48 + 50, 410);
        if (left + estW > vw) left = rect.right - estW;
        if (left < 4) left = 4;
        if (top + estH > vh) top = rect.top - estH;
        if (top < 4) top = 4;
        container.style.top = `${top}px`;
        container.style.left = `${left}px`;
      }
    }, 0);

    return container;
  }

  private _handleHistoryDelete(id: string): void {
    if (!confirm("Delete this session?")) return;
    this.deleteSession(id);
  }

  private _handleHistorySwitch(id: string): void {
    if (id === (this._state?.activeSessionId || "")) {
      this._closeHistoryPanel();
      return;
    }
    if (!confirm("Switch to this session?")) return;
    this.switchSession(id);
    this._closeHistoryPanel();
  }

  private _handleHistoryNewSession(): void {
    this.createSession();
    this._closeHistoryPanel();
  }

  private _handleClearAllHistory(): void {
    if (!confirm("Clear ALL history? This permanently deletes every saved session and cannot be undone.")) return;
    this.clearAllSessions();
    this._closeHistoryPanel();
  }

  // --- Config screen ---

  /** Current cue values with defaults for the config controls. */
  private _currentCues(): { enabled: boolean; speed: "slow" | "fast" } {
    return {
      enabled: this._cues?.enabled ?? false,
      speed: this._cues?.speed === "fast" ? "fast" : "slow",
    };
  }

  private _toggleConfig(): void {
    this._configOpen = !this._configOpen;
    if (this._configOpen) this._debugOpen = false;
    this.requestUpdate();
  }

  private _toggleMenu(): void {
    this._menuOpen = !this._menuOpen;
    this.requestUpdate();
  }

  /** Mutates the live in-memory cues, re-derives the session config, and
   *  notifies the host. Clears the cursor when the cue is turned off. */
  private _applyCues(next: { enabled: boolean; speed: "slow" | "fast" }): void {
    const wasEnabled = this._cues?.enabled ?? false;
    // Reuse the existing `cues` setter (updates session config + requests update).
    this.cues = { ...(this._cues ?? {}), enabled: next.enabled, speed: next.speed };
    if (wasEnabled && !next.enabled) {
      try { getAgentCursor().clear(); } catch {}
    }
    this._onCuesChange?.({ speed: next.speed, enabled: next.enabled });
  }

  private _setCueEnabled(enabled: boolean): void {
    this._applyCues({ ...this._currentCues(), enabled });
  }

  private _setCueSpeed(speed: "slow" | "fast"): void {
    this._applyCues({ ...this._currentCues(), speed });
  }

  private _renderConfigView() {
    const cur = this._currentCues();

    const back = uiRegistry.iconButton({
      icon: "arrow_back",
      label: "Back to chat",
      disabled: false,
      onPress: () => this._toggleConfig(),
    });

    const slowBtn = uiRegistry.button({
      label: "Slow",
      variant: cur.speed === "slow" ? "primary" : "secondary",
      disabled: !cur.enabled,
      onPress: () => this._setCueSpeed("slow"),
    });
    const fastBtn = uiRegistry.button({
      label: "Fast",
      variant: cur.speed === "fast" ? "primary" : "secondary",
      disabled: !cur.enabled,
      onPress: () => this._setCueSpeed("fast"),
    });

    const enableToggle = uiRegistry.checkbox({
      checked: cur.enabled,
      label: "Show the agent cursor while it works",
      onChange: (c: boolean) => this._setCueEnabled(c),
    });

    return html`
      <div class="wa-config-view" role="region" aria-label="Settings">
        <div class="wa-config-header">
          ${back}
          <span class="wa-config-title">Settings</span>
        </div>
        <div class="wa-config-section">
          <div class="wa-config-section-title">Visual cue</div>
          <div class="wa-config-row">${enableToggle}</div>
          <div class="wa-config-row">
            <span class="wa-config-label">Speed</span>
            <div class="wa-config-seg">${slowBtn}${fastBtn}</div>
          </div>
        </div>
      </div>
    `;
  }

  private _toggleDebug(): void {
    this._debugOpen = !this._debugOpen;
    if (this._debugOpen) this._configOpen = false;
    this.requestUpdate();
  }

  /** Read-only list of {name, description} for the tools available this turn. */
  private _availableTools(): { name: string; description: string }[] {
    try {
      const factory = this.buildSessionConfig().tools;
      const defs = factory
        ? factory({ imageInput: this._imageInput } as any /* ToolContext: only imageInput is read */)
        : [];
      return defs.map((d: any) => ({ name: d.name, description: d.description }));
    } catch {
      return [];
    }
  }

  /** Full raw debug log: config JSON header + every message/turn + tool calls. */
  private _serializeDebugLog(cfg: Record<string, unknown>): string {
    const lines: string[] = [];
    lines.push("=== Host / agent config ===");
    lines.push(JSON.stringify(cfg, null, 2));
    lines.push("");
    lines.push("=== Conversation ===");
    const msgs = this.messages;
    if (msgs.length === 0) {
      lines.push("(no conversation yet)");
    } else {
      for (const m of msgs) {
        const text =
          (m.text as string | undefined) ??
          ((m.parts as any[] | undefined) || [])
            .filter((p) => p.kind === "text")
            .map((p) => p.text)
            .join(" ");
        lines.push(`[${m.role}] ${text ?? ""}`.trimEnd());
        for (const entry of (m.trace as AuditEntry[] | undefined) || []) {
          lines.push(`  → ${entry.name}`);
          lines.push(`    input: ${JSON.stringify(entry.input)}`);
          lines.push(`    outcome: ${entry.outcomeSummary}`);
        }
      }
    }
    return lines.join("\n");
  }

  /** Available tools as plain copyable text: name then indented description. */
  private _serializeToolsList(tools: { name: string; description: string }[]): string {
    if (tools.length === 0) return "No tools.";
    return tools.map((t) => `${t.name}\n  ${t.description}`).join("\n\n");
  }

  private _copyDebug(which: "log" | "tools", value: string): void {
    const done = () => {
      this._debugCopied = which;
      this.requestUpdate();
      setTimeout(() => {
        if (this._debugCopied === which) {
          this._debugCopied = null;
          this.requestUpdate();
        }
      }, 1200);
    };
    try {
      const p = navigator.clipboard?.writeText(value);
      if (p && typeof p.then === "function") {
        p.then(done).catch((err: unknown) =>
          console.warn("[debug] clipboard write failed:", err),
        );
      } else {
        // No clipboard API (insecure context / test env) — still give feedback.
        done();
      }
    } catch (err) {
      console.warn("[debug] clipboard write failed:", err);
    }
  }

  private _renderDebugView() {
    const back = uiRegistry.iconButton({
      icon: "arrow_back",
      label: "Back to chat",
      disabled: false,
      onPress: () => this._toggleDebug(),
    });
    const tools = this._availableTools();
    const cfg = {
      appName: this.appContext?.appName,
      appDescription: this.appContext?.appDescription,
      userName: this.appContext?.userName,
      userInfo: this.appContext?.userInfo,
      agentName: this._agentName,
      agentShortName: this._agentShortName,
      userAvatar: this._userAvatar ? "(set)" : "(none)",
      agentAvatar: this._agentAvatar ? "(set)" : "(none)",
      debug: this._debug === true,
      persist: this.config?.persist !== false,
      model: this._model,
      type: this._type,
      path: this._path,
    };
    const logText = this._serializeDebugLog(cfg);
    const toolsText = this._serializeToolsList(tools);

    const copyLogBtn = uiRegistry.button({
      label: this._debugCopied === "log" ? "Copied!" : "Copy",
      variant: "secondary",
      onPress: () => this._copyDebug("log", logText),
    });
    const copyToolsBtn = uiRegistry.button({
      label: this._debugCopied === "tools" ? "Copied!" : "Copy",
      variant: "secondary",
      onPress: () => this._copyDebug("tools", toolsText),
    });

    return html`
      <div class="wa-debug-view" role="region" aria-label="Debug">
        <div class="wa-config-header">
          ${back}
          <span class="wa-config-title">Debug</span>
        </div>
        <div class="wa-config-section wa-debug-section">
          <div class="wa-config-section-title">Raw conversation &amp; tool calls</div>
          <textarea
            class="wa-debug-ta"
            readonly
            aria-label="Raw conversation and tool calls"
            .value=${logText}
          ></textarea>
          <div class="wa-debug-copy-row">${copyLogBtn}</div>
        </div>
        <div class="wa-config-section wa-debug-section">
          <div class="wa-config-section-title">Available tools (${tools.length})</div>
          <textarea
            class="wa-debug-ta"
            readonly
            aria-label="Available tools"
            .value=${toolsText}
          ></textarea>
          <div class="wa-debug-copy-row">${copyToolsBtn}</div>
        </div>
      </div>
    `;
  }

  // --- Inline title edit ---

  private _handleTitleEditOpen(): void {
    this._titleEditActive = true;
    const currentMeta = this._state?.sessions.find(s => s.id === this._state?.activeSessionId);
    (this._titleEditInputEl as any).value = currentMeta?.title || "";
    this.requestUpdate();
  }

  private _handleTitleEditConfirm(): void {
    const val = ((this._titleEditInputEl as any).value || "").trim();
    this._titleEditActive = false;
    if (!val) {
      this.requestUpdate();
      return;
    }
    if (this._session && this._state?.activeSessionId) {
      this._session.setTitle(this._state.activeSessionId, val)
        .catch(err => console.error("[title] setTitle failed:", err));
      this._manualTitle = true;
    }
    this.requestUpdate();
  }

  private _handleTitleEditCancel(): void {
    this._titleEditActive = false;
    this.requestUpdate();
  }

  private _handleKeyDown(e: KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      this._handleSend();
    }
  }

  private _handleSend() {
    this._ensureElements();
    const val = ((this._inputEl as any).value || "") as string;
    const hasImages = this._pendingImages.length > 0;
    const pointed = this._resolvePinnedForSend();
    if (!val.trim() && !hasImages && pointed.length === 0) return;
    const images = [...this._pendingImages];
    (this._inputEl as any).value = "";
    this._clearPendingImages();
    this.send({ text: val, images, pointed });
    if (!this._keepPinned) this._pickController?.clear();
  }

  /** 016-2: live, non-detached pinned elements resolved for send-time
   *  focused-snapshot assembly. Filters out anything that resolves to
   *  undefined (detached/removed between chip render and Send). */
  private _resolvePinnedForSend(): { role: string; name: string; el: Element }[] {
    if (!this._pickController) return [];
    const out: { role: string; name: string; el: Element }[] = [];
    for (const it of this._pickedItems) {
      if (it.detached) continue;
      const el = this._pickController.resolveElement(it.id);
      if (el) out.push({ role: it.role, name: it.name, el });
    }
    return out;
  }

  private _handleEditQueued() {
    const item = this._session?.popLastQueued();
    if (!item) return;
    this._ensureElements();
    (this._inputEl as any).value = item.text;
    this._pendingImages = item.images ? [...item.images] : [];
    this._renderThumbStrip();
    this._updateSendButtonState();
    this.requestUpdate();
    const nativeInput = this._inputEl.querySelector("input") || this._inputEl;
    (nativeInput as HTMLElement).focus();
  }

  private _renderQueueList() {
    const queued = this._state?.queuedMessages ?? [];
    if (queued.length === 0) return "";
    return html`
      <div class="wa-queue-list">
        ${queued.map((q, idx) => {
          const isLast = idx === queued.length - 1;
          const cancelBtn = uiRegistry.iconButton({
            icon: "close",
            label: "Cancel queued message",
            onPress: () => this._session?.cancelQueued(q.id),
          });
          const editBtn = isLast
            ? uiRegistry.iconButton({
                icon: "edit",
                label: "Edit queued message",
                onPress: () => this._handleEditQueued(),
              })
            : "";
          return html`
            <div class="wa-queue-item">
              <span class="wa-queue-text">${q.text}</span>
              <div class="wa-queue-actions">${editBtn}${cancelBtn}</div>
            </div>
          `;
        })}
      </div>
    `;
  }

  private _renderPickChips() {
    if (this._pickedItems.length === 0) return "";
    const cap = this._pickController?.atCap() ?? false;
    const keepPinnedToggle = uiRegistry.checkbox({
      checked: this._keepPinned,
      label: "Keep pinned after send",
      onChange: (c: boolean) => { this._keepPinned = c; this.requestUpdate(); },
    });
    return html`
      <div class="wa-pick-chips" role="list" aria-label="Pinned elements">
        ${this._pickedItems.map((it, idx) => {
          const removeBtn = uiRegistry.iconButton({
            icon: "close",
            label: `Unpin ${it.role} ${it.name}`,
            onPress: () => this._pickController?.unpin(it.id),
          });
          return html`
            <span
              class="wa-pick-chip${it.detached ? " wa-pick-chip--detached" : ""}"
              role="listitem"
              @mouseenter=${() => !it.detached && this._pickController?.reveal(it.id)}
              @click=${() => !it.detached && this._pickController?.reveal(it.id)}
            >
              <span class="wa-pick-chip-num">${idx + 1}</span>
              <span class="wa-pick-chip-label">${it.role}: ${it.name || "(no name)"}</span>
              ${removeBtn}
            </span>`;
        })}
        ${cap ? html`<span class="wa-pick-hint">Max ${this._pickController?.maxItems ?? 8} — unpin one to add more.</span>` : ""}
      </div>
      <div class="wa-pick-keep-row">${keepPinnedToggle}</div>`;
  }

  private _clearPendingImages() {
    this._pendingImages = [];
    this._fileInputEl.value = "";
    this._renderThumbStrip();
    this._updateSendButtonState();
    this.requestUpdate();
  }

  private _handleFileInput() {
    const files = Array.from(this._fileInputEl.files || []);
    this._ingestFiles(files);
  }

  private async _ingestFiles(files: File[]) {
    const limits = this.images ?? {};
    for (const file of files) {
      if (!file.type.startsWith("image/")) continue;
      try {
        const rawDataUrl = await this._readFileAsDataUrl(file);
        const scaled = await downscaleImage(rawDataUrl, limits);
        const originalBytes = (rawDataUrl.length - rawDataUrl.indexOf(",") - 1) * 0.75;
        const scaledBytes  = (scaled.length  - scaled.indexOf(",") - 1) * 0.75;
        if (scaledBytes < originalBytes * 0.99) {
          this._showToast("Image resized to fit size limits", "info");
        }
        this._pendingImages.push({ dataUrl: scaled, mediaType: "image/jpeg" });
      } catch (err) {
        this._showToast(`Image rejected: ${(err as Error).message || err}`, "error");
      }
    }
    this._renderThumbStrip();
    this._updateSendButtonState();
    this.requestUpdate();
  }

  private _readFileAsDataUrl(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  private _renderThumbStrip() {
    const strip = this._thumbStripEl;
    strip.innerHTML = "";
    if (this._pendingImages.length === 0) {
      strip.style.display = "none";
      return;
    }
    strip.style.display = "flex";
    this._pendingImages.forEach((img, idx) => {
      const wrap = document.createElement("div");
      wrap.className = "wa-thumb-wrap";
      wrap.style.cssText = "position:relative; width:56px; height:56px;";

      const imgEl = document.createElement("img");
      imgEl.src = img.dataUrl;
      imgEl.alt = `Attachment ${idx + 1}`;
      imgEl.style.cssText =
        "width:56px; height:56px; object-fit:cover; border-radius:6px;" +
        " border:1px solid var(--dragon-border-color, #ddd);";

      const removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.setAttribute("aria-label", `Remove attachment ${idx + 1}`);
      removeBtn.textContent = "×";
      removeBtn.style.cssText =
        "position:absolute; top:-6px; right:-6px; width:18px; height:18px;" +
        " border-radius:50%; border:none; background:var(--dragon-background-color-900, #444);" +
        " color:var(--dragon-text-color, #fff);" +
        " font-size:12px; line-height:1; cursor:pointer; padding:0;" +
        " display:flex; align-items:center; justify-content:center;";
      removeBtn.addEventListener("click", () => {
        this._pendingImages.splice(idx, 1);
        this._renderThumbStrip();
        this._updateSendButtonState();
        this.requestUpdate();
      });

      wrap.appendChild(imgEl);
      wrap.appendChild(removeBtn);
      strip.appendChild(wrap);
    });
  }

  private _handlePaste(e: ClipboardEvent) {
    if (this._imageInput === false) return;
    if (!e.clipboardData) return;
    const imageFiles: File[] = [];
    for (const item of Array.from(e.clipboardData.items)) {
      if (item.kind === "file" && item.type.startsWith("image/")) {
        const f = item.getAsFile();
        if (f) imageFiles.push(f);
      }
    }
    if (imageFiles.length > 0) {
      e.preventDefault();
      this._ingestFiles(imageFiles);
    }
  }

  private _handleDragOver(e: DragEvent) {
    if (this._imageInput === false) return;
    if (!e.dataTransfer) return;
    const hasImage = Array.from(e.dataTransfer.items).some(
      (it) => it.kind === "file" && it.type.startsWith("image/")
    );
    if (hasImage) {
      e.preventDefault();
      e.dataTransfer.dropEffect = "copy";
    }
  }

  private _handleDrop(e: DragEvent) {
    if (this._imageInput === false) return;
    if (!e.dataTransfer) return;
    const files = Array.from(e.dataTransfer.files).filter((f) =>
      f.type.startsWith("image/")
    );
    if (files.length > 0) {
      e.preventDefault();
      this._ingestFiles(files);
    }
  }

  private _handleBlockButton(e: CustomEvent<{ prompt: string }>) {
    if (this.running) return;
    const msg = buttonToMessage(e.detail.prompt);
    this.send(msg);
  }

  private _handleBlockSubmit(
    e: CustomEvent<{ id: string; values: Record<string, unknown> }>,
  ) {
    if (this.running) return;
    const msg = formSubmitToMessage(e.detail.id, e.detail.values);
    this.send(msg);
  }

  private _handleEvent(e: SessionEvent) {
    if (e.type === "auto-retry:attempt") {
      this._retryAttempt = { attempt: e.attempt, maxRetries: e.maxRetries };
      this.requestUpdate();
    } else if (e.type === "retry:success" || e.type === "retry:failure") {
      this._retryAttempt = undefined;
      this.requestUpdate();
    }
  }

  private _handleRetry() {
    if (this.running) return;
    this._forceScrollToBottom = true;
    this._session?.retryLast?.();
  }

  private _lastFailed() {
    const m = [...this.messages].reverse().find(x => x.failed);
    return m?.failed;
  }

  private _renderFailedTurnAffordance() {
    if (this._retryAttempt && this.running) {
      return html`<div class="wa-retrying" role="status">Retrying… (${this._retryAttempt.attempt} of ${this._retryAttempt.maxRetries})</div>`;
    }
    const failed = this._lastFailed();
    if (failed) {
      this._ensureElements();
      (this._retryBtnEl as any).disabled = this.running;
      return html`<div class="wa-failed-card" role="alert"><span class="wa-failed-msg">${failed.message}</span>${this._retryBtnEl}</div>`;
    }
    return "";
  }

  private _clearError() {
    this.error = null;
  }

  private async _scrollToBottomQueue() {
    this._forceScrollToBottom = false;
    await this.updateComplete;

    const views = this.querySelectorAll("agent-message-view");
    await Promise.all(Array.from(views).map(v => (v as any).updateComplete));

    const list = this.querySelector(".messages-list");
    if (list) {
      list.scrollTop = list.scrollHeight;
    }
  }

  template() {
    const activeSession = this._state?.sessions.find(
      (s) => s.id === this._state?.activeSessionId
    );
    const headerTitle = activeSession?.title?.trim()
      ? activeSession.title
      : (this._agentName?.trim()
        ? this._agentName
        : (this.appContext?.appName
          ? `🤖 ${this.appContext.appName} Assistant`
          : "🤖 Assistant"));

    return html`
      <style>
        agent-chat-panel {
          display: flex;
          flex-direction: column;
          position: fixed;
          bottom: 20px;
          right: 20px;
          width: 400px;
          height: 600px;
          background: var(--dragon-background-color, white);
          border-radius: 12px;
          box-shadow: var(--dragon-elevation-l, 0 5px 40px rgba(0, 0, 0, 0.16));
          overflow: hidden;
          z-index: 9999;
          border: 1px solid var(--dragon-border-color, #e0e0e0);
          color: var(--dragon-text-color, inherit);
          font-family: var(--dragon-font-family, "Public Sans", system-ui, -apple-system, sans-serif);
        }
        @media (max-width: 600px) {
          agent-chat-panel {
            position: relative;
            /* reset the desktop fixed-float insets so the full-width relative
               panel is not shifted off-screen: under position:relative a stale
               right:20px computes to left:-20px and clips the left edge. */
            inset: auto;
            width: 100%;
            height: 500px;
            max-height: 80vh;
            border-radius: 0;
            box-shadow: none;
            border-left: none;
            border-right: none;
          }
          agent-chat-panel .header {
            padding: var(--dragon-padding-m, 0.5rem);   /* 8px */
          }
          agent-chat-panel .header-title {
            font-size: 0.9em;
          }
          agent-chat-panel .input-area {
            padding: var(--dragon-padding-m, 0.5rem);   /* 8px */
          }
        }
        agent-chat-panel .input-area #input {
          flex: 1;
          min-width: 0;
        }
        agent-chat-panel .header {
          background: var(--dragon-background-color-900, #6200ee);
          color: var(--dragon-text-color, white);
          padding: var(--dragon-padding-m, 0.5rem) var(--dragon-padding-l, 0.75rem);   /* was 12px 16px */
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-weight: bold;
        }
        agent-chat-panel .header-title {
          font-size: var(--dragon-font-size-l, 1rem);   /* was 1.1em */
          display: flex;
          align-items: center;
          gap: var(--dragon-padding-s, 0.25rem);                    /* 4px, was 6px */
        }
        agent-chat-panel .messages-list {
          flex: 1;
          overflow-y: auto;
          overflow-x: hidden;
          padding: var(--dragon-padding-l, 0.75rem);   /* 12px, was 16px */
          background: var(--dragon-background-color, #fafafa);
        }
        agent-chat-panel .input-area {
          display: flex;
          align-items: center;
          padding: var(--dragon-padding-l, 0.5rem);   /* 8px, was 12px */
          gap: var(--dragon-padding-m, 0.5rem);        /* 8px */
          background: var(--dragon-background-color-700, white);
          border-top: 1px solid var(--dragon-border-color, #f0f0f0);
        }
        agent-chat-panel .input-area .field {
          flex: 1;
          margin: 0;
        }
        agent-chat-panel .error-region {
          background: var(--dragon-action-color-error-10opc, #fde8e8);
          color: var(--dragon-text-color, #9b1c1c);
          padding: 8px 12px;
          font-size: 0.85em;
          border-top: 1px solid var(--dragon-action-color-error-40opc, #fbd5d5);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        agent-chat-panel .error-close {
          cursor: pointer;
          font-weight: bold;
          opacity: 0.7;
        }
        agent-chat-panel .error-close:hover {
          opacity: 1;
        }

        agent-chat-panel .wa-thumb-strip {
          background: var(--dragon-background-color-700, white);
          border-top: 1px solid var(--dragon-border-color, #f0f0f0);
        }
        agent-chat-panel .wa-pick-chips {
          display: flex; flex-wrap: wrap; gap: var(--dragon-padding-s, 0.25rem);
          padding: var(--dragon-padding-m, 0.5rem) var(--dragon-padding-l, 0.75rem);
          background: var(--dragon-background-color-300, #f5f0ff);
          border-top: 1px solid var(--dragon-border-color, #f0f0f0);
        }
        agent-chat-panel .wa-pick-chip {
          display: inline-flex; align-items: center; gap: var(--dragon-padding-s, 0.25rem);
          background: var(--dragon-background-color-50, #fff); border: 1px solid var(--dragon-border-color, #e0e0e0);
          border-radius: 14px; padding: 2px 2px 2px 6px; font-size: 0.8em;
          cursor: pointer; max-width: 100%;
        }
        agent-chat-panel .wa-pick-chip--detached { opacity: 0.5; cursor: default; }
        agent-chat-panel .wa-pick-chip-num {
          display:inline-flex; align-items:center; justify-content:center;
          min-width:16px; height:16px; border-radius:8px;
          background: var(--dragon-action-color-info, #6750A4); color:var(--dragon-action-text-color-info,#fff); font-size:0.7rem;
        }
        agent-chat-panel .wa-pick-chip-label {
          overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:180px;
        }
        agent-chat-panel .wa-pick-chip button { width:24px; height:24px; }
        agent-chat-panel .wa-pick-chip button svg { width:14px; height:14px; }
        agent-chat-panel .wa-pick-hint { font-size:0.75rem; color:var(--dragon-label-color,#888); align-self:center; }
        agent-chat-panel .wa-pick-keep-row {
          display: flex; align-items: center; gap: var(--dragon-padding-s, 0.25rem);
          padding: 0 var(--dragon-padding-l, 0.75rem) var(--dragon-padding-s, 0.25rem);
          background: var(--dragon-background-color-300, #f5f0ff);
          font-size: 0.75rem; color: var(--dragon-label-color, #666);
        }
        agent-chat-panel #wa-pick-toggle.wa-pick-active {
          color: var(--dragon-action-color-info, #6750A4);
          background: var(--dragon-action-color-info-10opc, rgba(103,80,164,0.12));
        }
        agent-chat-panel .wa-thumb-wrap img:hover {
          opacity: 0.85;
        }
        agent-chat-panel .wa-title-edit-row {
          flex: 1;
          min-width: 0;
          display: flex;
          align-items: center;
          gap: 4px;
        }
        agent-chat-panel .wa-history-row:hover {
          background: var(--dragon-dropdown-item-background-color-hover, #f5f5f5);
        }
        agent-chat-panel .wa-history-row[aria-current="true"]:hover {
          background: var(--dragon-action-color-info-20opc, #e8d5ff);
        }
        agent-chat-panel .wa-failed-card {
          background: var(--dragon-action-color-error-10opc, #fde8e8);
          color: var(--dragon-action-color-error, #9b1c1c);
          border: 1px solid var(--dragon-action-color-error-40opc, #fbd5d5);
          border-radius: 8px; padding: var(--dragon-padding-m, 0.5rem) var(--dragon-padding-l, 0.75rem); margin: var(--dragon-padding-m, 0.5rem) 0;
          display: flex; align-items: center; justify-content: space-between; gap: var(--dragon-padding-m, 0.5rem);
          font-size: 0.85em;
        }
        agent-chat-panel .wa-failed-msg { flex: 1; min-width: 0; word-break: break-word; }
        agent-chat-panel .wa-retrying {
          color: var(--dragon-label-color, #666); font-size: 0.85em;
          font-style: italic; padding: var(--dragon-padding-m, 0.5rem) var(--dragon-padding-l, 0.75rem); margin: var(--dragon-padding-s, 0.25rem) 0;
        }
        agent-chat-panel .wa-queue-list {
          display: flex;
          flex-direction: column;
          gap: var(--dragon-padding-s, 0.25rem);
          padding: var(--dragon-padding-m, 0.5rem) var(--dragon-padding-l, 0.75rem);
          background: var(--dragon-background-color-300, #f5f0ff);
          border-top: 1px solid var(--dragon-border-color, #f0f0f0);
        }
        agent-chat-panel .wa-queue-item {
          display: flex;
          align-items: center;
          gap: var(--dragon-padding-m, 0.5rem);
          background: var(--dragon-background-color-50, #ffffff);
          border: 1px solid var(--dragon-border-color, #e0e0e0);
          border-radius: 8px;
          padding: var(--dragon-padding-s, 0.25rem) var(--dragon-padding-s, 0.25rem) var(--dragon-padding-s, 0.25rem) var(--dragon-padding-m, 0.5rem); /* 4px 4px 4px 8px */
          font-size: 0.85em;
        }
        agent-chat-panel .wa-queue-text {
          flex: 1;
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          color: var(--dragon-text-color, #333);
        }
        agent-chat-panel .wa-queue-actions {
          display: flex;
          align-items: center;
          gap: 0;
          flex-shrink: 0;
        }
        agent-chat-panel .wa-queue-actions button {
          width: 28px;
          height: 28px;
        }
        agent-chat-panel .wa-queue-actions button svg {
          width: 16px;
          height: 16px;
        }
        agent-chat-panel .wa-config-view {
          flex: 1;
          overflow-y: auto;
          padding: var(--dragon-padding-l, 0.75rem);   /* 12px, was 16px */
          background: var(--dragon-background-color, #fafafa);
          display: flex;
          flex-direction: column;
          gap: var(--dragon-padding-m, 0.75rem);        /* 12px, was 16px */
        }
        agent-chat-panel .wa-config-header {
          display: flex;
          align-items: center;
          gap: var(--dragon-padding-m, 0.5rem);
          font-weight: bold;
          font-size: var(--dragon-font-size-l, 1rem);   /* 1rem, was 1.05em */
        }
        agent-chat-panel .wa-config-section {
          display: flex;
          flex-direction: column;
          gap: var(--dragon-padding-m, 0.5rem);   /* 8px, was 10px */
          background: var(--dragon-background-color-300, white);
          border: 1px solid var(--dragon-border-color, #eee);
          border-radius: 8px;
          padding: var(--dragon-padding-l, 0.75rem);   /* 12px */
        }
        agent-chat-panel .wa-config-section-title {
          font-weight: 600;
          font-size: 0.9em;
          color: var(--dragon-label-color, #555);
        }
        agent-chat-panel .wa-config-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: var(--dragon-padding-l, 0.75rem);
        }
        agent-chat-panel .wa-config-seg {
          display: flex;
          gap: var(--dragon-padding-s, 0.25rem);   /* 4px, was 6px */
        }
        agent-chat-panel .wa-debug-view {
          flex: 1;
          overflow-y: auto;
          padding: var(--dragon-padding-l, 0.75rem);   /* 12px, was 16px */
          background: var(--dragon-background-color, #fafafa);
          display: flex;
          flex-direction: column;
          gap: var(--dragon-padding-m, 0.75rem);        /* 12px, was 16px */
        }
        agent-chat-panel .wa-debug-section {
          display: flex;
          flex-direction: column;
          flex: 1;
          min-height: 0;
        }
        agent-chat-panel .wa-debug-ta {
          flex: 1;
          width: 100%;
          box-sizing: border-box;
          min-height: 120px;
          font-family: monospace;
          font-size: 0.8em;
          white-space: pre;
          overflow: auto;
          resize: vertical;
          background: var(--dragon-input-background-color, white);
          border: 1px solid var(--dragon-input-border-color, #e0e0e0);
          border-radius: 4px;
          padding: var(--dragon-padding-m, 0.5rem);   /* 8px */
          color: var(--dragon-input-text-color, #222);
        }
        agent-chat-panel .wa-debug-copy-row {
          margin-top: var(--dragon-padding-s, 0.25rem);   /* 4px, was 6px */
        }
      </style>
      <div class="header">
        ${this._titleEditActive
          ? html`<div class="wa-title-edit-row">
              ${this._titleEditInputEl}
              ${this._titleEditConfirmBtnEl}
              ${this._titleEditCancelBtnEl}
            </div>`
          : html`<span class="header-title">${headerTitle}</span>
              ${(this.config?.persist !== false) ? this._titleEditBtnEl : ""}`
        }
        <div style="position:relative; display:flex; align-items:center; gap:8px; flex-shrink:0;">
          <agent-context-gauge
            .percent=${this.usage.percent}
            .tokens=${this.usage.tokens}
            .max=${this.usage.max}
            .warnAt=${this.config?.context?.autoCompactPercent ?? 85}
            .disabled=${this.running || !(this.messages.filter((m) => m.role === "assistant").length >= 2)}
            @compact-request=${() => this.compactSession()}
          ></agent-context-gauge>
          ${(this.config?.persist !== false) ? this._newSessionBtnEl : ""}
          ${(this.config?.persist !== false) ? this._historyBtnEl : ""}
          ${(() => {
            const items: { label: string; disabled?: boolean; onSelect: () => void }[] = [];

            // --- Choose model group (067-ui) — gated: needs >=2 configured models ---
            const models = this._models ?? [];
            if (models.length >= 2) {
              const activeId = this._state?.model;
              items.push({ label: "Choose model", disabled: true, onSelect: () => {} });
              for (const m of models) {
                const label = resolveModelLabel(models, m.id);
                const isActive = m.id === activeId;
                items.push({
                  label: isActive ? `✓ ${label}` : label,
                  onSelect: () => {
                    this._menuOpen = false;
                    this._session?.setModel(m.id);
                    this.requestUpdate();
                  },
                });
              }
            }

            items.push({
              label: "Configuration",
              onSelect: () => { this._menuOpen = false; this._toggleConfig(); },
            });
            if (this.debug) {
              items.push({
                label: "Debug",
                onSelect: () => { this._menuOpen = false; this._toggleDebug(); },
              });
            }
            return items.length === 0
              ? ""
              : html`
                  ${this._menuBtnEl}
                  ${uiRegistry.menu({
                    open: this._menuOpen,
                    anchorId: "menu-anchor",
                    onRequestClose: () => { this._menuOpen = false; this.requestUpdate(); },
                    items,
                  })}
                `;
          })()}
          ${this._renderHistoryPanelEl()}
        </div>
      </div>

      ${this._debugOpen
        ? this._renderDebugView()
        : this._configOpen
        ? this._renderConfigView()
        : html`
            ${this.running && !this._state?.inProgressTurnId ? this._progressEl : ""}

            <div
              class="messages-list"
              @block-button=${(e: any) => this._handleBlockButton(e)}
              @block-submit=${(e: any) => this._handleBlockSubmit(e)}
            >
              ${this.messages.map(
                (msg) => html`
                  <agent-message-view
                    .role=${msg.role}
                    .text=${msg.text || ""}
                    .images=${msg.images || []}
                    .trace=${msg.trace}
                    .blocks=${msg.blocks || []}
                    .parts=${msg.parts}
                    .pointedItems=${msg.pointedItems}
                    .disabled=${msg.disabled}
                    .dataSource=${this._readOnlyDataSource}
                    .registry=${this.registry}
                    .userAvatar=${this._userAvatar}
                    .agentAvatar=${this._agentAvatar}
                    .userName=${this.appContext?.userName}
                    .agentShortName=${this.agentShortName}
                    .toolRenderers=${this._toolRenderers}
                  ></agent-message-view>
                `,
              )}
              ${(() => {
                if (this.running && !!this._state?.inProgressTurnId && this._workingDotsEl) {
                  return html`
                    <div class="message-row assistant">
                      <div class="message-container assistant">
                        ${this._workingDotsEl}
                      </div>
                    </div>
                  `;
                }
                return "";
              })()}
              ${this._renderFailedTurnAffordance()}
            </div>

            ${this.error && !this._lastFailed()
              ? html`
                  <div class="error-region">
                    <span>Error: ${this.error}</span>
                    <span class="error-close" @click=${() => this._clearError()}>&times;</span>
                  </div>
                `
              : ""}

            ${this._renderQueueList()}
            ${this._renderPickChips()}
            ${this._thumbStripEl}
            ${this._fileInputEl}
            <div class="input-area">
              ${this._imageInput === false ? "" : this._attachBtnEl}
              ${this._pickToggleBtnEl}
              ${this._inputEl}
              ${this._showStopButton() ? this._stopBtnEl : this._sendBtnEl}
            </div>
          `}
    `;
  }
}

if (!customElements.get("agent-chat-panel")) {
  customElements.define("agent-chat-panel", AgentChatPanel);
}

declare global {
  interface HTMLElementTagNameMap {
    "agent-chat-panel": AgentChatPanel;
  }
}

// -------------------------------------------------------------------------
// Pure helpers (exported for testability) — no component state dependency.
// -------------------------------------------------------------------------

/**
 * Deterministic guard: should the auto-title fire?
 * No IO, no `this` — only inputs → boolean.
 */


/**
 * Display label for a session row.
 * Uses the saved title, or falls back to a locale-formatted creation date.
 */
export function formatSessionLabel(
  meta: { title: string; createdAt: number }
): string {
  const t = (meta.title ?? "").trim();
  if (t) return t;
  return new Date(meta.createdAt).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * Compact locale timestamp for the session row subtitle (updatedAt).
 */
export function formatTimestamp(ms: number): string {
  return new Date(ms).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
