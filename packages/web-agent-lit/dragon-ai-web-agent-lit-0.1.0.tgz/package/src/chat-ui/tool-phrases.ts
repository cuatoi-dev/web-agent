import type { AuditEntry } from "@dragon-ai/web-agent-core";

const GENERIC_AGENT = "Agent";

function agentLabel(agentShortName?: string): string {
  const trimmed = agentShortName?.trim();
  return trimmed ? trimmed : GENERIC_AGENT;
}

function asRecord(input: unknown): Record<string, unknown> {
  return input && typeof input === "object" ? (input as Record<string, unknown>) : {};
}

/** 'role "name"' or bare 'role' (from DomAdapter.describeElement()) →
 *  'the role "name"' / 'the role'. */
function describeThing(desc: string): string {
  const m = /^(\S+)(?: "(.+)")?$/.exec(desc.trim());
  if (!m) return "an element";
  const [, role, name] = m;
  return name ? `the ${role} "${name}"` : `the ${role}`;
}

function extractClickDesc(outcomeSummary: string): string | undefined {
  const m = /^Clicked \[[^\]]+\] ([^.]+)\./.exec(outcomeSummary);
  return m?.[1]?.trim();
}

function extractFillDesc(outcomeSummary: string): string | undefined {
  const m = /^Filled \[[^\]]+\] ([^→]+)→/.exec(outcomeSummary);
  return m?.[1]?.trim();
}

type PhraseBuilder = (entry: AuditEntry, agent: string) => string;

const PHRASE_BUILDERS: Record<string, PhraseBuilder> = {
  click: (entry, agent) => {
    if (!entry.outcomeSummary.startsWith("Clicked [")) {
      return `${agent} tried to click an element`;
    }
    const desc = extractClickDesc(entry.outcomeSummary);
    return desc ? `${agent} clicked ${describeThing(desc)}` : `${agent} clicked an element`;
  },
  fill: (entry, agent) => {
    const { value } = asRecord(entry.input);
    const valueStr = typeof value === "string" ? value : undefined;
    if (!entry.outcomeSummary.startsWith("Filled [")) {
      return valueStr ? `${agent} tried to enter "${valueStr}"` : `${agent} tried to fill in a field`;
    }
    const desc = extractFillDesc(entry.outcomeSummary);
    const target = desc ? describeThing(desc) : "a field";
    return valueStr ? `${agent} entered "${valueStr}" into ${target}` : `${agent} filled in ${target}`;
  },
  select_option: (entry, agent) => {
    const { option } = asRecord(entry.input);
    const optionStr = typeof option === "string" ? option : undefined;
    if (!entry.outcomeSummary.startsWith('Selected "')) {
      return optionStr ? `${agent} tried to select "${optionStr}"` : `${agent} tried to select an option`;
    }
    return optionStr ? `${agent} selected "${optionStr}"` : `${agent} selected an option`;
  },
  see: (entry, agent) => {
    if (entry.outcomeSummary !== "Screenshot captured.") {
      return `${agent} tried to take a screenshot`;
    }
    const { ref } = asRecord(entry.input);
    return typeof ref === "string" && ref
      ? `${agent} took a screenshot of part of the page`
      : `${agent} took a screenshot of the page`;
  },
  snapshot_page: (_entry, agent) => `${agent} looked at the page`,
  query_state: (_entry, agent) => `${agent} checked the app's data`,
  wait_for: (_entry, agent) => `${agent} waited for the page to update`,
  wait: (entry, agent) => {
    const { seconds } = asRecord(entry.input);
    return typeof seconds === "number" ? `${agent} waited ${seconds}s` : `${agent} waited`;
  },
  list_data_sources: (_entry, agent) => `${agent} looked at the available data`,
  query_data: (entry, agent) => {
    const { source } = asRecord(entry.input);
    return typeof source === "string" && source
      ? `${agent} looked through the ${source} data`
      : `${agent} looked through the data`;
  },
  show_generative_ui: (entry, agent) => {
    const { type } = asRecord(entry.input);
    return type === "form"
      ? `${agent} showed you a form`
      : `${agent} showed you some options`;
  },
  search_skills: (entry, agent) => {
    const { query } = asRecord(entry.input);
    return typeof query === "string" && query
      ? `${agent} searched skills for "${query}"`
      : `${agent} searched its skills`;
  },
  load_skill: (entry, agent) => {
    const { name } = asRecord(entry.input);
    return typeof name === "string" && name
      ? `${agent} loaded the ${name} skill`
      : `${agent} loaded a skill`;
  },
  show_chart: (entry, agent) => {
    const { title } = asRecord(entry.input);
    return typeof title === "string" && title
      ? `${agent} drew a chart: ${title}`
      : `${agent} drew a chart`;
  },
};

const IN_PROGRESS_PHRASES: Record<string, (agent: string) => string> = {
  click: (agent) => `${agent} is clicking…`,
  fill: (agent) => `${agent} is typing…`,
  select_option: (agent) => `${agent} is selecting an option…`,
  see: (agent) => `${agent} is taking a screenshot…`,
  snapshot_page: (agent) => `${agent} is looking at the page…`,
  query_state: (agent) => `${agent} is checking the app's data…`,
  wait_for: (agent) => `${agent} is waiting for the page to update…`,
  wait: (agent) => `${agent} is waiting…`,
  list_data_sources: (agent) => `${agent} is looking at the available data…`,
  query_data: (agent) => `${agent} is searching the data…`,
  show_generative_ui: (agent) => `${agent} is preparing some options…`,
  search_skills: (agent) => `${agent} is searching its skills…`,
  load_skill: (agent) => `${agent} is loading a skill…`,
  show_chart: (agent) => `${agent} is drawing a chart…`,
};

/** Friendly, host-facing phrase for one tool-step audit entry. Falls back
 *  to "{Agent} used the tool {name}" for any tool with no defined phrase
 *  (custom tools, or built-ins not in the friendly set). An unresolved
 *  (empty) outcomeSummary means the tool is still in progress, not failed —
 *  route it to a neutral present-tense phrase instead of the "tried to" wording. */
export function toolStepPhrase(entry: AuditEntry, agentShortName?: string): string {
  const agent = agentLabel(agentShortName);
  if (!entry.outcomeSummary) {
    const inProgress = IN_PROGRESS_PHRASES[entry.name];
    return inProgress ? inProgress(agent) : `${agent} is using ${entry.name}…`;
  }
  const builder = PHRASE_BUILDERS[entry.name];
  return builder ? builder(entry, agent) : `${agent} used the tool ${entry.name}`;
}
