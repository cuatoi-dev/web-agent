import { describeElementParts } from "@dragon-ai/web-agent-core";
import { getAgentCursor } from "./agent-cursor.js";

export interface PickedItem {
  id: number; // stable, monotonic
  role: string;
  name: string;
  detached: boolean; // element left the DOM
}

export interface PointerControllerOptions {
  /** Fires whenever the picked set OR active flag changes (panel re-renders chips). */
  onChange: () => void;
  /** CSS selector for UI to exclude from pinning (defaults to the agent panel). */
  agentUiSelector?: string; // default "[data-agent-ui]"
  /** Max pins allowed. */
  maxItems?: number; // default 8
}

interface Entry {
  el: Element;
  item: PickedItem;
  badgeEl: HTMLElement | null;
}

const STYLE_ID = "wa-pointer-mode-styles";
const DEFAULT_MAX_ITEMS = 8;
const DEFAULT_AGENT_UI_SELECTOR = "[data-agent-ui]";
const PINNABLE_SELECTOR =
  'button, a[href], input, select, textarea, [role], [contenteditable="true"], [onclick]';
const LAYER_Z_INDEX = 2147482000;

const CSS = `
.wa-pointer-layer {
  position: fixed; inset: 0;
  pointer-events: none;
  z-index: ${LAYER_Z_INDEX};
}
.wa-pointer-outline {
  position: fixed;
  border: 2px solid var(--dragon-action-color-info, #6750A4);
  background: var(--dragon-action-color-info-10opc, rgba(103, 80, 164, 0.12));
  border-radius: 4px;
  pointer-events: none;
  transition: all 0.05s linear;
  display: none;
}
.wa-pointer-tooltip {
  position: fixed;
  background: var(--dragon-background-color-900, #333);
  color: var(--dragon-text-color, #fff);
  font: 12px/1.4 system-ui;
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  pointer-events: none;
  display: none;
}
.wa-pointer-badge {
  position: fixed;
  min-width: 18px;
  height: 18px;
  border-radius: 9px;
  background: var(--dragon-action-color-info, #6750A4);
  color: var(--dragon-action-text-color-info, #fff);
  font: 11px/18px system-ui;
  text-align: center;
  transform: translate(-50%, -50%);
  pointer-events: none;
  box-shadow: 0 0 0 2px var(--dragon-background-color, #fff);
}
html.wa-picking, html.wa-picking * {
  cursor: crosshair !important;
}
@media (prefers-reduced-motion: reduce) {
  .wa-pointer-outline { transition: none; }
}
`;

function injectStyles() {
  if (typeof document === "undefined") return;
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = CSS;
  document.head.appendChild(style);
}

export class PointerController {
  private opts: Required<PointerControllerOptions>;
  private active = false;
  private items: Entry[] = [];
  private nextId = 1;

  private layer: HTMLElement | null = null;
  private outlineEl: HTMLElement | null = null;
  private tooltipEl: HTMLElement | null = null;

  private observer: MutationObserver | null = null;
  private rafId: number | null = null;

  private readonly handlePointerMove = (ev: PointerEvent) => this.onPointerMove(ev);
  private readonly handleClick = (ev: MouseEvent) => this.onClick(ev);
  private readonly handleSuppress = (ev: Event) => this.onSuppress(ev);

  constructor(opts: PointerControllerOptions) {
    injectStyles();
    this.opts = {
      onChange: opts.onChange,
      agentUiSelector: opts.agentUiSelector ?? DEFAULT_AGENT_UI_SELECTOR,
      maxItems: opts.maxItems ?? DEFAULT_MAX_ITEMS,
    };
  }

  isActive(): boolean {
    return this.active;
  }

  getPickedItems(): PickedItem[] {
    return this.items.map((e) => ({ ...e.item }));
  }

  /** 016-2: resolve a picked item's id to its live Element, for send-time
   *  focused-snapshot assembly. Returns undefined for an unknown, detached,
   *  or disconnected item (defensive — `syncDetached()` should already have
   *  flagged it, this guards a race between read and use). */
  resolveElement(id: number): Element | undefined {
    const entry = this.items.find((e) => e.item.id === id);
    if (!entry || entry.item.detached || !entry.el.isConnected) return undefined;
    return entry.el;
  }

  atCap(): boolean {
    const liveCount = this.items.filter((e) => !e.item.detached).length;
    return liveCount >= this.opts.maxItems;
  }

  get maxItems(): number {
    return this.opts.maxItems;
  }

  enable(): void {
    if (this.active) return;
    this.active = true;
    this.ensureLayer();
    if (typeof document !== "undefined") {
      document.documentElement.classList.add("wa-picking");
      document.addEventListener("pointermove", this.handlePointerMove, true);
      document.addEventListener("click", this.handleClick, true);
      document.addEventListener("mousedown", this.handleSuppress, true);
      document.addEventListener("pointerdown", this.handleSuppress, true);
    }
    this.ensureObserver();
    this.ensureRaf();
    this.opts.onChange();
  }

  disable(): void {
    if (!this.active) return;
    this.active = false;
    if (typeof document !== "undefined") {
      document.documentElement.classList.remove("wa-picking");
      document.removeEventListener("pointermove", this.handlePointerMove, true);
      document.removeEventListener("click", this.handleClick, true);
      document.removeEventListener("mousedown", this.handleSuppress, true);
      document.removeEventListener("pointerdown", this.handleSuppress, true);
    }
    this.hideOutline();
    this.hideTooltip();
    this.opts.onChange();
  }

  toggle(): void {
    if (this.active) this.disable();
    else this.enable();
  }

  pinAt(rawTarget: Element): void {
    if (!rawTarget) return;
    if (this.isExcluded(rawTarget)) return;
    const target = this.resolvePinnable(rawTarget);
    const existing = this.items.find((e) => e.el === target);
    if (existing) {
      this.unpin(existing.item.id);
      return;
    }
    if (this.atCap()) {
      this.opts.onChange();
      return;
    }
    const { role, name } = describeElementParts(target);
    const entry: Entry = {
      el: target,
      item: { id: this.nextId++, role, name, detached: false },
      badgeEl: null,
    };
    this.items.push(entry);
    this.renumberBadges();
    this.opts.onChange();
  }

  unpin(id: number): void {
    const idx = this.items.findIndex((e) => e.item.id === id);
    if (idx === -1) return;
    const [entry] = this.items.splice(idx, 1);
    entry.badgeEl?.remove();
    this.renumberBadges();
    this.opts.onChange();
  }

  reveal(id: number): void {
    const entry = this.items.find((e) => e.item.id === id);
    if (!entry || entry.item.detached) return;
    entry.el.scrollIntoView({ behavior: "smooth", block: "center" });
    requestAnimationFrame(() => {
      const rect = entry.el.getBoundingClientRect();
      getAgentCursor().flash({
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
      });
    });
  }

  clear(): void {
    for (const entry of this.items) entry.badgeEl?.remove();
    this.items = [];
    this.opts.onChange();
  }

  syncDetached(): void {
    let changed = false;
    for (const entry of this.items) {
      // isConnected (not body.contains) — pierces shadow-root boundaries so
      // pinned elements inside a host's shadow DOM aren't falsely flagged.
      if (!entry.item.detached && !entry.el.isConnected) {
        entry.item.detached = true;
        entry.badgeEl?.remove();
        entry.badgeEl = null;
        changed = true;
      }
    }
    if (changed) this.opts.onChange();
  }

  dispose(): void {
    this.disable();
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.layer?.remove();
    this.layer = null;
    this.outlineEl = null;
    this.tooltipEl = null;
    this.items = [];
  }

  // ---------------------------------------------------------------------
  // Internal
  // ---------------------------------------------------------------------

  /** `Element.closest()` that pierces shadow-root boundaries: search up the
   *  current tree; when the search reaches a shadow root, hop to its host and
   *  continue. Needed because host registries (e.g. cat-store's Material Web)
   *  render the real clicked node inside a widget's own shadow root, so a plain
   *  `closest("[data-agent-ui]")` on that node stops at the shadow boundary and
   *  never reaches the light-DOM `<agent-chat-panel data-agent-ui>` ancestor. */
  private closestAcrossShadow(el: Element, selector: string): Element | null {
    let node: Element | null = el;
    while (node) {
      const hit = node.closest(selector);
      if (hit) return hit;
      const root = node.getRootNode();
      node = root instanceof ShadowRoot ? (root.host as Element) : null;
    }
    return null;
  }

  private isExcluded(el: Element): boolean {
    if (this.closestAcrossShadow(el, this.opts.agentUiSelector)) return true;
    if (this.layer && this.layer.contains(el)) return true;
    return false;
  }

  /** Real-world buttons/links nest a label span or icon; hovering/clicking that
   *  inner content should resolve to the interactive ancestor, not the leaf. */
  private resolvePinnable(el: Element): Element {
    return el.closest(PINNABLE_SELECTOR) ?? el;
  }

  private ensureLayer(): void {
    if (typeof document === "undefined") return;
    if (this.layer && document.body.contains(this.layer)) return;
    this.layer = document.createElement("div");
    this.layer.className = "wa-pointer-layer";
    this.layer.setAttribute("data-agent-ui", "true");

    this.outlineEl = document.createElement("div");
    this.outlineEl.className = "wa-pointer-outline";
    this.layer.appendChild(this.outlineEl);

    this.tooltipEl = document.createElement("div");
    this.tooltipEl.className = "wa-pointer-tooltip";
    this.layer.appendChild(this.tooltipEl);

    document.body.appendChild(this.layer);

    for (const entry of this.items) {
      entry.badgeEl = this.createBadge();
    }
    this.renumberBadges();
  }

  private createBadge(): HTMLElement {
    const badge = document.createElement("div");
    badge.className = "wa-pointer-badge";
    this.layer?.appendChild(badge);
    return badge;
  }

  private renumberBadges(): void {
    this.items.forEach((entry, idx) => {
      if (entry.item.detached) {
        entry.badgeEl?.remove();
        entry.badgeEl = null;
        return;
      }
      if (!entry.badgeEl) {
        entry.badgeEl = this.createBadge();
      }
      entry.badgeEl.textContent = String(idx + 1);
    });
  }

  private repositionOverlay(): void {
    if (this.outlineEl && this.outlineEl.style.display !== "none" && this.hoveredEl) {
      if (!this.hoveredEl.isConnected) {
        this.hideOutline();
        this.hideTooltip();
      } else {
        this.positionOutline(this.hoveredEl);
      }
    }
    for (const entry of this.items) {
      if (entry.item.detached || !entry.badgeEl) continue;
      const rect = entry.el.getBoundingClientRect();
      entry.badgeEl.style.left = `${rect.left}px`;
      entry.badgeEl.style.top = `${rect.top}px`;
    }
  }

  private ensureRaf(): void {
    if (this.rafId !== null) return;
    const loop = () => {
      if (!this.active && this.items.length === 0) {
        this.rafId = null;
        return;
      }
      this.repositionOverlay();
      this.rafId = requestAnimationFrame(loop);
    };
    this.rafId = requestAnimationFrame(loop);
  }

  private ensureObserver(): void {
    if (this.observer || typeof MutationObserver === "undefined") return;
    this.observer = new MutationObserver(() => this.syncDetached());
    this.observer.observe(document.body, { childList: true, subtree: true });
  }

  private hoveredEl: Element | null = null;

  /** The true innermost event target, un-retargeted across shadow-root
   *  boundaries (host apps commonly render behind a shadow root, which
   *  makes `ev.target` resolve to the shadow host instead of the real
   *  element for document-level listeners). */
  private realTarget(ev: Event): Element | null {
    const path = ev.composedPath();
    return (path[0] as Element) ?? (ev.target as Element | null);
  }

  private onPointerMove(ev: PointerEvent): void {
    const raw = this.realTarget(ev);
    if (!raw || this.isExcluded(raw)) {
      this.hoveredEl = null;
      this.hideOutline();
      this.hideTooltip();
      return;
    }
    const el = this.resolvePinnable(raw);
    this.hoveredEl = el;
    this.positionOutline(el);
    this.positionTooltip(el);
  }

  private positionOutline(el: Element): void {
    if (!this.outlineEl) return;
    const rect = el.getBoundingClientRect();
    this.outlineEl.style.display = "block";
    this.outlineEl.style.left = `${rect.left}px`;
    this.outlineEl.style.top = `${rect.top}px`;
    this.outlineEl.style.width = `${rect.width}px`;
    this.outlineEl.style.height = `${rect.height}px`;
  }

  private positionTooltip(el: Element): void {
    if (!this.tooltipEl) return;
    const { role, name } = describeElementParts(el);
    this.tooltipEl.textContent = `${role} — ${name || "(no name)"}`;
    const rect = el.getBoundingClientRect();
    this.tooltipEl.style.display = "block";
    const top = Math.max(0, rect.top - 24);
    this.tooltipEl.style.left = `${rect.left}px`;
    this.tooltipEl.style.top = `${top}px`;
  }

  private hideOutline(): void {
    if (this.outlineEl) this.outlineEl.style.display = "none";
  }

  private hideTooltip(): void {
    if (this.tooltipEl) this.tooltipEl.style.display = "none";
  }

  private onClick(ev: MouseEvent): void {
    const el = this.realTarget(ev);
    if (!el || this.isExcluded(el)) return;
    ev.preventDefault();
    ev.stopPropagation();
    this.pinAt(el);
  }

  private onSuppress(ev: Event): void {
    const el = this.realTarget(ev);
    if (!el) return;
    if (this.isExcluded(el)) return;
    ev.preventDefault();
    ev.stopPropagation();
  }
}
