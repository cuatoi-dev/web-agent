import type { RenderableBlock, AuditEntry } from "@dragon-ai/web-agent-core";

/**
 * An ordered, renderable piece of an assistant message.
 * - `text` carries raw markdown for prose.
 * - `block` carries a UI block (button grid, chart, form, ...).
 * - `tool` carries a compact record of one tool call (name + outcome), rendered
 *   inline between text segments as a lightweight step row.
 */
export type MessagePart =
  | { kind: "text"; text: string; html?: string }
  | { kind: "block"; block: RenderableBlock }
  | { kind: "tool"; audit: AuditEntry };