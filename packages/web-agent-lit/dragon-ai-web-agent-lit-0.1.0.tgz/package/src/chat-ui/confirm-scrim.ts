import { registry as uiRegistry } from "../ui/registry.js";
import type { ConfirmInteractionFn } from "@dragon-ai/web-agent-core";

export function createConfirmScrim(panelEl: HTMLElement): ConfirmInteractionFn {
  let currentScrim: HTMLElement | null = null;
  let currentResolve: ((v: boolean) => void) | null = null;
  let currentKeyHandler: ((e: KeyboardEvent) => void) | null = null;

  return (detail) => {
    if (currentResolve) {
      const r = currentResolve;
      cleanup();
      r(false);
    }

    return new Promise<boolean>((resolve) => {
      currentResolve = resolve;

      const backdrop = document.createElement("div");
      backdrop.className = "wa-confirm-scrim";
      backdrop.style.cssText = [
        "position: absolute",
        "inset: 0",
        "background: var(--dragon-black-color-50opc, rgba(0, 0, 0, 0.5))",
        "z-index: 10000",
        "display: flex",
        "align-items: center",
        "justify-content: center",
        "padding: 16px",
        "box-sizing: border-box",
      ].join(";");

      const card = document.createElement("div");
      card.className = "wa-confirm-card";
      card.setAttribute("role", "dialog");
      card.setAttribute("aria-modal", "true");
      card.setAttribute("aria-labelledby", "wa-confirm-title");
      card.style.cssText = [
        "background: var(--dragon-dialog-background-color, white)",
        "border-radius: 12px",
        "padding: 20px",
        "box-shadow: var(--dragon-dialog-box-shadow, 0 4px 24px rgba(0,0,0,0.2))",
        "max-width: 320px",
        "width: 100%",
        "display: flex",
        "flex-direction: column",
        "gap: 12px",
      ].join(";");

      const title = document.createElement("h3");
      title.id = "wa-confirm-title";
      title.style.cssText = "margin: 0; font-size: 1.1em; color: var(--dragon-text-color, #333);";
      title.textContent = "Confirm action";
      card.appendChild(title);

      const desc = document.createElement("p");
      desc.style.cssText = "margin: 0; font-size: 0.95em; color: var(--dragon-text-color, #555);";
      desc.innerHTML = `Agent wants to perform <strong>${detail.action}</strong> on <strong>${detail.name || detail.ref}</strong>.`;
      card.appendChild(desc);

      if (detail.reason) {
        const reasonEl = document.createElement("p");
        reasonEl.className = "wa-confirm-reason";
        reasonEl.style.cssText = "margin: 0; font-size: 0.85em; color: var(--dragon-label-color, #666); background: var(--dragon-background-color-300, #f5f5f5); padding: 8px; border-radius: 6px;";
        reasonEl.textContent = `Reason: ${detail.reason}`;
        card.appendChild(reasonEl);
      }

      const btnRow = document.createElement("div");
      btnRow.style.cssText = "display: flex; justify-content: flex-end; gap: 8px; margin-top: 8px;";

      const rejectBtn = uiRegistry.button({
        label: "Reject",
        variant: "secondary",
        onPress: () => {
          cleanup();
          resolve(false);
        },
      });

      const allowBtn = uiRegistry.button({
        label: "Allow",
        variant: "primary",
        onPress: () => {
          cleanup();
          resolve(true);
        },
      });

      btnRow.appendChild(rejectBtn);
      btnRow.appendChild(allowBtn);
      card.appendChild(btnRow);
      backdrop.appendChild(card);

      currentKeyHandler = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          e.preventDefault();
          cleanup();
          resolve(false);
        }
      };
      window.addEventListener("keydown", currentKeyHandler);

      panelEl.appendChild(backdrop);
      currentScrim = backdrop;
    });
  };

  function cleanup() {
    if (currentKeyHandler) {
      window.removeEventListener("keydown", currentKeyHandler);
      currentKeyHandler = null;
    }
    if (currentScrim && currentScrim.parentNode) {
      currentScrim.parentNode.removeChild(currentScrim);
    }
    currentScrim = null;
    currentResolve = null;
  }
}
