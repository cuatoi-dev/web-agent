import { type AgentCursor } from "./agent-cursor.js";
import { type ActionCueFn, type CueKind } from "@dragon-ai/web-agent-core";

export interface CueActionDeps {
  getCursor: () => AgentCursor;
  speed: () => "slow" | "fast";
}

export function createActionCue(deps: CueActionDeps): ActionCueFn {
  return async (el: Element | undefined, kind: CueKind, detail?: {
    value?: string;
    speedMs?: number;
    point?: { x: number; y: number };
    rect?: { x: number; y: number; width: number; height: number };
  }) => {
    try {
      const cursor = deps.getCursor();
      const speed = deps.speed();

      let point: { x: number; y: number } | undefined;
      if (detail?.point) {
        point = detail.point;
      } else if (detail?.rect) {
        point = {
          x: detail.rect.x + detail.rect.width / 2,
          y: detail.rect.y + detail.rect.height / 2,
        };
      } else if (el && typeof el.getBoundingClientRect === "function") {
        const r = el.getBoundingClientRect();
        point = {
          x: r.left + r.width / 2,
          y: r.top + r.height / 2,
        };
      }

      switch (kind) {
        case "click":
          if (point) {
            await cursor.moveTo(point, speed);
          }
          cursor.clickPulse();
          break;
        case "see":
          if (point) {
            await cursor.moveTo(point, speed);
          }
          if (detail?.rect) {
            cursor.flash(detail.rect);
          }
          break;
        case "fill":
          if (point) {
            await cursor.moveTo(point, speed);
          }
          try {
            if (el && typeof (el as any).focus === "function") {
              (el as HTMLElement).focus();
            }
          } catch {}
          break;
        case "select":
          if (point) {
            await cursor.moveTo(point, speed);
          }
          break;
        default:
          break;
      }
    } catch (err) {
      // best-effort cue actions, do not propagate errors
    }
  };
}
