import { defaultRenderers } from "../index.js";
import "../index.js";
import type { CuesConfig } from "@dragon-ai/web-agent-core";

export class WebAgentBubble extends HTMLElement {
  private isOpen = false;
  private launcherBtn!: HTMLButtonElement;
  private containerEl!: HTMLDivElement;
  private panelEl: any = null;
  private _imageInput?: boolean;
  private _model?: string;
  private _models?: import("@dragon-ai/web-agent-core").ModelOption[];
  private _path?: string;
  private _type?: "openai" | "anthropic";
  private _streaming?: boolean;
  private _tools?: any[];
  private _skills?: any[];
  private _renderers?: any[];
  private _cues?: CuesConfig;
  private _agentName?: string;
  private _agentShortName?: string;
  private _userAvatar?: string;
  private _agentAvatar?: string;
  private _launcherIcon?: string;
  private _debug?: boolean;

  get imageInput() {
    return this._imageInput;
  }

  set imageInput(val: boolean | undefined) {
    this._imageInput = val;
    if (this.panelEl) {
      this.panelEl.imageInput = val;
    }
  }

  get model() {
    return this._model;
  }

  set model(val: string | undefined) {
    this._model = val;
    if (this.panelEl) { this.panelEl.model = val; }
  }

  get models() { return this._models; }
  set models(val: import("@dragon-ai/web-agent-core").ModelOption[] | undefined) {
    this._models = val;
    if (this.panelEl) { this.panelEl.models = val; }
  }

  get path() {
    return this._path;
  }

  set path(val: string | undefined) {
    this._path = val;
    if (this.panelEl) {
      this.panelEl.path = val;
    }
  }

  get type() {
    return this._type;
  }

  set type(val: "openai" | "anthropic" | undefined) {
    this._type = val;
    if (this.panelEl) {
      this.panelEl.type = val;
    }
  }

  get streaming() {
    return this._streaming;
  }

  set streaming(val: boolean | undefined) {
    this._streaming = val;
    if (this.panelEl) {
      this.panelEl.streaming = val;
    }
  }

  get tools() {
    return this._tools;
  }

  set tools(val: any[] | undefined) {
    this._tools = val;
    if (this.panelEl) {
      this.panelEl.tools = val;
    }
  }

  get skills() {
    return this._skills;
  }

  set skills(val: any[] | undefined) {
    this._skills = val;
    if (this.panelEl) {
      this.panelEl.skills = val;
    }
  }

  get renderers() {
    return this._renderers;
  }

  set renderers(val: any[] | undefined) {
    this._renderers = val;
    if (this.panelEl) {
      this.panelEl.renderers = val;
    }
  }

  get cues() {
    return this._cues;
  }

  set cues(val: typeof this._cues) {
    this._cues = val;
    if (this.panelEl) {
      this.panelEl.cues = val;
    }
  }

  private _onCuesChange?: (cues: { speed: "slow" | "fast"; enabled: boolean }) => void;
  get onCuesChange() { return this._onCuesChange; }
  set onCuesChange(val: typeof this._onCuesChange) {
    this._onCuesChange = val;
    if (this.panelEl) { this.panelEl.onCuesChange = val; }
  }

  get agentName() { return this._agentName; }
  set agentName(val: string | undefined) { this._agentName = val; if (this.panelEl) this.panelEl.agentName = val; }
  get agentShortName() { return this._agentShortName; }
  set agentShortName(val: string | undefined) { this._agentShortName = val; if (this.panelEl) this.panelEl.agentShortName = val; this._renderLauncher(); }
  get userAvatar() { return this._userAvatar; }
  set userAvatar(val: string | undefined) { this._userAvatar = val; if (this.panelEl) this.panelEl.userAvatar = val; }
  get agentAvatar() { return this._agentAvatar; }
  set agentAvatar(val: string | undefined) { this._agentAvatar = val; if (this.panelEl) this.panelEl.agentAvatar = val; this._renderLauncher(); }
  get launcherIcon() { return this._launcherIcon; }
  set launcherIcon(val: string | undefined) { this._launcherIcon = val; this._renderLauncher(); }
  get debug() { return this._debug; }
  set debug(val: boolean | undefined) {
    this._debug = val;
    if (this.panelEl) this.panelEl.debug = val;
  }

  connectedCallback() {
    if (this.querySelector("#launcher")) {
      this.launcherBtn = this.querySelector("#launcher") as HTMLButtonElement;
      this.containerEl = this.querySelector("#panel-container") as HTMLDivElement;
      this.panelEl = this.querySelector("agent-chat-panel");
      this.isOpen = this.containerEl.style.display === "flex";
      this.setupListeners();
      this._renderLauncher();
      return;
    }

    this.innerHTML = `
      <style>
        web-agent-bubble #panel-container {
          position: fixed;
          bottom: 80px;
          right: 20px;
          width: 400px;
          height: 600px;
          max-height: 80vh;
          display: none;
          flex-direction: column;
          overflow: hidden;
          box-shadow: var(--elevate-3);
          z-index: 1000;
        }
        @media (max-width: 600px) {
          web-agent-bubble #panel-container {
            width: calc(100% - 40px) !important;
            height: calc(100vh - 120px) !important;
            max-height: calc(100vh - 120px) !important;
            bottom: 80px !important;
            right: 20px !important;
            left: 20px !important;
            border-radius: 8px !important;
          }
        }
        web-agent-bubble .wa-launcher-avatar {
          width: 100%;
          height: 100%;
          border-radius: 50%;
          object-fit: cover;
        }
      </style>
      <button class="circle extra margin fixed right bottom" style="z-index:1000;" id="launcher">
        <span id="launcher-icon" class="wa-launcher-icon"><i>chat</i></span>
      </button>
      <div class="card no-padding" style="display: none;" id="panel-container">
      </div>
    `;

    this.launcherBtn = this.querySelector("#launcher") as HTMLButtonElement;
    this.containerEl = this.querySelector("#panel-container") as HTMLDivElement;
    this.setupListeners();
    this._renderLauncher();
  }

  private setupListeners() {
    this.launcherBtn.onclick = () => this.toggle();
  }

  private _renderLauncher() {
    if (!this.launcherBtn) return;
    const iconEl = this.launcherBtn.querySelector("#launcher-icon") as HTMLElement | null;
    if (this.isOpen) return; // toggle() owns the open-state icon
    if (iconEl) {
      if (this._launcherIcon) {
        iconEl.innerHTML = `<i>${this._launcherIcon}</i>`;
      } else if (this._agentAvatar) {
        iconEl.innerHTML = `<img class="wa-launcher-avatar" src="${this._agentAvatar}" alt="${this._agentShortName || "Open chat"}">`;
      } else {
        iconEl.innerHTML = "<i>chat</i>";
      }
    }
  }

  toggle() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) {
      this.containerEl.style.display = "flex";
      this.launcherBtn.querySelector("#launcher-icon")!.innerHTML = "<i>close</i>";
      if (!this.panelEl) {
        this.panelEl = document.createElement("agent-chat-panel");

        // Mock store to satisfy agent-chat-panel's requirement
        this.panelEl.store = {
          getState: () => ({
            ui: { route: window.location.pathname },
          }),
          subscribe: () => () => {},
          dispatch: () => {},
        };

        this.panelEl.appContext = {
          appName: "Web Agent Docs",
          appDescription: "Documentation for the web-agent project.",
        };

        // Configurable backend constant (default to cat-store openai-proxy value)
        const BACKEND = {
          type: "openai",
          path: "/api/openai/v1",
          model: "gpt-oss:120b-cloud"
        };

        this.panelEl.path = this._path ?? BACKEND.path;
        this.panelEl.model = this._model ?? BACKEND.model;
        if (this._models) this.panelEl.models = this._models;
        this.panelEl.type = this._type ?? BACKEND.type;
        this.panelEl.imageInput = this._imageInput;
        this.panelEl.streaming = this._streaming;
        this.panelEl.renderers = this._renderers ?? defaultRenderers;
        if (this._cues) this.panelEl.cues = this._cues;
        if (this._onCuesChange) this.panelEl.onCuesChange = this._onCuesChange;
        if (this._tools) this.panelEl.tools = this._tools;
        if (this._skills) this.panelEl.skills = this._skills;
        if (this._agentName) this.panelEl.agentName = this._agentName;
        if (this._agentShortName) this.panelEl.agentShortName = this._agentShortName;
        if (this._userAvatar) this.panelEl.userAvatar = this._userAvatar;
        if (this._agentAvatar) this.panelEl.agentAvatar = this._agentAvatar;
        if (this._debug !== undefined) this.panelEl.debug = this._debug;

        this.panelEl.config = {
          persist: true,
          sessionNamespace: "web-agent-docs",
          appendSystemPrompt: "You are an assistant for the Web Agent documentation site. You can help users understand how to use, configure, and extend the Web Agent. You operate the current page only and cannot change pages; if the user needs a different page, ask them to switch to it. Keep replies precise, concise, and helpful."
        };

        this.panelEl.style.position = "static";
        this.panelEl.style.width = "100%";
        this.panelEl.style.height = "100%";
        this.panelEl.style.display = "flex";
        this.panelEl.style.flexDirection = "column";

        this.containerEl.appendChild(this.panelEl);
      }
    } else {
      this.containerEl.style.display = "none";
      this._renderLauncher();
    }
  }
}

if (!customElements.get("web-agent-bubble")) {
  customElements.define("web-agent-bubble", WebAgentBubble);
}
