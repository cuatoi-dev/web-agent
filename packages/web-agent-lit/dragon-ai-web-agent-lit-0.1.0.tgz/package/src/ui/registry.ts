import { UiRegistry } from "./registry-types.js";

const ICON_SVGS: Record<string, string> = {
  more_vert: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>`,
  send: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>`,
  arrow_upward: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"/></svg>`,
  close: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>`,
  attach_file: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5a2.5 2.5 0 0 1 5 0v10.5c0 .83-.67 1.5-1.5 1.5s-1.5-.67-1.5-1.5V6H10v9.5a2.5 2.5 0 0 0 5 0V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/></svg>`,
  chat: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z"/></svg>`,
  stop: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M6 6h12v12H6z"/></svg>`,
  history: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>`,
  delete: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>`,
  edit: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>`,
  add_comment: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M21.99 4c0-1.1-.89-2-1.99-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4-.01-18zM17 11h-4v4h-2v-4H7V9h4V5h2v4h4v2z"/></svg>`,
  settings: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.07-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.74,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.8,11.69,4.8,12s0.02,0.64,0.07,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.47-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"/></svg>`,
  arrow_back: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M20,11H7.83l5.59-5.59L12,4l-8,8l8,8l1.41-1.41L7.83,13H20V11z"/></svg>`,
  bug_report: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M20 8h-2.81c-.45-.78-1.07-1.45-1.82-1.96L17 4.41 15.59 3l-2.17 2.17C12.96 5.06 12.49 5 12 5c-.49 0-.96.06-1.41.17L8.41 3 7 4.41l1.62 1.63C7.88 6.55 7.26 7.22 6.81 8H4v2h2.09c-.05.33-.09.66-.09 1v1H4v2h2v1c0 .34.04.67.09 1H4v2h2.81c1.04 1.79 2.97 3 5.19 3s4.15-1.21 5.19-3H20v-2h-2.09c.05-.33.09-.66.09-1v-1h2v-2h-2v-1c0-.34-.04-.67-.09-1H20V8zm-6 8h-4v-2h4v2zm0-4h-4v-2h4v2z"/></svg>`,
  ads_click: `<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M11.71 17.99C8.53 17.84 6 15.22 6 12c0-3.31 2.69-6 6-6 3.22 0 5.84 2.53 5.99 5.71l-2.1-.63C15.48 9.65 13.89 8 12 8c-2.21 0-4 1.79-4 4 0 1.89 1.65 3.48 3.08 3.89l.63 2.1zM23 12c0 .22-.01.44-.02.66l-1.98-.6c0-.02.01-.04.01-.06 0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c.02 0 .04 0 .06-.01l.6 1.98c-.22.01-.44.02-.66.02C5.92 23 1 18.08 1 12S5.92 1 12 1s11 4.92 11 11zm-9.71 1.29l6.42 1.95-2.55 1.42 2.86 2.86-1.41 1.41-2.86-2.86-1.42 2.55z"/></svg>`,
};

if (typeof document !== "undefined") {
  const id = "wa-registry-styles";
  if (!document.getElementById(id)) {
    const style = document.createElement("style");
    style.id = id;
    style.textContent = `
.wa-btn {
  font-family: inherit;
  font-size: 1rem;
  padding: 8px 16px;
  border-radius: 8px;
  border: 1px solid var(--dragon-border-color, #c4c7c5);
  background-color: var(--dragon-action-color-info, #1a73e8);
  color: var(--dragon-action-text-color-info, #ffffff);
  cursor: pointer;
  box-sizing: border-box;
}
.wa-btn:hover {
  opacity: 0.9;
}
.wa-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.wa-btn.wa-btn-secondary {
  background-color: transparent;
  color: var(--dragon-action-color-info, #1a73e8);
  border: 1px solid var(--dragon-action-color-info, #1a73e8);
}
.wa-btn.wa-btn-danger {
  background-color: var(--dragon-action-color-error, #d93025);
  color: var(--dragon-action-text-color-error, #ffffff);
  border-color: var(--dragon-action-color-error, #d93025);
}

.wa-icon-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  padding: 0;
  box-sizing: border-box;
  outline: none;
}
.wa-icon-btn:hover {
  background-color: var(--dragon-action-color-info-10opc, rgba(0, 0, 0, 0.05));
}
.wa-icon-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.wa-icon-btn svg {
  display: block;
}

.wa-input-container {
  display: flex;
  align-items: center;
  border: 1px solid var(--dragon-border-color, #c4c7c5);
  border-radius: 8px;
  padding: 4px 8px;
  background-color: var(--dragon-input-background-color, #ffffff);
  box-sizing: border-box;
}
.wa-input-container.disabled {
  background-color: var(--dragon-background-color-500, #f1f3f4);
  opacity: 0.7;
}
.wa-input {
  flex: 1;
  border: none;
  background: transparent;
  outline: none;
  font-family: inherit;
  font-size: 1rem;
  padding: 6px 4px;
  color: inherit;
}
.wa-input:disabled {
  cursor: not-allowed;
}

.wa-checkbox-label {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  user-select: none;
  font-family: inherit;
  font-size: 1rem;
}
.wa-checkbox {
  cursor: pointer;
  width: 18px;
  height: 18px;
}

.wa-progress {
  width: 100%;
  height: 4px;
}

.wa-working-dots {
  display: flex;
  gap: 4px;
  padding: 12px 16px;
  align-items: center;
  animation: wa-fade-in 0.2s 400ms both;
}
.wa-working-dots span {
  width: 6px; height: 6px; border-radius: 50%; background: var(--dragon-border-color, #c4c7c5);
  animation: wa-bounce 1.4s infinite ease-in-out both;
}
.wa-working-dots span:nth-child(1) { animation-delay: -0.32s; }
.wa-working-dots span:nth-child(2) { animation-delay: -0.16s; }
@keyframes wa-bounce { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1); } }
@keyframes wa-fade-in { from { opacity: 0; } to { opacity: 1; } }
    `;
    document.head.appendChild(style);
  }
}

export const registry: UiRegistry = {
  button({ label, variant = "primary", disabled, onPress }) {
    const b = document.createElement("button");
    if (variant === "secondary") {
      b.className = "border wa-btn wa-btn-secondary";
    } else if (variant === "danger") {
      b.className = "error wa-btn wa-btn-danger";
    } else {
      b.className = "primary wa-btn wa-btn-primary";
    }
    b.textContent = label;

    Object.defineProperty(b, "disabled", {
      get() {
        return b.hasAttribute("disabled");
      },
      set(val) {
        if (val) {
          b.setAttribute("disabled", "");
          b.classList.add("disabled");
        } else {
          b.removeAttribute("disabled");
          b.classList.remove("disabled");
        }
      },
      configurable: true,
    });

    b.disabled = !!disabled;
    b.addEventListener("click", (e) => {
      if (b.disabled) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      onPress();
    });
    return b;
  },

  iconButton({ icon, label, disabled, onPress }) {
    const b = document.createElement("button");
    b.className = "circle transparent wa-icon-btn";
    b.disabled = !!disabled;
    b.setAttribute("aria-label", label);
    
    if (ICON_SVGS[icon]) {
      const temp = document.createElement("div");
      temp.innerHTML = ICON_SVGS[icon];
      const svgEl = temp.firstElementChild;
      if (svgEl) {
        b.appendChild(svgEl);
      }
    } else {
      const i = document.createElement("i");
      i.textContent = icon;
      b.appendChild(i);
    }
    
    b.addEventListener("click", onPress);
    return b;
  },

  textInput({ value, placeholder = "", disabled, onInput }) {
    const wrapper = document.createElement("div");
    wrapper.className = "wa-input-container";
    
    const input = document.createElement("input");
    input.type = "text";
    input.className = "wa-input";
    input.value = value;
    input.placeholder = placeholder;
    input.disabled = !!disabled;
    if (disabled) {
      wrapper.classList.add("disabled");
    }
    
    input.addEventListener("input", () => {
      onInput(input.value);
    });
    
    wrapper.appendChild(input);
    
    Object.defineProperty(wrapper, "value", {
      get() { return input.value; },
      set(v) { input.value = v; }
    });
    Object.defineProperty(wrapper, "placeholder", {
      get() { return input.placeholder; },
      set(v) { input.placeholder = v; }
    });
    Object.defineProperty(wrapper, "disabled", {
      get() { return input.disabled; },
      set(d) {
        input.disabled = !!d;
        if (d) {
          wrapper.classList.add("disabled");
        } else {
          wrapper.classList.remove("disabled");
        }
      }
    });
    
    return wrapper;
  },

  checkbox({ checked, label, onChange }) {
    const wrapper = document.createElement("label");
    wrapper.className = "checkbox wa-checkbox-label";
    
    const input = document.createElement("input");
    input.type = "checkbox";
    input.className = "wa-checkbox";
    input.checked = checked;
    input.addEventListener("change", () => {
      onChange(input.checked);
    });
    
    const span = document.createElement("span");
    span.textContent = label;
    
    wrapper.appendChild(input);
    wrapper.appendChild(span);
    
    Object.defineProperty(wrapper, "checked", {
      get() { return input.checked; },
      set(v) { input.checked = !!v; }
    });
    
    return wrapper;
  },

  menu({ open, anchorId, onRequestClose, items }) {
    const menuEl = document.createElement("div");
    menuEl.setAttribute("role", "menu");
    menuEl.className = "wa-menu-container";
    menuEl.style.display = open ? "block" : "none";
    
    menuEl.style.position = "fixed";
    menuEl.style.backgroundColor = "var(--dragon-dropdown-background-color, #ffffff)";
    menuEl.style.color = "var(--dragon-dropdown-item-text-color, #000000)";
    menuEl.style.border = "1px solid var(--dragon-dropdown-border-color, #ccc)";
    menuEl.style.borderRadius = "8px";
    menuEl.style.boxShadow = "var(--dragon-dropdown-elevation, 0 4px 12px rgba(0, 0, 0, 0.15))";
    menuEl.style.padding = "4px 0";
    menuEl.style.zIndex = "9999";
    menuEl.style.minWidth = "120px";
    
    const list = document.createElement("ul");
    list.style.listStyle = "none";
    list.style.margin = "0";
    list.style.padding = "0";
    
    items.forEach(item => {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.setAttribute("role", "menuitem");
      btn.textContent = item.label;
      btn.disabled = !!item.disabled;
      btn.className = "flat";
      btn.style.width = "100%";
      btn.style.textAlign = "left";
      btn.style.display = "block";
      btn.style.padding = "8px 16px";
      btn.style.border = "none";
      btn.style.background = "none";
      btn.style.color = "inherit";
      btn.style.cursor = item.disabled ? "default" : "pointer";
      
      if (!item.disabled) {
        btn.addEventListener("click", () => {
          item.onSelect();
        });
      }
      li.appendChild(btn);
      list.appendChild(li);
    });
    menuEl.appendChild(list);
    
    if (open) {
      const positionMenu = () => {
        const anchor = document.getElementById(anchorId);
        if (anchor && menuEl.style.display !== "none") {
          const rect = anchor.getBoundingClientRect();
          const menuRect = menuEl.getBoundingClientRect();
          
          let top = rect.bottom;
          let left = rect.left;
          
          const vw = window.innerWidth || document.documentElement.clientWidth;
          const vh = window.innerHeight || document.documentElement.clientHeight;
          
          if (left + menuRect.width > vw) {
            left = rect.right - menuRect.width;
          }
          if (left < 4) {
            left = 4;
          }
          
          if (top + menuRect.height > vh) {
            top = rect.top - menuRect.height;
          }
          if (top < 4) {
            top = 4;
          }
          
          menuEl.style.top = `${top}px`;
          menuEl.style.left = `${left}px`;
        }
      };
      
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          cleanup();
          onRequestClose();
        }
      };
      
      const handleOutsideClick = (e: MouseEvent) => {
        const anchor = document.getElementById(anchorId);
        const clickedInsideMenu = menuEl.contains(e.target as Node);
        const clickedInsideAnchor = anchor && anchor.contains(e.target as Node);
        if (!clickedInsideMenu && !clickedInsideAnchor) {
          cleanup();
          onRequestClose();
        }
      };
      
      const cleanup = () => {
        document.removeEventListener("click", handleOutsideClick);
        document.removeEventListener("keydown", handleKeyDown);
        window.removeEventListener("scroll", positionMenu);
        window.removeEventListener("resize", positionMenu);
        observer.disconnect();
      };
      
      const observer = new MutationObserver(() => {
        if (!document.body.contains(menuEl)) {
          cleanup();
        }
      });
      
      setTimeout(() => {
        document.addEventListener("click", handleOutsideClick);
        document.addEventListener("keydown", handleKeyDown);
        window.addEventListener("scroll", positionMenu, { passive: true });
        window.addEventListener("resize", positionMenu, { passive: true });
        positionMenu();
        if (document.body.contains(menuEl)) {
          observer.observe(document.body, { childList: true, subtree: true });
        }
      }, 0);
    }
    
    return menuEl;
  },

  progress({ indeterminate }) {
    const p = document.createElement("progress");
    p.className = "primary wa-progress";
    if (indeterminate) {
      p.removeAttribute("value");
    } else {
      p.value = 0;
    }
    return p;
  },

  workingDots() {
    const el = document.createElement("div");
    el.className = "wa-working-dots";
    el.innerHTML = `<span></span><span></span><span></span>`;
    return el;
  }
};

