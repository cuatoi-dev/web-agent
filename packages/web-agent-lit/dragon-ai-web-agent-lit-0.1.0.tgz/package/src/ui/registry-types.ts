export interface UiRegistry {
  button(o: {
    label: string;
    variant?: "primary" | "secondary" | "danger";
    disabled?: boolean;
    onPress: () => void;
  }): HTMLElement;
  iconButton(o: {
    icon: string;
    label: string;
    disabled?: boolean;
    onPress: () => void;
  }): HTMLElement;
  textInput(o: {
    value: string;
    placeholder?: string;
    disabled?: boolean;
    onInput: (v: string) => void;
  }): HTMLElement;
  checkbox(o: {
    checked: boolean;
    label: string;
    onChange: (c: boolean) => void;
  }): HTMLElement;
  menu(o: {
    open: boolean;
    anchorId: string;
    onRequestClose: () => void;
    items: {
      label: string;
      disabled?: boolean;
      onSelect: () => void;
    }[];
  }): HTMLElement;
  progress(o: {
    indeterminate: boolean;
  }): HTMLElement;
  workingDots?(): HTMLElement;
}
