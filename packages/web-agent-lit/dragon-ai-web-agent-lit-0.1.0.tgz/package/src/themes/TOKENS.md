# Dragon theme tokens

`themes/dragon-tokens.css` defines three themes, selected by `data-theme` on
any element — the root element, or any subtree container for scoped theming:
`dwf1-dark`, `dwf2-dark`, `dwf2-light`.

All three blocks declare the identical set of 352 `--dragon-*` tokens, so
switching themes never leaves a token undefined.

## Host-provided token set via `data-theme="provided"`

Setting `data-theme="provided"` on an element signals that the host application
is supplying its own `--dragon-*` token values:

1. **The package ships no values for `provided`.** `dragon-tokens.css` defines
   no CSS rules for `data-theme="provided"`.
2. **Unset tokens inherit from an ancestor base theme.** CSS custom properties
   inherit down the DOM tree. If an ancestor element specifies a base theme
   (`dwf1-dark`, `dwf2-dark`, or `dwf2-light`), unprovided tokens automatically
   inherit those base values.
3. **Component fallback backstop.** If no ancestor specifies a base theme,
   unprovided tokens fall back to the component-level defaults declared in
   `var(--dragon-*, <fallback>)`.
4. **Vendor component surfaces are separate tokens.** The `provided`/override
   mechanism recolors everything the UI styles through `--dragon-*`. Hosts that
   swap the UI registry for a vendor component system (e.g. Material Web in
   cat-store) have primitives that paint from their OWN tokens — a Material
   filled (primary) button fills from `--md-filled-button-container-color`, not
   `--dragon-action-color-info`. Such hosts must also declare those `--md-*`
   tokens on the same `data-theme="provided"` element (or any ancestor) to
   recolor those primitives; the dragon tokens alone will not reach them.
   See the Cat Store theme-showcase `provided` card for a worked example.

## Token list

### Action colours (72)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-action-text-color-error` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) |
| `--dragon-action-text-color-info` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) |
| `--dragon-action-text-color-success` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) |
| `--dragon-action-text-color-warn` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) |
| `--dragon-action-color-error` | hsl(352deg 70% 45%) | hsl(352deg 60% 45%) | hsl(10deg 100% 57%) |
| `--dragon-action-color-error-50` | hsl(352deg 70% 88%) | color-mix(…95%) | hsl(10deg 100% 88%) |
| `--dragon-action-color-error-100` | hsl(352deg 70% 68%) | color-mix(…90%) | hsl(10deg 100% 68%) |
| `--dragon-action-color-error-300` | hsl(352deg 70% 58%) | color-mix(…70%) | hsl(10deg 100% 63%) |
| `--dragon-action-color-error-500` | hsl(352deg 70% 45%) | color-mix(…50%) | hsl(10deg 100% 57%) |
| `--dragon-action-color-error-700` | hsl(352deg 60% 35%) | color-mix(…30%) | hsl(10deg 100% 51%) |
| `--dragon-action-color-error-900` | hsl(352deg 60% 25%) | color-mix(…10%) | hsl(10deg 100% 45%) |
| `--dragon-action-color-error-{0…90}opc` | hsl(352deg 70% 45% / N%) | hsl(352deg 60% 45% / N%) | hsl(10deg 100% 57% / N%) |
| `--dragon-action-color-info` | hsl(216deg 100% 50%) | hsl(257deg 100% 67%) | hsl(257deg 100% 67%) |
| `--dragon-action-color-info-50` | hsl(257deg 100% 87%) | color-mix(…95%) | hsl(257deg 100% 87%) |
| `--dragon-action-color-info-100` | hsl(257deg 100% 77%) | color-mix(…90%) | hsl(257deg 100% 77%) |
| `--dragon-action-color-info-300` | hsl(257deg 100% 72%) | color-mix(…70%) | hsl(257deg 100% 72%) |
| `--dragon-action-color-info-500` | hsl(257deg 100% 67%) | color-mix(…50%) | hsl(257deg 100% 67%) |
| `--dragon-action-color-info-700` | hsl(257deg 100% 62%) | color-mix(…30%) | hsl(257deg 100% 62%) |
| `--dragon-action-color-info-900` | hsl(257deg 100% 57%) | color-mix(…10%) | hsl(257deg 100% 57%) |
| `--dragon-action-color-info-{0…90}opc` | hsl(216deg 100% 50% / N%) | hsl(257deg 100% 67% / N%) | hsl(257deg 100% 67% / N%) |
| `--dragon-action-color-success` | hsl(151deg 74% 43%) | hsl(151deg 74% 43%) | hsl(154deg 100% 34%) |
| `--dragon-action-color-success-{50…900}` | (see CSS) | color-mix(in oklab, …) | (see CSS) |
| `--dragon-action-color-success-{0…90}opc` | hsl(151deg 74% 43% / N%) | hsl(151deg 74% 43% / N%) | hsl(154deg 100% 34% / N%) |
| `--dragon-action-color-warn` | hsl(29deg 100% 59%) | hsl(30deg 70% 60%) | hsl(38deg 100% 46%) |
| `--dragon-action-color-warn-{50…900}` | (see CSS) | color-mix(in oklab, …) | (see CSS) |
| `--dragon-action-color-warn-{0…90}opc` | hsl(29deg 100% 59% / N%) | hsl(30deg 70% 60% / N%) | hsl(38deg 100% 46% / N%) |

### Backgrounds (57)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-accordion-background-color` | var(--dragon-background-color-500) | var(--dragon-background-color-500) | var(--dragon-background-color-50) |
| `--dragon-accordion-header-hover-background-color` | var(--dragon-background-color-700) | var(--dragon-background-color-700) | var(--dragon-background-color-500) |
| `--dragon-background-color` | hsl(221deg 29% 19%) | hsl(221deg 29% 19%) | hsl(206deg 26% 95%) |
| `--dragon-background-color-{0…90}opc` | hsl(221deg 29% 19% / N%) | hsl(221deg 29% 19% / N%) | hsl(206deg 26% 95% / N%) |
| `--dragon-background-color-50` | hsl(221deg 25% 40%) | hsl(221deg 25% 5%) | hsl(0deg 0% 100%) |
| `--dragon-background-color-100` | hsl(221deg 25% 30%) | hsl(222deg 27% 11%) | hsl(0deg 0% 98%) |
| `--dragon-background-color-300` | hsl(221deg 25% 25%) | hsl(221deg 30% 15%) | hsl(210deg 25% 97%) |
| `--dragon-background-color-500` | hsl(221deg 29% 19%) | hsl(221deg 29% 19%) | hsl(206deg 26% 95%) |
| `--dragon-background-color-700` | hsl(221deg 30% 15%) | hsl(221deg 25% 25%) | hsl(204deg 17% 89%) |
| `--dragon-background-color-900` | hsl(222deg 27% 11%) | hsl(221deg 25% 30%) | hsl(206deg 14% 81%) |
| `--dragon-button-background-color` | var(--dragon-background-color-300) | var(--dragon-background-color-300) | hsl(0deg 0% 100%) |
| `--dragon-button-background-color-disabled` | var(--dragon-background-color-500) | hsl(221deg 30% 20%) | var(--dragon-background-color-300) |
| `--dragon-button-background-color-hover` | var(--dragon-background-color-100) | var(--dragon-background-color-300) | var(--dragon-background-color-300) |
| `--dragon-calendar-weekdays-background-color` | var(--dragon-background-color-300) | var(--dragon-background-color-300) | var(--dragon-action-color-info-50opc) |
| `--dragon-circular-progress-bar-background-color` | transparent | transparent | transparent |
| `--dragon-countdown-timer-background-color` | var(--dragon-background-color) | var(--dragon-background-color) | var(--dragon-background-color) |
| `--dragon-dialog-background-color` | var(--dragon-background-color-500) | var(--dragon-background-color-500) | var(--dragon-background-color-500) |
| `--dragon-dialog-overlay-background-color` | var(--dragon-background-color-50opc) | var(--dragon-background-color-50opc) | var(--dragon-background-color-50opc) |
| `--dragon-dropdown-background-color` | hsl(221deg 36% 7%) | hsl(221deg 36% 7%) | hsl(0deg 0% 100%) |
| `--dragon-dropdown-item-background-color` | transparent | transparent | transparent |
| `--dragon-dropdown-item-background-color-active` | var(--dragon-action-color-info-10opc) | var(--dragon-action-color-info-10opc) | var(--dragon-action-color-info-10opc) |
| `--dragon-dropdown-item-background-color-disabled` | var(--dragon-background-color-500) | var(--dragon-background-color-500) | var(--dragon-background-color-300) |
| `--dragon-dropdown-item-background-color-hover` | var(--dragon-action-color-info-10opc) | var(--dragon-action-color-info-10opc) | var(--dragon-action-color-info-10opc) |
| `--dragon-dropdown-item-background-color-selected` | var(--dragon-action-color-info) | var(--dragon-action-color-info) | var(--dragon-action-color-info) |
| `--dragon-input-background-color` | hsl(221deg 36% 7%) | hsl(221deg 36% 7%) | hsl(0deg 0% 100%) |
| `--dragon-input-background-color-disabled` | hsl(221deg 30% 19%) | hsl(224deg 26% 17%) | var(--dragon-background-color-300) |
| `--dragon-input-background-color-hover` | hsl(221deg 36% 7%) | hsl(221deg 36% 7%) | hsl(0deg 0% 100%) |
| `--dragon-radio-button-background-color` | hsl(0deg 0% 100%) | transparent | transparent |
| `--dragon-radio-button-background-color-checked` | hsl(0deg 0% 100%) | transparent | transparent |
| `--dragon-radio-button-background-color-disabled` | var(--dragon-text-color-disabled) | transparent | transparent |
| `--dragon-radio-button-background-color-hover` | hsl(0deg 0% 90%) | transparent | transparent |
| `--dragon-scrollbar-corner-background-color` | transparent | transparent | transparent |
| `--dragon-scrollbar-thumb-background-color` | hsl(0deg 0% 66%) | var(--dragon-background-color-900) | hsl(0deg 0% 80%) |
| `--dragon-scrollbar-thumb-background-color-hover` | hsl(0deg 0% 66%) | hsl(221deg 25% 50%) | hsl(0deg 0% 65%) |
| `--dragon-scrollbar-track-background-color` | hsl(221deg 25% 30%) | var(--dragon-background-color-100) | var(--dragon-background-color-100) |
| `--dragon-smart-list-background-color` | hsl(221deg 36% 7%) | hsl(221deg 36% 7%) | hsl(0deg 0% 100%) |
| `--dragon-smart-list-background-color-disabled` | hsl(221deg 30% 19%) | hsl(221deg 30% 19%) | hsl(0deg 0% 92%) |
| `--dragon-tabs-background-color` | hsl(221deg 30% 28%) | hsl(221deg 30% 28%) | var(--dragon-background-color-900) |
| `--dragon-tabs-background-color-disabled` | hsl(221deg 24% 34%) | hsl(221deg 24% 34%) | var(--dragon-background-color-900) |
| `--dragon-tabs-background-color-hover` | hsl(221deg 30% 33%) | hsl(221deg 30% 33%) | var(--dragon-background-color-700) |
| `--dragon-tabs-background-color-selected` | hsl(221deg 29% 19%) | hsl(221deg 29% 19%) | var(--dragon-background-color-500) |
| `--dragon-tabs-close-button-background-color` | transparent | transparent | transparent |
| `--dragon-tabs-close-button-background-color-hover` | var(--dragon-background-color-900) | var(--dragon-background-color-900) | var(--dragon-background-color-900) |
| `--dragon-tabs-input-background-color` | var(--dragon-input-background-color) | var(--dragon-input-background-color) | var(--dragon-input-background-color) |
| `--dragon-tabs-placeholder-background-color` | var(--dragon-action-color-info-50opc) | var(--dragon-action-color-info-50opc) | var(--dragon-action-color-info-50opc) |
| `--dragon-toast-background-color` | hsl(209deg 26% 20%) | hsl(209deg 26% 20%) | hsl(209deg 26% 20%) |
| `--dragon-toast-button-background-color` | transparent | transparent | transparent |
| `--dragon-toast-button-background-color-hover` | var(--dragon-white-color-10opc) | var(--dragon-white-color-10opc) | var(--dragon-white-color-10opc) |

### Black & white (22)

| Token | All themes |
|-------|------------|
| `--dragon-black-color` | hsl(0deg 0% 0%) |
| `--dragon-black-color-{0…90}opc` | hsl(0deg 0% 0% / N%) |
| `--dragon-white-color` | hsl(0deg 0% 100%) |
| `--dragon-white-color-{0…90}opc` | hsl(0deg 0% 100% / N%) |

### Calendar / flag / gauge / pagination (11)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-calendar-row-size` | 40px | 40px | 40px |
| `--dragon-flag-height` | 22.5px | 22.5px | 22.5px |
| `--dragon-flag-width` | 30px | 30px | 30px |
| `--dragon-gauge-arrow-color` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 0%) |
| `--dragon-gauge-green-color` | hsl(164deg 83% 53%) | hsl(164deg 83% 53%) | hsl(164deg 83% 53%) |
| `--dragon-gauge-orange-color` | hsl(29deg 100% 59%) | hsl(29deg 100% 59%) | hsl(29deg 100% 59%) |
| `--dragon-gauge-red-color` | hsl(10deg 100% 57%) | hsl(10deg 100% 57%) | hsl(10deg 100% 57%) |
| `--dragon-gauge-size` | 48px | 48px | 48px |
| `--dragon-gauge-transition-duration` | 2s | 2s | 2s |
| `--dragon-gauge-yellow-color` | hsl(47deg 100% 57%) | hsl(47deg 100% 57%) | hsl(47deg 100% 57%) |
| `--dragon-pagination-height` | 38px | 38px | 38px |

### Countdown timer (7)

| Token | All themes |
|-------|------------|
| `--dragon-countdown-timer-color` | var(--dragon-text-color) |
| `--dragon-countdown-timer-donut-size` | 10 |
| `--dragon-countdown-timer-loader-color` | var(--dragon-label-color) |
| `--dragon-countdown-timer-loader-size` | 10 |
| `--dragon-countdown-timer-scale-color` | var(--dragon-label-color) |
| `--dragon-countdown-timer-scale-stroke-dasharray` | 2 5.65 |
| `--dragon-countdown-timer-scale-stroke-width` | 2 |

### Icon (9)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-accordion-header-icon-color` | var(--dragon-icon-color) | var(--dragon-icon-color) | var(--dragon-icon-color) |
| `--dragon-gauge-exclamation-icon-color` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 0%) |
| `--dragon-icon-color` | var(--dragon-text-color) | var(--dragon-text-color) | hsl(205deg 8% 64%) |
| `--dragon-icon-color-disabled` | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) | hsl(206deg 14% 80%) |
| `--dragon-icon-size-xs` | 16px | 14px | 14px |
| `--dragon-icon-size-s` | 24px | 16px | 16px |
| `--dragon-icon-size-m` | 26px | 20px | 20px |
| `--dragon-icon-size-l` | 28px | 24px | 24px |
| `--dragon-icon-size-xl` | 32px | 28px | 28px |

### Progress bar / scrollbar / spinner (8)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-circular-progress-bar-linecap` | round | round | round |
| `--dragon-circular-progress-bar-loader-color` | var(--dragon-label-color) | var(--dragon-label-color) | var(--dragon-label-color) |
| `--dragon-circular-progress-bar-scale-color` | var(--dragon-label-color) | var(--dragon-label-color) | var(--dragon-label-color) |
| `--dragon-circular-progress-bar-scale-stroke-dasharray` | 2 5.65 | 2 5.65 | 2 5.65 |
| `--dragon-circular-progress-bar-scale-stroke-width` | 2 | 2 | 2 |
| `--dragon-circular-progress-bar-size` | 100px | 100px | 100px |
| `--dragon-scrollbar-size` | 6px | 6px | 6px |
| `--dragon-spinner-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |

### Smart list (1)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-smart-list-row-height` | 30px | 30px | var(--dragon-component-size-m) |

### Depth (3)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-depth-s` | 0px 1px 2px var(--dragon-black-color-20opc) inset | 0px 1px 2px var(--dragon-black-color-40opc) inset | 0px 1px 2px var(--dragon-black-color-20opc) inset |
| `--dragon-depth-m` | 0px 2px 4px var(--dragon-black-color-20opc) inset | 0px 2px 4px var(--dragon-black-color-40opc) inset | 0px 2px 4px var(--dragon-black-color-20opc) inset |
| `--dragon-depth-l` | 0px 4px 8px var(--dragon-black-color-20opc) inset | 0px 4px 8px var(--dragon-black-color-40opc) inset | 0px 4px 8px var(--dragon-black-color-20opc) inset |

### Elevation (5)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-dropdown-elevation` | var(--dragon-elevation-m) | var(--dragon-elevation-m) | var(--dragon-elevation-m) |
| `--dragon-elevation-s` | 0px 1px 2px var(--dragon-black-color-20opc) | 0px 1px 2px var(--dragon-black-color-40opc) | 0px 1px 2px var(--dragon-black-color-20opc) |
| `--dragon-elevation-m` | 0px 2px 4px var(--dragon-black-color-20opc) | 0px 2px 4px 0px … | 0px 2px 4px var(--dragon-black-color-20opc) |
| `--dragon-elevation-l` | 0px 5px 10px var(--dragon-black-color-40opc) | 0px 5px 10px var(--dragon-black-color-40opc) | 0px 5px 10px var(--dragon-black-color-40opc) |
| `--dragon-toast-elevation` | var(--dragon-elevation-m) | var(--dragon-elevation-m) | var(--dragon-elevation-m) |

### Highlight (11)

| Token | All themes |
|-------|------------|
| `--dragon-highlight-color` | hsl(45deg 100% 74%) |
| `--dragon-highlight-color-{0…90}opc` | hsl(45deg 100% 74% / N%) |

### Outline (2)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-outline-color` | hsl(216deg 96% 49%) | var(--dragon-action-color-info) | var(--dragon-action-color-info) |
| `--dragon-component-outline` | 0px 0px 0px 2px var(…) | 0px 0px 2px 2px var(…) | 0px 0px 2px 2px var(…) |

### Shadow (2)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-circular-progress-bar-box-shadow` | none | none | none |
| `--dragon-dialog-box-shadow` | 0px 5px 10px 0px var(--dragon-black-color-50opc) | 0px 5px 10px 0px var(--dragon-black-color-50opc) | 0px 10px 30px 0px var(--dragon-black-color-20opc) |

### Radio button (12)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-radio-button-border-style` | solid | solid | solid |
| `--dragon-radio-button-border-width` | 1px | 2px | 2px |
| `--dragon-radio-button-color` | var(--dragon-action-color-info) | var(--dragon-action-color-info) | var(--dragon-action-color-info) |
| `--dragon-radio-button-color-disabled` | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) |
| `--dragon-radio-button-dot-color` | var(--dragon-action-color-info) | var(--dragon-action-color-info) | var(--dragon-action-color-info) |
| `--dragon-radio-button-dot-color-disabled` | var(--dragon-text-color-disabled) | hsl(221deg 35% 80%) | hsl(0deg 0% 100%) |
| `--dragon-radio-button-dot-size` | 8px | 8px | 8px |
| `--dragon-radio-button-focus-ring-color` | var(--dragon-action-color-info-50opc) | var(--dragon-action-color-info-30opc) | var(--dragon-action-color-info-30opc) |
| `--dragon-radio-button-focus-ring-size` | 3px | 3px | 3px |
| `--dragon-radio-button-size` | 20px | 18px | 18px |
| `--dragon-radio-button-outline-color` | var(--dragon-action-color-info-40opc) | var(--dragon-action-color-info-40opc) | var(--dragon-action-color-info-40opc) |
| `--dragon-radio-button-outline-color-disabled` | var(--dragon-action-color-info-20opc) | var(--dragon-action-color-info-20opc) | var(--dragon-action-color-info-20opc) |

### Form / label (5)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-form-validation-invalid` | var(--dragon-action-color-error) | var(--dragon-action-color-error) | var(--dragon-action-color-error) |
| `--dragon-form-validation-mandatory` | var(--dragon-action-color-warn) | var(--dragon-action-color-warn) | var(--dragon-action-color-warn) |
| `--dragon-form-validation-valid` | var(--dragon-action-color-success) | var(--dragon-action-color-success) | var(--dragon-action-color-success) |
| `--dragon-gauge-label-color` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 0%) |
| `--dragon-label-color` | hsl(0deg 0% 50%) | hsl(221deg 15% 60%) | hsl(207deg 8% 45%) |

### Input (4)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-input-icon-color` | var(--dragon-icon-color) | var(--dragon-icon-color) | var(--dragon-icon-color) |
| `--dragon-input-placeholder-color` | hsl(221deg 27% 30%) | hsl(221deg 20% 36%) | hsl(206deg 9% 64%) |
| `--dragon-input-placeholder-color-disabled` | hsl(221deg 27% 50%) | hsl(221deg 20% 35%) | hsl(206deg 9% 64%) |
| `--dragon-tabs-input-placeholder-color` | var(--dragon-input-placeholder-color) | var(--dragon-input-placeholder-color) | var(--dragon-input-placeholder-color) |

### Border colour (15)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-accordion-border-color` | var(--dragon-border-color) | var(--dragon-border-color) | var(--dragon-border-color) |
| `--dragon-border-color` | hsl(221deg 20% 35%) | hsl(221deg 27% 11%) | hsl(206deg 14% 81%) |
| `--dragon-button-border-color` | hsl(209deg 25% 34%) | var(--dragon-border-color) | var(--dragon-border-color) |
| `--dragon-button-border-color-disabled` | var(--dragon-background-color-100) | var(--dragon-background-color-100) | hsl(206deg 14% 91%) |
| `--dragon-button-border-color-hover` | hsl(209deg 25% 39%) | hsl(209deg 25% 39%) | hsl(206deg 14% 61%) |
| `--dragon-dropdown-border-color` | hsl(221deg 36% 17%) | hsl(221deg 36% 17%) | hsl(206deg 14% 81%) |
| `--dragon-dropdown-item-border-color` | var(--dragon-background-color-700) | transparent | transparent |
| `--dragon-form-border-color` | hsl(206deg 14% 81%) | hsl(221deg 25% 25%) | var(--dragon-border-color) |
| `--dragon-input-border-color` | #314168 | var(--dragon-border-color) | var(--dragon-border-color) |
| `--dragon-input-border-color-hover` | hsl(221deg 29% 11%) | var(--dragon-border-color) | var(--dragon-border-color) |
| `--dragon-radio-button-border-color` | hsl(0deg 0% 100%) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-radio-button-border-color-checked` | var(--dragon-action-color-info) | var(--dragon-action-color-info) | var(--dragon-action-color-info) |
| `--dragon-radio-button-border-color-disabled` | transparent | var(--dragon-text-color-disabled) | hsl(206deg 14% 91%) |
| `--dragon-tabs-border-color` | var(--dragon-border-color) | var(--dragon-border-color) | var(--dragon-border-color) |
| `--dragon-tabs-placeholder-border-color` | var(--dragon-action-color-info-30opc) | var(--dragon-action-color-info-30opc) | var(--dragon-action-color-info-30opc) |

### Border radius (13)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-border-radius-xs` | 1px | 1px | 1px |
| `--dragon-border-radius-s` | 2px | 2px | 2px |
| `--dragon-border-radius-m` | 4px | 4px | 4px |
| `--dragon-border-radius-l` | 8px | 8px | 8px |
| `--dragon-border-radius-xl` | 16px | 10px | 16px |
| `--dragon-dialog-border-radius` | var(--dragon-border-radius-m) | var(--dragon-border-radius-m) | var(--dragon-border-radius-m) |
| `--dragon-dropdown-border-radius` | 4px | var(--dragon-border-radius-m) | var(--dragon-border-radius-m) |
| `--dragon-dropdown-item-border-radius` | 4px | var(--dragon-border-radius-m) | var(--dragon-border-radius-m) |
| `--dragon-scrollbar-thumb-border-radius` | 3px | 3px | 3px |
| `--dragon-scrollbar-track-border-radius` | 3px | 3px | 3px |
| `--dragon-tabs-border-radius` | 4px 4px 0px 0px | 4px 4px 0px 0px | 8px 8px 0px 0px |
| `--dragon-tabs-new-tab-button-border-radius` | 4px | 4px | 50% |
| `--dragon-toast-border-radius` | var(--dragon-border-radius-m) | var(--dragon-border-radius-m) | var(--dragon-border-radius-m) |

### Component size (3)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-component-size-s` | 20px | 20px | 24px |
| `--dragon-component-size-m` | 26px | 30px | 30px |
| `--dragon-component-size-l` | 36px | 36px | 36px |

### Gap survivors (2)

| Token | All themes |
|-------|------------|
| `--dragon-calendar-row-gap` | 5px |
| `--dragon-tabs-gap-size` | 2px |

### Padding (7)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-dropdown-item-padding` | 8px | var(--dragon-padding-m) | var(--dragon-padding-m) |
| `--dragon-padding-xs` | 2px | 2px | 2px |
| `--dragon-padding-s` | 4px | 4px | 4px |
| `--dragon-padding-m` | 8px | 8px | 8px |
| `--dragon-padding-l` | 12px | 12px | 12px |
| `--dragon-padding-xl` | 16px | 16px | 16px |
| `--dragon-tabs-padding` | 5px | 5px | 5px |

### Dialog / toast borders (2)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-dialog-border` | 1px solid var(--dragon-background-color-900) | 1px solid var(--dragon-background-color-900) | 1px solid hsl(0deg 0% 80%) |
| `--dragon-toast-border` | 1px solid hsl(209deg 26% 25%) | 1px solid hsl(209deg 26% 25%) | 1px solid hsl(209deg 26% 25%) |

### Tabs (6)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-tabs-cont-height` | 30px | 30px | 30px |
| `--dragon-tabs-height` | 28px | 28px | var(--dragon-component-size-m) |
| `--dragon-tabs-height-selected` | 30px | 30px | 30px |
| `--dragon-tabs-icon-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-tabs-icon-size` | var(--dragon-icon-size-xs) | var(--dragon-icon-size-xs) | var(--dragon-icon-size-xs) |
| `--dragon-tabs-width` | 150px | 150px | 150px |

### Other (1)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-text-size` | 1rem | 10px | 10px |

Note: `--dragon-text-size` is the base unit for v2's numeric font scale (not shipped).
Use `--dragon-font-size-m` for body text.

### Font family (8)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-dropdown-item-font-family` | var(--dragon-font-family) | var(--dragon-font-family) | var(--dragon-font-family) |
| `--dragon-font-family` | "Public Sans" | "Public Sans" | "Public Sans" |
| `--dragon-font-family-bold` | "Public Sans Bold" | "Public Sans Bold" | "Public Sans Bold" |
| `--dragon-font-family-light` | "Public Sans Light" | "Public Sans Light" | "Public Sans Light" |
| `--dragon-font-family-semibold` | "Public Sans Semibold" | "Public Sans SemiBold" | "Public Sans SemiBold" |
| `--dragon-label-font-family` | var(--dragon-font-family) | var(--dragon-font-family) | var(--dragon-font-family) |
| `--dragon-toast-font-family` | var(--dragon-font-family) | var(--dragon-font-family) | var(--dragon-font-family) |
| `--dragon-toast-header-font-family` | var(--dragon-font-family-bold) | var(--dragon-font-family-bold) | var(--dragon-font-family-bold) |

Note: `--dragon-font-family-semibold` deliberately preserves the v1/v2 casing difference.

### Font size (10)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-dropdown-item-font-size` | var(--dragon-font-size-m) | var(--dragon-font-size-m) | var(--dragon-font-size-m) |
| `--dragon-font-size-xs` | 10px | 10px | 10px |
| `--dragon-font-size-s` | 12px | 12px | 12px |
| `--dragon-font-size-m` | 14px | 13px | 13px |
| `--dragon-font-size-l` | 16px | 14px | 14px |
| `--dragon-font-size-xl` | 18px | 16px | 16px |
| `--dragon-gauge-label-font-size` | 16px | 16px | 16px |
| `--dragon-label-font-size` | var(--dragon-font-size-s) | var(--dragon-font-size-s) | var(--dragon-font-size-s) |
| `--dragon-toast-font-size` | var(--dragon-font-size-m) | var(--dragon-font-size-m) | var(--dragon-font-size-m) |
| `--dragon-toast-header-font-size` | var(--dragon-font-size-l) | var(--dragon-font-size-l) | var(--dragon-font-size-l) |

### Font weight (9)

| Token | All themes |
|-------|------------|
| `--dragon-font-weight-thin` | 100 |
| `--dragon-font-weight-extralight` | 200 |
| `--dragon-font-weight-light` | 300 |
| `--dragon-font-weight-normal` | 400 |
| `--dragon-font-weight-medium` | 500 |
| `--dragon-font-weight-semibold` | 600 |
| `--dragon-font-weight-bold` | 700 |
| `--dragon-font-weight-extrabold` | 800 |
| `--dragon-font-weight-black` | 900 |

### Line height (5)

| Token | All themes |
|-------|------------|
| `--dragon-line-height-xs` | 15px |
| `--dragon-line-height-s` | 18px |
| `--dragon-line-height-m` | 21px |
| `--dragon-line-height-l` | 24px |
| `--dragon-line-height-xl` | 27px |

Note: These are px values, not unitless ratios.

### Links (4)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-link-color` | hsl(216deg 86% 51%) | hsl(216deg 86% 61%) | hsl(216deg 86% 51%) |
| `--dragon-link-color-active` | hsl(271deg 100% 60%) | hsl(271deg 100% 70%) | hsl(271deg 100% 60%) |
| `--dragon-link-color-hover` | hsl(216deg 86% 56%) | hsl(216deg 86% 66%) | hsl(216deg 86% 56%) |
| `--dragon-link-color-visited` | hsl(271deg 100% 50%) | hsl(271deg 100% 60%) | hsl(271deg 100% 50%) |

### Text colour (29)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-accordion-header-text-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-button-text-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-button-text-color-disabled` | var(--dragon-background-color-100) | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) |
| `--dragon-button-text-color-hover` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-calendar-weekdays-text-color` | var(--dragon-action-color-info-100) | var(--dragon-action-color-info-100) | var(--dragon-action-text-color-info) |
| `--dragon-countdown-timer-donut-text-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-countdown-timer-text-color` | var(--dragon-label-color) | var(--dragon-label-color) | var(--dragon-label-color) |
| `--dragon-dropdown-item-text-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-dropdown-item-text-color-active` | var(--dragon-action-color-info) | var(--dragon-action-color-info) | var(--dragon-action-color-info) |
| `--dragon-dropdown-item-text-color-disabled` | var(--dragon-background-color-100) | var(--dragon-background-color-100) | hsl(205deg 12% 70%) |
| `--dragon-dropdown-item-text-color-hover` | var(--dragon-action-color-info) | var(--dragon-action-color-info) | var(--dragon-action-color-info) |
| `--dragon-dropdown-item-text-color-selected` | var(--dragon-action-text-color-info) | var(--dragon-action-text-color-info) | var(--dragon-action-text-color-info) |
| `--dragon-header-text-color` | hsl(29deg 100% 59%) | hsl(30deg 70% 60%) | hsl(206deg 38% 15%) |
| `--dragon-header-text-color-disabled` | hsl(29deg 100% 84%) | hsl(30deg 60% 60%) | hsl(206deg 7% 55%) |
| `--dragon-header-text-color-hover` | hsl(29deg 100% 64%) | hsl(30deg 70% 64%) | hsl(206deg 38% 25%) |
| `--dragon-input-text-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-input-text-color-disabled` | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) |
| `--dragon-input-text-color-hover` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-radio-button-text-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-radio-button-text-color-disabled` | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) |
| `--dragon-tabs-input-text-color` | var(--dragon-input-text-color) | var(--dragon-input-text-color) | var(--dragon-input-text-color) |
| `--dragon-tabs-text-color` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-tabs-text-color-disabled` | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) | var(--dragon-text-color-disabled) |
| `--dragon-tabs-text-color-hover` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-tabs-text-color-selected` | var(--dragon-text-color) | var(--dragon-text-color) | var(--dragon-text-color) |
| `--dragon-text-color` | hsl(0deg 0% 100%) | hsl(221deg 30% 96%) | hsl(206deg 38% 15%) |
| `--dragon-text-color-disabled` | hsl(0deg 0% 66%) | hsl(221deg 20% 57%) | hsl(206deg 9% 64%) |
| `--dragon-toast-header-text-color` | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) | hsl(0deg 0% 100%) |
| `--dragon-toast-text-color` | hsl(0deg 0% 92%) | hsl(0deg 0% 92%) | hsl(0deg 0% 92%) |

### Text shadow (7)

| Token | dwf1-dark | dwf2-dark | dwf2-light |
|-------|-----------|-----------|------------|
| `--dragon-button-text-shadow` | none | none | none |
| `--dragon-calendar-weekdays-text-shadow` | 0px 1px 1px var(--dragon-black-color) | 0px 1px 1px var(--dragon-black-color) | 0px 1px 1px var(--dragon-black-color) |
| `--dragon-dropdown-item-text-shadow` | none | none | none |
| `--dragon-header-text-shadow` | 0px 1px 1px var(--dragon-black-color) | 0px 1px 1px var(--dragon-black-color) | none |
| `--dragon-label-text-shadow` | none | 0px 1px 1px var(--dragon-black-color) | none |
| `--dragon-tabs-text-shadow` | none | none | none |
| `--dragon-text-shadow` | none | 0px 1px 1px var(--dragon-black-color) | none |

---

## What is deliberately absent, and what to use instead

| Absent | Reason | Use instead |
|--------|--------|-------------|
| `--dragon-primary-color*`, `-secondary-*`, `-tertiary-*` | v1-only (deprecated in v2) | `--dragon-action-color-info` |
| `--dragon-gap-*` | v2-only | `--dragon-padding-*` |
| `--dragon-font-size-2…12` | resolves ~3× larger under v2 than v1 | `--dragon-font-size-xs…xl` |
| `--dragon-input-border-color-disabled` | v2 value references `--dragon-border-color-disabled`, a v2-only unshipped token | — |
| `--dragon-circular-progress-bar-gradient-color-start` | references `--dragon-primary-color` (v1-only) | — |
| `--dragon-circular-progress-bar-gradient-color-end` | references `--dragon-secondary-color` (v1-only, no replacement) | — |
