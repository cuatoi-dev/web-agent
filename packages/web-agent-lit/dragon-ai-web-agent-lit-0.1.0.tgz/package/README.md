# @dragon-ai/web-agent-lit

lit-html chat UI, embeddable widget and UI-block renderers for the web-agent
in-app browser agent.

## Install

```bash
pnpm add @dragon-ai/web-agent-lit lit-html
```

`lit-html` is a peer dependency (`^1 || ^2 || ^3`) supplied by the host
application, so the agent UI binds to whichever version the host already ships.

## Entry points

| Import | Contents |
| --- | --- |
| `@dragon-ai/web-agent-lit` | chat panel and public API |
| `@dragon-ai/web-agent-lit/themes/*` | design tokens CSS (`themes/dragon-tokens.css`) |
| `@dragon-ai/web-agent-lit/embed/*` | drop-in embeddable widget, e.g. `embed/web-agent-embed` |
| `@dragon-ai/web-agent-lit/chat-ui/*` | individual chat UI components |
| `@dragon-ai/web-agent-lit/ui/*` | the UI registry seam (`ui/registry`, `ui/registry-types`) |
| `@dragon-ai/web-agent-lit/ui-blocks/*` | UI-block renderers |
| `@dragon-ai/web-agent-lit/vendor/*` | vendored CSS/font assets (Beer CSS, Public Sans) |

```ts
import "@dragon-ai/web-agent-lit/embed/web-agent-embed";
```

## Theming

Import the tokens stylesheet in your entry point:

```ts
import "@dragon-ai/web-agent-lit/themes/dragon-tokens.css";
```

Select a theme by setting `data-theme` on the root `<html>` element:

- `dwf1-dark`: DWF v1 Dark theme
- `dwf2-dark`: DWF v2 Dark theme
- `dwf2-light`: DWF v2 Light theme

```html
<html data-theme="dwf2-dark">
```

To override individual tokens, redeclare custom properties on or below `:root`:

```css
:root {
  --dragon-action-color-info: #1a73e8;
}
```

## UI registry

UI primitives (button, input, checkbox, menu, progress) render through the
registry seam in `ui/registry-types` rather than importing vendor widgets
directly, so a host can swap in its own component library via a build-time
alias. The vendored Beer CSS binding under `vendor/` is the default and is
meant to be replaced by hosts that do so.

## License

Apache-2.0
